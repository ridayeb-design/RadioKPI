# Radio KPI — Android cellular radio dashboard

Reads live radio measurements from the phone's modem through the public Android
Telephony API and shows them as a dashboard with session KPIs and CSV drive-test logging.

## Features
- **Dashboard**: serving-cell RSRP / RSRQ / SINR (LTE & 5G NR), RSCP / Ec/No (3G), RSSI (2G),
  colour-graded; 5G NSA NR leg; PCI, EARFCN/NR-ARFCN, band, TAC, Cell ID, eNB-sector, TA, CQI;
  live RSRP & SINR trend charts; GPS position and speed.
- **Cells**: serving + neighbour cells (RAT, PCI, ARFCN, level, quality, SINR).
- **KPIs**: availability, average/min/max level, avg RSRQ & SINR, % good / excellent / bad coverage,
  % SINR ≥ 13 dB, 5G time share, cell changes (handovers / reselections), RAT changes,
  unique cells, technology share.
- **Bands**: serving 4G/5G band with DL/UL frequency (calculated from EARFCN / NR-ARFCN using 3GPP tables),
  duplex mode, channel bandwidth, carrier aggregation (number of carriers and bandwidth of each),
  NSA NR leg band if the phone lists it, neighbour bands, and band usage share over the session.
- **Diag**: detects chipset vendor, root, `/dev/diag` and the vendor `diag_mdlog` logger.
  On rooted Qualcomm phones: on-device .qmdl capture (import a QXDM/QCSuper `.cfg` mask) saved to
  `Download/RadioKPI_diag`, and a switch to put the USB port into DIAG mode for PC tools
  (QXDM, QCAT, QCSuper, SCAT). Shows vendor-specific alternatives for MediaTek, Exynos and Tensor.
- **CSV logging** (timestamp, GPS, all serving metrics, NSA leg, best neighbour) with share button.
- Sampling interval 1 / 2 / 5 / 10 s. Screen stays on while open.

## Thresholds
| Metric | Excellent | Good | Fair | Poor | Bad |
|---|---|---|---|---|---|
| RSRP (dBm) | ≥ -80 | ≥ -90 | ≥ -100 | ≥ -110 | < -110 |
| RSRQ (dB) | ≥ -10 | ≥ -15 | ≥ -20 | ≥ -24 | < -24 |
| SINR (dB) | ≥ 20 | ≥ 13 | ≥ 0 | ≥ -5 | < -5 |
| RSCP (dBm) | ≥ -75 | ≥ -85 | ≥ -95 | ≥ -105 | < -105 |

Edit them in `app/src/main/java/com/radiokpi/app/radio/Models.kt` (`Thresholds`).

## Get the APK (no PC needed)
1. Create a new repository on github.com and upload the contents of this folder
   (keep the `.github` folder; it holds the build workflow).
2. Open the **Actions** tab. The *Build APK* workflow runs automatically (about 5 min).
3. Open the finished run, then download **RadioKPI-apk** under *Artifacts*. Unzip it to get `app-debug.apk`.
4. On the phone, open the APK and allow "Install unknown apps".

## Or build locally
Android Studio (Ladybug or newer): *Open* this folder, then *Build › Build APK(s)*.
Command line (JDK 17 + Android SDK): `./gradlew assembleDebug`, which creates
`app/build/outputs/apk/debug/app-debug.apk`.

## Requirements and limits
- Android 8.0+ (5G NR fields need Android 10+, bands and Ec/No need Android 11+).
- Grant **Location** and **Phone** permissions, and keep Location **on**:
  Android hides cell info otherwise.
- Values come from the vendor modem through the public API. Some phones report no neighbours,
  no SINR, or stale values. Layer-3 messages, throughput, BLER and MCS need root or
  engineering tools (QXDM, NSG) and aren't available to normal apps.
- Measurement runs while the app is open (not as a background service).
