package com.radiokpi.app.analysis

import com.radiokpi.app.radio.CellMeasurement
import com.radiokpi.app.radio.RadioSnapshot
import com.radiokpi.app.radio.Rat

enum class Severity(val label: String, val weight: Float) {
    CRITICAL("Critical", 3f), MAJOR("Major", 1.5f), MINOR("Minor", 0.5f)
}

enum class AnomalyType(val title: String, val severity: Severity, val advice: String) {
    NO_SERVICE("No service", Severity.CRITICAL,
        "No registered cell. Possible coverage hole, or a registration/core network problem."),
    WEAK_COVERAGE("Weak coverage", Severity.MAJOR,
        "Signal below -110 dBm (4G/5G) or -105 dBm (2G/3G). Possible coverage hole: check antenna tilt/azimuth, or a new site may be needed."),
    INTERFERENCE("Interference suspected", Severity.MAJOR,
        "Good signal level but poor SINR/RSRQ. Check for overlapping cells, PCI/frequency conflicts, overshooting neighbours or external interference."),
    MISSED_HO("Stronger neighbour not used", Severity.MAJOR,
        "A neighbour was at least 6 dB stronger for several samples. Check the neighbour list and handover offsets."),
    FALLBACK_LEGACY("Fallback to 2G/3G", Severity.MAJOR,
        "Phone left 4G/5G. Check 4G coverage, inter-RAT thresholds or CSFB behaviour."),
    FIVE_G_DROP("5G dropped", Severity.MINOR,
        "Phone lost 5G (SA or NSA). Check NR coverage and B1/A2 thresholds."),
    PING_PONG("Ping-pong handover", Severity.MINOR,
        "Phone bounced back to the previous cell within seconds. Review handover hysteresis/time-to-trigger and cell overlap."),
    EXCESSIVE_HO("Excessive handovers", Severity.MINOR,
        "6 or more cell changes within one minute. Possible lack of a dominant cell or poor neighbour planning."),
    SIGNAL_DROP("Sudden signal drop", Severity.MINOR,
        "Level fell 15 dB or more in one step on the same cell: obstruction, deep fading or a cell problem."),
    PCI_MOD3("PCI mod-3 conflict", Severity.MAJOR,
        "Serving and a strong co-channel neighbour have the same PCI mod 3, so their reference signals collide (lower RSRQ/SINR). Re-plan one of the PCIs."),
    NO_DOMINANT("No dominant cell", Severity.MINOR,
        "3 or more neighbours within 6 dB of the serving cell (pilot pollution). Optimise tilts/power to create dominance."),
    OVERSHOOT("Far serving cell", Severity.MINOR,
        "High timing advance: the serving cell is far away (possible overshooting). Check downtilt."),
    LOW_CQI("Low CQI", Severity.MINOR,
        "Channel quality index of 6 or less: low throughput expected."),
    STALE_DATA("Measurements not updating", Severity.MINOR,
        "The modem reported identical values for a long time, so data may be cached. Toggle airplane mode or restart measuring.")
}

data class Anomaly(
    val id: Long,
    val type: AnomalyType,
    val start: Long,
    val end: Long,
    val ongoing: Boolean,
    val detail: String,
    val cell: String?,
    val lat: Double?,
    val lon: Double?,
    val worst: Int?
) {
    val durationS: Long get() = ((end - start) / 1000).coerceAtLeast(0)
}

/**
 * Rule-based anomaly detection over the stream of radio snapshots.
 * Condition-type anomalies (e.g. weak coverage) open after [minSamples] consecutive samples and
 * stay "ongoing" until the condition clears; event-type anomalies (e.g. fallback) are instant.
 */
class AnomalyDetector {

    object Limits {
        const val WEAK_LTE_NR = -110
        const val WEAK_LEGACY = -105
        const val INTERF_MIN_LEVEL = -95
        const val INTERF_SINR = 0
        const val INTERF_RSRQ = -15
        const val MISSED_HO_DB = 6
        const val NO_DOMINANT_DB = 6
        const val NO_DOMINANT_CELLS = 3
        const val OVERSHOOT_TA = 64          // LTE TA unit ≈ 78 m, so 64 ≈ 5 km
        const val LOW_CQI = 6
        const val DROP_DB = 15
        const val PING_PONG_MS = 15_000L
        const val EXCESSIVE_HO_COUNT = 6
        const val EXCESSIVE_HO_WINDOW_MS = 60_000L
        const val STALE_SAMPLES = 10
        const val MIN_SAMPLES = 3
        const val MAX_EVENTS = 400
    }

    private class Open(val id: Long, val start: Long, var worst: Int?)

    private val events = ArrayList<Anomaly>()
    private val open = HashMap<AnomalyType, Open>()
    private val streak = HashMap<AnomalyType, Int>()
    private val streakStart = HashMap<AnomalyType, Long>()
    private val changes = ArrayDeque<Pair<Long, String>>()   // serving cell changes (time, key)
    private var nextId = 1L
    private var lastServing: CellMeasurement? = null
    private var lastFiveG = false
    private var lastExcessiveAt = 0L
    private var staleSig: String? = null
    private var staleCount = 0
    private var cameFrom: String? = null   // serving cell before the current one
    private var arrivedAt = 0L             // when the current serving cell took over

    fun reset() {
        events.clear(); open.clear(); streak.clear(); streakStart.clear(); changes.clear()
        lastServing = null; lastFiveG = false; lastExcessiveAt = 0L; staleSig = null; staleCount = 0
        cameFrom = null; arrivedAt = 0L
    }

    /** Processes one snapshot; returns the full event list (newest last). */
    fun process(s: RadioSnapshot): List<Anomaly> {
        val c = s.serving
        val lvl = c?.primaryDbm
        val lteNr = c?.rat == Rat.LTE || c?.rat == Rat.NR
        val label = c?.cellLabel

        // ---- condition-type anomalies
        track(AnomalyType.NO_SERVICE, c == null, s, 1, null, null, lowerIsWorse = true) { "No registered cell" }

        val weakThr = if (lteNr) Limits.WEAK_LTE_NR else Limits.WEAK_LEGACY
        track(AnomalyType.WEAK_COVERAGE, lvl != null && lvl < weakThr, s, Limits.MIN_SAMPLES, label, lvl, true) {
            "Level $lvl dBm (threshold $weakThr)"
        }

        val sinr = c?.sinr
        val rsrq = c?.rsrq
        val badQual = (sinr != null && sinr < Limits.INTERF_SINR) || (sinr == null && rsrq != null && rsrq < Limits.INTERF_RSRQ)
        track(AnomalyType.INTERFERENCE, lteNr && lvl != null && lvl >= Limits.INTERF_MIN_LEVEL && badQual,
            s, Limits.MIN_SAMPLES, label, sinr ?: rsrq, true) {
            "Level $lvl dBm but " + (if (sinr != null) "SINR $sinr dB" else "RSRQ $rsrq dB")
        }

        // Co-channel neighbours: same RAT and same frequency (or frequency unknown).
        // Inter-frequency layers are usually managed by priorities/load balancing, so they're not flagged.
        val sameRat = if (c == null) emptyList() else s.neighbours.filter {
            it.rat == c.rat && it.primaryDbm != null && (it.arfcn == null || c.arfcn == null || it.arfcn == c.arfcn)
        }
        val best = sameRat.maxByOrNull { it.primaryDbm ?: -999 }
        val bestLvl = best?.primaryDbm
        val missedDiff = if (lvl != null && bestLvl != null) bestLvl - lvl else null
        track(AnomalyType.MISSED_HO, missedDiff != null && missedDiff >= Limits.MISSED_HO_DB,
            s, Limits.MIN_SAMPLES, label, missedDiff, lowerIsWorse = false) {
            "Neighbour ${best?.cellLabel} is ${missedDiff} dB stronger ($bestLvl vs $lvl dBm)"
        }

        val close = if (lvl == null) 0 else sameRat.count { (it.primaryDbm ?: -999) >= lvl - Limits.NO_DOMINANT_DB }
        track(AnomalyType.NO_DOMINANT, lteNr && close >= Limits.NO_DOMINANT_CELLS,
            s, Limits.MIN_SAMPLES, label, close, lowerIsWorse = false) {
            "$close neighbours within ${Limits.NO_DOMINANT_DB} dB of serving ($lvl dBm)"
        }

        val cPci = c?.pci
        val mod3 = if (c?.rat != Rat.LTE || cPci == null || lvl == null) null else sameRat.firstOrNull { n ->
            val p = n.pci
            p != null && p != cPci && p % 3 == cPci % 3 && (n.primaryDbm ?: -999) >= lvl - Limits.NO_DOMINANT_DB
        }
        track(AnomalyType.PCI_MOD3, mod3 != null, s, Limits.MIN_SAMPLES, label, mod3?.primaryDbm, lowerIsWorse = false) {
            "PCI $cPci vs neighbour PCI ${mod3?.pci} (both mod 3 = ${cPci?.rem(3)}), ${mod3?.primaryDbm} vs $lvl dBm"
        }

        val ta = if (c?.rat == Rat.LTE) c.ta else null
        track(AnomalyType.OVERSHOOT, ta != null && ta >= Limits.OVERSHOOT_TA,
            s, Limits.MIN_SAMPLES, label, ta, lowerIsWorse = false) {
            "TA $ta ≈ ${"%.1f".format((ta ?: 0) * 0.078)} km from site"
        }

        val cqi = c?.cqi
        track(AnomalyType.LOW_CQI, cqi != null && cqi in 1..Limits.LOW_CQI,
            s, Limits.MIN_SAMPLES, label, cqi, true) { "CQI $cqi" }

        val sig = if (c == null) null else "${c.key}|${c.rsrp}|${c.rsrq}|${c.sinr}|${c.dbm}|${s.neighbours.size}"
        if (sig != null && sig == staleSig) staleCount++ else { staleSig = sig; staleCount = 0 }
        track(AnomalyType.STALE_DATA, staleCount >= Limits.STALE_SAMPLES, s, 1, label, null, true) {
            "Identical measurement for $staleCount samples"
        }

        // ---- event-type anomalies
        val prev = lastServing
        val legacy = c?.rat == Rat.WCDMA || c?.rat == Rat.GSM || c?.rat == Rat.TDSCDMA || c?.rat == Rat.CDMA
        if (prev != null && (prev.rat == Rat.LTE || prev.rat == Rat.NR) && legacy) {
            emit(AnomalyType.FALLBACK_LEGACY, s, label, lvl, "${prev.rat.label} → ${c?.rat?.label}")
        }

        val fiveG = c?.rat == Rat.NR || s.isNsa
        if (lastFiveG && !fiveG && c != null) {
            emit(AnomalyType.FIVE_G_DROP, s, label, lvl, "Now on ${s.techLabel}")
        }

        val prevLvl = prev?.primaryDbm
        if (prev != null && c != null && prev.key == c.key && prevLvl != null && lvl != null &&
            prevLvl - lvl >= Limits.DROP_DB
        ) {
            emit(AnomalyType.SIGNAL_DROP, s, label, lvl, "$prevLvl → $lvl dBm (−${prevLvl - lvl} dB)")
        }

        if (c != null && prev != null && c.key != prev.key) {
            changes.addLast(s.timestamp to c.key)
            while (changes.isNotEmpty() && s.timestamp - changes.first().first > Limits.EXCESSIVE_HO_WINDOW_MS) {
                changes.removeFirst()
            }
            // A -> B -> A: we go back to the cell we came from, shortly after arriving on B
            if (cameFrom == c.key && prev.rat == c.rat && s.timestamp - arrivedAt <= Limits.PING_PONG_MS) {
                emit(AnomalyType.PING_PONG, s, label, lvl, "${prev.cellLabel} ⇄ ${c.cellLabel}")
            }
            cameFrom = prev.key
            arrivedAt = s.timestamp
            if (changes.size >= Limits.EXCESSIVE_HO_COUNT && s.timestamp - lastExcessiveAt > Limits.EXCESSIVE_HO_WINDOW_MS) {
                lastExcessiveAt = s.timestamp
                emit(AnomalyType.EXCESSIVE_HO, s, label, changes.size, "${changes.size} cell changes in the last minute")
            }
        }

        if (c != null) {
            lastServing = c
            lastFiveG = fiveG
        }
        if (events.size > Limits.MAX_EVENTS) {
            events.subList(0, events.size - Limits.MAX_EVENTS).clear()
        }
        return events.toList()
    }

    private fun track(
        type: AnomalyType, active: Boolean, s: RadioSnapshot, minSamples: Int,
        cell: String?, value: Int?, lowerIsWorse: Boolean, detail: () -> String
    ) {
        if (!active) {
            streak[type] = 0
            val o = open.remove(type) ?: return
            replace(o.id) { it.copy(ongoing = false) }
            return
        }
        val n = (streak[type] ?: 0) + 1
        streak[type] = n
        if (n == 1) streakStart[type] = s.timestamp
        val o = open[type]
        if (o == null) {
            if (n < minSamples) return
            val id = nextId++
            open[type] = Open(id, streakStart[type] ?: s.timestamp, value)
            events.add(
                Anomaly(id, type, streakStart[type] ?: s.timestamp, s.timestamp, true, detail(), cell,
                    s.location?.lat, s.location?.lon, value)
            )
        } else {
            if (value != null) {
                val w = o.worst
                o.worst = when {
                    w == null -> value
                    lowerIsWorse -> minOf(w, value)
                    else -> maxOf(w, value)
                }
            }
            val worst = o.worst
            replace(o.id) { it.copy(end = s.timestamp, worst = worst, detail = detail()) }
        }
    }

    private fun emit(type: AnomalyType, s: RadioSnapshot, cell: String?, value: Int?, detail: String) {
        events.add(
            Anomaly(nextId++, type, s.timestamp, s.timestamp, false, detail, cell,
                s.location?.lat, s.location?.lon, value)
        )
    }

    private inline fun replace(id: Long, f: (Anomaly) -> Anomaly) {
        for (i in events.indices.reversed()) {
            if (events[i].id == id) { events[i] = f(events[i]); return }
        }
    }
}
