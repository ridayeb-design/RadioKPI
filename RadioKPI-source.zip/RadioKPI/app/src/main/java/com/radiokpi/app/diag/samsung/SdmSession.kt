package com.radiokpi.app.diag.samsung

import java.io.BufferedOutputStream
import java.io.File
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** A byte pipe to the Shannon DM port (USB bulk endpoints, or a root device node). */
interface SdmTransport {
    val label: String
    fun write(data: ByteArray)
    /** Bytes read, 0 on timeout, -1 when the link is gone. */
    fun read(buf: ByteArray): Int
    fun close()
}

data class L3Line(val t: Long, val layer: String, val dir: String, val channel: String, val name: String, val detail: String)

data class SamsungLive(
    val running: Boolean = false,
    val source: String = "",
    val startedAt: Long = 0,
    val packets: Long = 0,
    val bytes: Long = 0,
    val dropped: Long = 0,
    val l3Count: Long = 0,
    val icd: String? = null,
    val firmware: String? = null,
    val rrcState: String? = null,
    val plmn: String? = null,
    val tac: Int? = null,
    val eci: Long? = null,
    val band: Int? = null,
    val earfcn: Long? = null,
    val pci: Int? = null,
    val rsrp: Double? = null,
    val rsrq: Double? = null,
    val rssi: Double? = null,
    val rsrpMin: Double? = null,
    val rsrpMax: Double? = null,
    val rsrpAvg: Double? = null,
    val neighbours: List<NCell> = emptyList(),
    val counters: Map<String, Int> = emptyMap(),
    val log: List<L3Line> = emptyList(),
    val outDir: String? = null,
    val error: String? = null
) {
    val enb: Long? get() = eci?.let { it shr 8 }
    val sector: Long? get() = eci?.let { it and 0xff }
    val gotData: Boolean get() = packets > 0
}

object Counter {
    const val PAGING = "Paging messages (cell)"
    const val PAGING_ME = "Paging for this phone"
    const val PAGING_CS = "Paging with CS domain (voice/SMS)"
    const val REQ = "RRC connection requests"
    const val SETUP = "RRC connection setups"
    const val REJECT = "RRC connection rejects"
    const val RELEASE = "RRC connection releases"
    const val REDIRECT = "Release with redirect to 2G/3G"
    const val CSFB = "Release cause CS fallback"
    const val HO = "Handover commands"
    const val IRAT = "Inter-RAT mobility commands"
    const val REEST = "RRC re-establishments"
    const val HOFAIL = "Re-establishments after HO failure"
    const val MR = "Measurement reports"
    const val NAS_REJ = "NAS rejects (attach/TAU/service/ESM)"
    const val TAU = "Tracking area updates"
    const val ATTACH = "Attach requests"
    const val SR = "Service requests"
    const val BARRED = "Cell barred (SIB1)"
    val ORDER = listOf(PAGING, PAGING_ME, PAGING_CS, REQ, SETUP, REJECT, RELEASE, REDIRECT, CSFB, HO, IRAT, REEST, HOFAIL,
        MR, TAU, ATTACH, SR, NAS_REJ, BARRED)
}

/**
 * Runs one capture: sends SCAT's init sequence, reads/deframes/decodes the stream,
 * keeps live state, and writes:
 *   capture.sdmraw  raw DM stream   (PC: scat -t sec -d capture.sdmraw -F out.pcap)
 *   l3.pcap         RRC+NAS in GSMTAP (open in Wireshark directly)
 *   l3_log.csv      decoded message log
 *   summary.md      findings when stopped
 */
class SdmSession(
    private val transport: SdmTransport,
    private val outDir: File,
    private val onUpdate: (SamsungLive) -> Unit,
    private val now: () -> Long = System::currentTimeMillis,
    private val initGapMs: Long = 60
) {
    @Volatile private var stopRequested = false
    private val parser = SdmParser()
    private val deframer = SdmDeframer()
    @Volatile private var live = SamsungLive()
    private val counters = LinkedHashMap<String, Int>()
    private val log = ArrayDeque<L3Line>()
    private val myStmsi = mutableSetOf<String>()
    private val cellsSeen = LinkedHashMap<String, Int>()     // "EARFCN/PCI" -> samples
    private val keyEvents = mutableListOf<L3Line>()
    private var rsrpSum = 0.0; private var rsrpN = 0
    private var lastPush = 0L
    private var lastEarfcn = 0L

    private lateinit var raw: OutputStream
    private lateinit var pcapOut: OutputStream
    private lateinit var pcap: PcapWriter
    private lateinit var csv: OutputStream

    fun stop() { stopRequested = true }

    /** Blocking; call from a background thread. */
    fun run() {
        outDir.mkdirs()
        raw = BufferedOutputStream(File(outDir, "capture.sdmraw").outputStream())
        pcapOut = BufferedOutputStream(File(outDir, "l3.pcap").outputStream())
        pcap = PcapWriter(pcapOut)
        csv = BufferedOutputStream(File(outDir, "l3_log.csv").outputStream())
        csv.write("time,layer,direction,channel,message,detail\n".toByteArray())
        live = SamsungLive(running = true, source = transport.label, startedAt = now(), outDir = outDir.absolutePath)
        push(true)

        val reader = Thread({ readLoop() }, "sdm-reader")
        reader.start()
        try {
            for (p in SdmCmd.initSequence()) {
                if (stopRequested) break
                transport.write(p)
                Thread.sleep(initGapMs)
            }
        } catch (e: Exception) {
            live = live.copy(error = "Could not send start commands: ${e.message}")
            stopRequested = true
        }
        reader.join()
        try { for (p in SdmCmd.stopSequence()) transport.write(p) } catch (_: Exception) {}
        transport.close()
        finish()
    }

    private fun readLoop() {
        val buf = ByteArray(16384)
        while (!stopRequested) {
            val n = try { transport.read(buf) } catch (e: Exception) { -1 }
            if (n < 0) {
                if (!stopRequested) live = live.copy(error = "Link closed (cable unplugged or DM mode off?)")
                stopRequested = true; break
            }
            if (n == 0) { push(false); continue }
            raw.write(buf, 0, n)
            live = live.copy(bytes = live.bytes + n)
            for (pkt in deframer.feed(buf, n)) handle(pkt)
            live = live.copy(dropped = deframer.dropped)
            push(false)
        }
    }

    fun handle(pkt: ByteArray) {
        val e = parser.parse(pkt) ?: return
        live = live.copy(packets = live.packets + 1)
        val t = now()
        if (e is SdmEvent.PhyCellInfo) lastEarfcn = e.earfcn
        Gsmtap.forEvent(e, lastEarfcn)?.let { pcap.write(it, t) }
        when (e) {
            is SdmEvent.StartResponse -> live = live.copy(
                icd = "${e.icdMajor}.${e.icdMinor}",
                firmware = listOf(e.extra, e.date).filter { it.isNotBlank() }.joinToString(" · ").ifBlank { e.version })
            is SdmEvent.RrcState -> if (live.rrcState != e.label) {
                live = live.copy(rrcState = e.label)
                addLine(L3Line(t, "RRC", "--", "state", "RRC ${e.label}", ""), key = false)
            }
            is SdmEvent.ServingCell -> {
                val p = e.plmn.toString()
                val plmn = if (p.length >= 5) p.substring(0, 3) + "-" + p.substring(3) else p
                live = live.copy(plmn = plmn, tac = e.tac, eci = e.cid, band = e.band ?: live.band)
            }
            is SdmEvent.PhyCellInfo -> {
                val valid = e.rsrp > -140.5 && e.rsrp < -30
                if (valid) {
                    rsrpSum += e.rsrp; rsrpN++
                    cellsSeen.merge("${e.earfcn}/${e.pci}", 1, Int::plus)
                }
                live = live.copy(
                    earfcn = e.earfcn, pci = e.pci,
                    rsrp = if (valid) e.rsrp else null, rsrq = if (valid) e.rsrq else null, rssi = if (valid) e.rssi else null,
                    rsrpMin = if (valid) minOf(live.rsrpMin ?: e.rsrp, e.rsrp) else live.rsrpMin,
                    rsrpMax = if (valid) maxOf(live.rsrpMax ?: e.rsrp, e.rsrp) else live.rsrpMax,
                    rsrpAvg = if (rsrpN > 0) rsrpSum / rsrpN else null,
                    neighbours = e.neighbours.filter { it.rsrp > -140.5 && it.rsrp < -30 && it.arfcn > 0 }
                )
            }
            is SdmEvent.RrcOta -> {
                val info = RrcLite.decode(e.channel, e.msg)
                val forMe = count(info)
                if (info.name == "systemInformationBlockType1") {
                    (info.values["band"] as? Int)?.let { live = live.copy(band = it) }
                }
                val important = info.tags.any { it in setOf("REJECT", "HO_FAIL", "REEST", "REDIRECT", "CSFB", "BARRED", "HO_CMD", "IRAT_HO", "REEST_FAIL") }
                // Neighbour paging and repeated system information flood the log: keep only useful ones.
                val show = !(e.channel == "PCCH" && !forMe && "PAGING_CS" !in info.tags) &&
                    !(e.channel == "BCCH-DL-SCH" && info.name == "systemInformation")
                val name = if (forMe) "${info.name} (THIS PHONE)" else info.name
                if (show || important) addLine(L3Line(t, "RRC", if (e.uplink) "UL" else "DL", e.channel, name, info.detail), important)
                else csvLine(L3Line(t, "RRC", if (e.uplink) "UL" else "DL", e.channel, info.name, info.detail))
            }
            is SdmEvent.Nas -> {
                val info = NasLite.decode(e.msg)
                if ("NAS_REJECT" in info.tags) inc(Counter.NAS_REJ)
                if ("TAU" in info.tags) inc(Counter.TAU)
                if ("ATTACH" in info.tags) inc(Counter.ATTACH)
                if ("SERVICE_REQ" in info.tags || "EXT_SR" in info.tags) inc(Counter.SR)
                addLine(L3Line(t, "NAS", if (e.uplink) "UL" else "DL", if (e.msg.isNotEmpty() && (e.msg[0].toInt() and 0x0f) == 2) "ESM" else "EMM",
                    info.name, info.detail), "NAS_REJECT" in info.tags)
            }
            is SdmEvent.Other -> Unit
        }
    }

    /** Updates counters; returns true when this is a paging addressed to this phone. */
    private fun count(info: L3Info): Boolean {
        val tg = info.tags
        var forMe = false
        if ("PAGING" in tg) {
            inc(Counter.PAGING)
            if ("PAGING_CS" in tg) inc(Counter.PAGING_CS)
            @Suppress("UNCHECKED_CAST")
            val ids = info.values["stmsi"] as? List<String> ?: emptyList()
            if (ids.any { it in myStmsi }) { inc(Counter.PAGING_ME); forMe = true }
        }
        if ("REQUEST" in tg) { inc(Counter.REQ); (info.values["stmsi"] as? String)?.let { myStmsi += it } }
        if ("SETUP" in tg) inc(Counter.SETUP)
        if ("SETUP_FAIL" in tg) inc(Counter.REJECT)
        if ("RELEASE" in tg) inc(Counter.RELEASE)
        if ("REDIRECT_2G3G" in tg) inc(Counter.REDIRECT)
        if ("CSFB" in tg) inc(Counter.CSFB)
        if ("HO_CMD" in tg) inc(Counter.HO)
        if ("IRAT_HO" in tg) inc(Counter.IRAT)
        if ("REEST" in tg) inc(Counter.REEST)
        if ("HO_FAIL" in tg) inc(Counter.HOFAIL)
        if ("MR" in tg) inc(Counter.MR)
        if ("BARRED" in tg) inc(Counter.BARRED)
        return forMe
    }

    private fun inc(k: String) { counters.merge(k, 1, Int::plus) }

    private fun csvLine(l: L3Line) {
        fun q(s: String) = "\"" + s.replace("\"", "'") + "\""
        csv.write("${TS.format(Date(l.t))},${l.layer},${l.dir},${l.channel},${q(l.name)},${q(l.detail)}\n".toByteArray())
    }

    private fun addLine(l: L3Line, key: Boolean) {
        csvLine(l)
        log.addLast(l); while (log.size > 300) log.removeFirst()
        if (key && keyEvents.size < 500) keyEvents += l
        live = live.copy(l3Count = live.l3Count + 1)
    }

    private fun push(force: Boolean) {
        val t = now()
        if (!force && t - lastPush < 400) return
        lastPush = t
        onUpdate(live.copy(counters = LinkedHashMap(counters), log = log.toList()))
    }

    private fun finish() {
        listOf(raw, pcapOut, csv).forEach { try { it.flush(); it.close() } catch (_: Exception) {} }
        try { File(outDir, "summary.md").writeText(summaryMarkdown()) } catch (_: Exception) {}
        live = live.copy(running = false)
        push(true)
    }

    fun snapshot(): SamsungLive = live.copy(counters = LinkedHashMap(counters), log = log.toList())

    fun summaryMarkdown(): String = SamsungSummary.markdown(snapshot(), cellsSeen, keyEvents, now())

    companion object {
        val TS = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
    }
}

object SamsungSummary {
    data class Finding(val severity: String, val team: String, val title: String, val action: String)

    fun findings(s: SamsungLive): List<Finding> {
        val c = s.counters
        fun n(k: String) = c[k] ?: 0
        val f = mutableListOf<Finding>()
        if (n(Counter.HOFAIL) > 0) f += Finding("Major", "RAN optimisation",
            "${n(Counter.HOFAIL)} handover failure(s) (RRC re-establishment, cause handoverFailure)",
            "Check neighbour relations and HO parameters (A3 offset, TTT, CIO) between source and target PCI; check target cell availability/alarms.")
        else if (n(Counter.REEST) > 0) f += Finding("Minor", "RAN optimisation",
            "${n(Counter.REEST)} RRC re-establishment(s) (radio link failure)",
            "Look at RSRP/RSRQ before each event in l3_log.csv; likely coverage hole or interference.")
        if (n(Counter.REJECT) > 0) f += Finding("Major", "RAN capacity",
            "${n(Counter.REJECT)} RRC connection reject(s)",
            "Cell admission/congestion: check RRC users, PRB load and licence limits on the serving eNB.")
        if (n(Counter.REDIRECT) > 0) f += Finding(if (n(Counter.CSFB) > 0) "Info" else "Minor", "RAN / Core (CS)",
            "${n(Counter.REDIRECT)} release(s) with redirect to 2G/3G" + if (n(Counter.CSFB) > 0) " (CS fallback for calls)" else "",
            if (n(Counter.CSFB) > 0) "Expected while calls use CSFB. Enabling VoLTE removes the 4G→3G drop and call setup delay."
            else "Redirect without a call: LTE coverage/quality triggered release; check A2 thresholds and LTE coverage.")
        if (n(Counter.NAS_REJ) > 0) f += Finding("Major", "Core (MME/HSS)",
            "${n(Counter.NAS_REJ)} NAS reject(s)", "See the cause codes in the key events below and check subscriber profile / MME logs.")
        if (n(Counter.BARRED) > 0) f += Finding("Major", "RAN operations", "Serving cell broadcast 'cell barred' in SIB1",
            "Check whether the cell is intentionally barred (maintenance) or misconfigured.")
        s.rsrpAvg?.let {
            if (it < -110) f += Finding("Major", "RAN planning", "Weak coverage: average RSRP %.1f dBm".format(it),
                "Coverage improvement (tilt/azimuth/power, new site or small cell).")
        }
        if (n(Counter.HO) > 20 && s.startedAt > 0) f += Finding("Minor", "RAN optimisation",
            "${n(Counter.HO)} handovers in this capture", "If you were static, this is ping-pong: tune hysteresis/TTT between the cells involved.")
        if (f.isEmpty()) f += Finding("Info", "-", "No signalling failures seen in this capture", "-")
        return f
    }

    fun markdown(s: SamsungLive, cells: Map<String, Int>, key: List<L3Line>, now: Long): String = buildString {
        val df = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        appendLine("# Samsung modem (Shannon) diag summary")
        appendLine()
        appendLine("- Capture: ${df.format(Date(s.startedAt))} → ${df.format(Date(now))} (${(now - s.startedAt) / 60000} min)")
        appendLine("- Source: ${s.source}")
        appendLine("- Modem ICD: ${s.icd ?: "?"} · Firmware: ${s.firmware ?: "?"}")
        appendLine("- Packets: ${s.packets} · Bytes: ${s.bytes} · Decoded L3 messages: ${s.l3Count} · Dropped bytes: ${s.dropped}")
        appendLine()
        appendLine("## Last serving cell")
        appendLine()
        appendLine("| PLMN | TAC | ECI (eNB-sector) | Band | EARFCN | PCI | RSRP | RSRQ |")
        appendLine("|---|---|---|---|---|---|---|---|")
        appendLine("| ${s.plmn ?: "-"} | ${s.tac ?: "-"} | ${s.eci?.let { "$it (${s.enb}-${s.sector})" } ?: "-"} | ${s.band ?: "-"} | ${s.earfcn ?: "-"} | ${s.pci ?: "-"} | ${s.rsrp?.let { "%.1f dBm".format(it) } ?: "-"} | ${s.rsrq?.let { "%.1f dB".format(it) } ?: "-"} |")
        appendLine()
        s.rsrpAvg?.let { appendLine("RSRP over capture: min %.1f / avg %.1f / max %.1f dBm".format(s.rsrpMin, it, s.rsrpMax)); appendLine() }
        if (cells.isNotEmpty()) {
            appendLine("Cells camped/served (EARFCN/PCI: samples): " + cells.entries.sortedByDescending { it.value }.take(12).joinToString(", ") { "${it.key}: ${it.value}" })
            appendLine()
        }
        appendLine("## Findings")
        appendLine()
        appendLine("| Severity | Team | Issue | Action |")
        appendLine("|---|---|---|---|")
        findings(s).forEach { appendLine("| ${it.severity} | ${it.team} | ${it.title} | ${it.action} |") }
        appendLine()
        appendLine("## Signalling counters")
        appendLine()
        appendLine("| Counter | Count |")
        appendLine("|---|---|")
        Counter.ORDER.forEach { k -> s.counters[k]?.let { appendLine("| $k | $it |") } }
        appendLine()
        if (key.isNotEmpty()) {
            appendLine("## Key events")
            appendLine()
            appendLine("| Time | Layer | Dir | Message | Detail |")
            appendLine("|---|---|---|---|---|")
            key.takeLast(100).forEach { appendLine("| ${SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(it.t))} | ${it.layer} | ${it.dir} | ${it.name} | ${it.detail.replace("|", "/")} |") }
            appendLine()
        }
        appendLine("## Files")
        appendLine()
        appendLine("- `l3.pcap`: RRC + NAS messages (GSMTAP). Open in Wireshark for full 3GPP decoding.")
        appendLine("- `capture.sdmraw`: raw modem stream. On a PC: `scat -t sec -d capture.sdmraw -F full.pcap` for everything SCAT can decode.")
        appendLine("- `l3_log.csv`: every decoded message with time.")
    }
}
