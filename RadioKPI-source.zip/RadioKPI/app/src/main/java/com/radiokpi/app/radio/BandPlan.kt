package com.radiokpi.app.radio

import java.util.Locale

enum class Duplex { FDD, TDD, SDL }

data class BandResult(
    val name: String,       // "B3", "n78" (or "n78/n77" if ambiguous)
    val common: String,     // "1800", "3500"
    val duplex: Duplex,
    val dlMHz: Double?,
    val ulMHz: Double?
)

fun Double.mhz(): String = String.format(Locale.US, "%.1f MHz", this)

/** 3GPP band plans (TS 36.101 for LTE, TS 38.101-1/-2 for NR). */
object BandPlan {

    private class Lte(
        val band: Int, val fDl: Double, val nOffDl: Int, val nMax: Int,
        val fUl: Double?, val duplex: Duplex, val common: String
    )

    private val lte = listOf(
        Lte(1, 2110.0, 0, 599, 1920.0, Duplex.FDD, "2100"),
        Lte(2, 1930.0, 600, 1199, 1850.0, Duplex.FDD, "1900 PCS"),
        Lte(3, 1805.0, 1200, 1949, 1710.0, Duplex.FDD, "1800"),
        Lte(4, 2110.0, 1950, 2399, 1710.0, Duplex.FDD, "AWS-1"),
        Lte(5, 869.0, 2400, 2649, 824.0, Duplex.FDD, "850"),
        Lte(7, 2620.0, 2750, 3449, 2500.0, Duplex.FDD, "2600"),
        Lte(8, 925.0, 3450, 3799, 880.0, Duplex.FDD, "900"),
        Lte(12, 729.0, 5010, 5179, 699.0, Duplex.FDD, "700a"),
        Lte(13, 746.0, 5180, 5279, 777.0, Duplex.FDD, "700c"),
        Lte(14, 758.0, 5280, 5379, 788.0, Duplex.FDD, "700 PS"),
        Lte(17, 734.0, 5730, 5849, 704.0, Duplex.FDD, "700b"),
        Lte(18, 860.0, 5850, 5999, 815.0, Duplex.FDD, "800 Lower"),
        Lte(19, 875.0, 6000, 6149, 830.0, Duplex.FDD, "800 Upper"),
        Lte(20, 791.0, 6150, 6449, 832.0, Duplex.FDD, "800 DD"),
        Lte(21, 1495.9, 6450, 6599, 1447.9, Duplex.FDD, "1500 Upper"),
        Lte(25, 1930.0, 8040, 8689, 1850.0, Duplex.FDD, "1900+"),
        Lte(26, 859.0, 8690, 9039, 814.0, Duplex.FDD, "850+"),
        Lte(28, 758.0, 9210, 9659, 703.0, Duplex.FDD, "700 APT"),
        Lte(29, 717.0, 9660, 9769, null, Duplex.SDL, "700 SDL"),
        Lte(30, 2350.0, 9770, 9869, 2305.0, Duplex.FDD, "2300 WCS"),
        Lte(32, 1452.0, 9920, 10359, null, Duplex.SDL, "1500 L-band"),
        Lte(34, 2010.0, 36200, 36349, null, Duplex.TDD, "2000 TDD"),
        Lte(38, 2570.0, 37750, 38249, null, Duplex.TDD, "2600 TDD"),
        Lte(39, 1880.0, 38250, 38649, null, Duplex.TDD, "1900 TDD"),
        Lte(40, 2300.0, 38650, 39649, null, Duplex.TDD, "2300 TDD"),
        Lte(41, 2496.0, 39650, 41589, null, Duplex.TDD, "2500 TDD"),
        Lte(42, 3400.0, 41590, 43589, null, Duplex.TDD, "3500 TDD"),
        Lte(43, 3600.0, 43590, 45589, null, Duplex.TDD, "3700 TDD"),
        Lte(46, 5150.0, 46790, 54539, null, Duplex.TDD, "5 GHz LAA"),
        Lte(48, 3550.0, 55240, 56739, null, Duplex.TDD, "CBRS"),
        Lte(66, 2110.0, 66436, 67335, 1710.0, Duplex.FDD, "AWS-3"),
        Lte(71, 617.0, 68586, 68935, 663.0, Duplex.FDD, "600")
    )

    /** ulOffset = DL - UL in MHz for FDD bands. */
    private class Nr(
        val band: Int, val dlLo: Double, val dlHi: Double,
        val duplex: Duplex, val common: String, val ulOffset: Double? = null
    )

    // Order matters for overlapping bands: the most common band is listed first.
    private val nr = listOf(
        Nr(1, 2110.0, 2170.0, Duplex.FDD, "2100", 190.0),
        Nr(3, 1805.0, 1880.0, Duplex.FDD, "1800", 95.0),
        Nr(7, 2620.0, 2690.0, Duplex.FDD, "2600", 120.0),
        Nr(8, 925.0, 960.0, Duplex.FDD, "900", 45.0),
        Nr(20, 791.0, 821.0, Duplex.FDD, "800", -41.0),
        Nr(28, 758.0, 803.0, Duplex.FDD, "700 APT", 55.0),
        Nr(78, 3300.0, 3800.0, Duplex.TDD, "3500"),
        Nr(77, 3300.0, 4200.0, Duplex.TDD, "3700 C-band"),
        Nr(41, 2496.0, 2690.0, Duplex.TDD, "2500"),
        Nr(38, 2570.0, 2620.0, Duplex.TDD, "2600 TDD"),
        Nr(40, 2300.0, 2400.0, Duplex.TDD, "2300"),
        Nr(79, 4400.0, 5000.0, Duplex.TDD, "4700"),
        Nr(5, 869.0, 894.0, Duplex.FDD, "850", 45.0),
        Nr(2, 1930.0, 1990.0, Duplex.FDD, "1900 PCS", 80.0),
        Nr(25, 1930.0, 1995.0, Duplex.FDD, "1900+", 80.0),
        Nr(66, 2110.0, 2200.0, Duplex.FDD, "AWS-3", 400.0),
        Nr(71, 617.0, 652.0, Duplex.FDD, "600", -46.0),
        Nr(12, 729.0, 746.0, Duplex.FDD, "700a", 30.0),
        Nr(48, 3550.0, 3700.0, Duplex.TDD, "CBRS"),
        Nr(257, 26500.0, 29500.0, Duplex.TDD, "28 GHz mmW"),
        Nr(258, 24250.0, 27500.0, Duplex.TDD, "26 GHz mmW"),
        Nr(261, 27500.0, 28350.0, Duplex.TDD, "28 GHz mmW"),
        Nr(260, 37000.0, 40000.0, Duplex.TDD, "39 GHz mmW")
    )

    fun lte(earfcn: Int?): BandResult? {
        if (earfcn == null) return null
        val b = lte.firstOrNull { earfcn in it.nOffDl..it.nMax } ?: return null
        val dl = b.fDl + 0.1 * (earfcn - b.nOffDl)
        val ul = when (b.duplex) {
            Duplex.FDD -> b.fUl?.let { it + 0.1 * (earfcn - b.nOffDl) }
            Duplex.TDD -> dl
            Duplex.SDL -> null
        }
        return BandResult("B${b.band}", b.common, b.duplex, dl, ul)
    }

    /** NR-ARFCN to frequency (global raster, TS 38.104 §5.4.2.1). */
    fun nrFreqMHz(arfcn: Int): Double? = when (arfcn) {
        in 0..599999 -> arfcn * 0.005
        in 600000..2016666 -> 3000.0 + 0.015 * (arfcn - 600000)
        in 2016667..3279165 -> 24250.08 + 0.06 * (arfcn - 2016667)
        else -> null
    }

    fun nr(arfcn: Int?, reported: String?): BandResult? {
        if (arfcn == null) return reported?.let { BandResult(it, "", Duplex.TDD, null, null) }
        val f = nrFreqMHz(arfcn) ?: return null
        val matches = nr.filter { f >= it.dlLo && f <= it.dlHi }
        val reportedNums = reported?.split("/")?.mapNotNull { it.removePrefix("n").toIntOrNull() } ?: emptyList()
        val pick = matches.firstOrNull { it.band in reportedNums } ?: matches.firstOrNull()
        val name = when {
            reported != null -> reported
            matches.isEmpty() -> "n?"
            else -> matches.joinToString("/") { "n${it.band}" }
        }
        val duplex = pick?.duplex ?: Duplex.TDD
        val ul = when (duplex) {
            Duplex.FDD -> pick?.ulOffset?.let { f - it }
            Duplex.TDD -> f
            Duplex.SDL -> null
        }
        return BandResult(name, pick?.common ?: String.format(Locale.US, "%.0f", f), duplex, f, ul)
    }

    fun forCell(c: CellMeasurement): BandResult? = when (c.rat) {
        Rat.LTE -> {
            val r = lte(c.arfcn)
            when {
                r != null && c.band != null -> r.copy(name = c.band)
                r != null -> r
                c.band != null -> BandResult(c.band, "", Duplex.FDD, null, null)
                else -> null
            }
        }
        Rat.NR -> nr(c.arfcn, c.band)
        else -> null
    }
}
