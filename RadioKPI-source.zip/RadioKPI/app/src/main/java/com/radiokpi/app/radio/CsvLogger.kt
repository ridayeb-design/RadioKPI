package com.radiokpi.app.radio

import android.content.Context
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Drive-test style CSV log, one row per sample. Stored in app external files /logs. */
class CsvLogger(private val context: Context) {

    private var writer: BufferedWriter? = null
    var file: File? = null
        private set
    var rows: Int = 0
        private set

    private val tsFmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    fun start(): File {
        stop()
        val dir = File(context.getExternalFilesDir(null), "logs").apply { mkdirs() }
        val name = "radio_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".csv"
        val f = File(dir, name)
        writer = BufferedWriter(FileWriter(f)).also {
            it.write(
                "timestamp,lat,lon,accuracy_m,speed_kmh,operator,network_type,tech,rat,mcc,mnc," +
                    "pci,arfcn,band,tac_lac,cell_id,enb_sector,rsrp,rsrq,sinr,rssi,rscp,ecno,ta,cqi," +
                    "nsa_ss_rsrp,nsa_ss_rsrq,nsa_ss_sinr,neighbour_count,best_neighbour_pci,best_neighbour_dbm," +
                    "band_name,dl_mhz,ul_mhz,duplex,bw_mhz,cc_count,total_bw_mhz\n"
            )
        }
        file = f
        rows = 0
        return f
    }

    fun log(s: RadioSnapshot) {
        val w = writer ?: return
        val c = s.serving
        val best = s.neighbours.firstOrNull()
        val b = c?.bandResult
        val cols = listOf(
            tsFmt.format(Date(s.timestamp)),
            s.location?.lat?.let { "%.6f".format(Locale.US, it) },
            s.location?.lon?.let { "%.6f".format(Locale.US, it) },
            s.location?.accuracyM?.let { "%.0f".format(Locale.US, it) },
            s.location?.speedKmh?.let { "%.1f".format(Locale.US, it) },
            s.operator.replace(",", " "),
            s.networkType,
            s.techLabel,
            c?.rat?.name,
            c?.mcc, c?.mnc, c?.pci, c?.arfcn, c?.band, c?.tac, c?.cellId, c?.enbSector,
            c?.rsrp, c?.rsrq, c?.sinr, c?.rssi, c?.rscp, c?.ecno, c?.ta, c?.cqi,
            s.nsa?.ssRsrp, s.nsa?.ssRsrq, s.nsa?.ssSinr,
            s.neighbours.size, best?.pci, best?.primaryDbm,
            b?.name, b?.dlMHz?.let { "%.1f".format(Locale.US, it) }, b?.ulMHz?.let { "%.1f".format(Locale.US, it) },
            b?.duplex?.name, c?.bandwidthKhz?.let { it / 1000 },
            s.ccBandwidthsKhz.size.takeIf { it > 0 },
            s.ccBandwidthsKhz.takeIf { it.isNotEmpty() }?.sum()?.let { it / 1000 }
        )
        w.write(cols.joinToString(",") { it?.toString() ?: "" })
        w.write("\n")
        rows++
        if (rows % 5 == 0) w.flush()
    }

    fun stop() {
        try { writer?.flush(); writer?.close() } catch (_: Exception) { }
        writer = null
    }
}
