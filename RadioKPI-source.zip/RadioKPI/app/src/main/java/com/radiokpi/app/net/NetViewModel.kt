package com.radiokpi.app.net

import android.app.Application
import android.net.ConnectivityManager
import android.net.DnsResolver
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build
import android.os.CancellationSignal
import androidx.annotation.RequiresApi
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.radiokpi.app.diag.Shell
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executor
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull

class NetViewModel(app: Application) : AndroidViewModel(app) {

    private val cm = app.getSystemService(ConnectivityManager::class.java)
    private val _state = MutableStateFlow(NetUi())
    val state: StateFlow<NetUi> = _state.asStateFlow()
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.US)

    init { refreshLink() }

    private fun log(m: String) = _state.update { it.copy(log = (it.log + "${clock.format(Date())}  $m").takeLast(60)) }
    private fun progress(p: String?) = _state.update { it.copy(progress = p) }

    private fun network(): Network? = cm.activeNetwork

    fun refreshLink() = viewModelScope.launch(Dispatchers.IO) {
        _state.update { it.copy(link = readLink()) }
    }

    private fun readLink(): LinkInfo? = try {
        val n = network()
        val caps = n?.let { cm.getNetworkCapabilities(it) }
        val lp = n?.let { cm.getLinkProperties(it) }
        if (n == null || caps == null || lp == null) null else {
            val transport = when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                else -> "Other"
            }
            val addrs = lp.linkAddresses.map { it.address }
            LinkInfo(
                transport = transport,
                iface = lp.interfaceName,
                ipv4 = addrs.filterIsInstance<Inet4Address>().mapNotNull { it.hostAddress },
                ipv6 = addrs.filterIsInstance<Inet6Address>().filter { !it.isLinkLocalAddress }
                    .mapNotNull { it.hostAddress?.substringBefore('%') },
                dns = lp.dnsServers.mapNotNull { it.hostAddress?.substringBefore('%') },
                privateDns = if (Build.VERSION.SDK_INT >= 28) {
                    if (lp.isPrivateDnsActive) (lp.privateDnsServerName ?: "Automatic") else "Off"
                } else "n/a",
                mtu = if (Build.VERSION.SDK_INT >= 29) lp.mtu.takeIf { it > 0 } else null,
                validated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED),
                metered = !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED),
                downKbps = caps.linkDownstreamBandwidthKbps.takeIf { it > 0 },
                upKbps = caps.linkUpstreamBandwidthKbps.takeIf { it > 0 }
            )
        }
    } catch (e: Exception) {
        log("Link info error: ${e.message}")
        null
    }

    private fun begin(name: String): Boolean {
        if (_state.value.running != null) return false
        _state.update { it.copy(running = name) }
        return true
    }

    private fun end() = _state.update { it.copy(running = null, progress = null) }

    // ---------------------------------------------------------------- DNS

    fun runDns() = viewModelScope.launch(Dispatchers.IO) {
        if (!begin("DNS")) return@launch
        try {
            val link = readLink()
            _state.update { it.copy(link = link) }
            val n = network()
            val sys = n?.let { cm.getLinkProperties(it)?.dnsServers } ?: emptyList()
            val resolvers = (sys.mapIndexed { i, a -> "Network DNS ${i + 1}" to a } + listOf(
                "Google" to InetAddress.getByName("8.8.8.8"),
                "Cloudflare" to InetAddress.getByName("1.1.1.1"),
                "Quad9" to InetAddress.getByName("9.9.9.9")
            )).distinctBy { it.second.hostAddress }
            val hijack = "rkpi-" + java.lang.Long.toHexString(System.nanoTime()) + ".com"
            log("DNS test: ${resolvers.size} resolvers × ${NetAnalysis.DOMAINS.size} domains")
            progress("Querying ${resolvers.size} resolvers…")
            val bind: (java.net.DatagramSocket) -> Unit = { s -> try { n?.bindSocket(s) } catch (_: Exception) { } }

            val results = coroutineScope {
                resolvers.map { (name, addr) ->
                    async(Dispatchers.IO) {
                        val r = mutableListOf<DnsQueryResult>()
                        for (d in NetAnalysis.DOMAINS) {
                            r += DnsClient.query(name, addr, d, DnsPacket.TYPE_A, 1, bind = bind)
                            r += DnsClient.query(name, addr, d, DnsPacket.TYPE_A, 2, bind = bind)
                        }
                        r += DnsClient.query(name, addr, hijack, DnsPacket.TYPE_A, 1, bind = bind)
                        r += DnsClient.query(name, addr, "google.com", DnsPacket.TYPE_AAAA, 1, bind = bind)
                        r
                    }
                }.awaitAll().flatten()
            }.toMutableList()

            if (Build.VERSION.SDK_INT >= 29 && n != null) {
                progress("Testing Android system resolver…")
                for (d in NetAnalysis.DOMAINS) {
                    results += systemQuery(n, d, 1)
                    results += systemQuery(n, d, 2)
                }
            }
            val report = NetAnalysis.summarize(results, hijack, link, System.currentTimeMillis())
            _state.update { it.copy(dns = report) }
            log("DNS test done: ${results.size} queries")
        } catch (e: Exception) {
            log("DNS test failed: ${e.message}")
        }
        end()
    }

    /** Android's own resolver (netd), bypassing its cache; includes Private DNS if enabled. */
    @RequiresApi(29)
    private suspend fun systemQuery(n: Network, domain: String, attempt: Int): DnsQueryResult {
        val t0 = System.nanoTime()
        val res = withTimeoutOrNull(5000L) {
            suspendCancellableCoroutine<DnsQueryResult> { cont ->
                val flags = if (attempt == 1) DnsResolver.FLAG_NO_CACHE_LOOKUP else DnsResolver.FLAG_EMPTY
                DnsResolver.getInstance().query(
                    n, domain, DnsResolver.TYPE_A, flags, Executor { it.run() }, CancellationSignal(),
                    object : DnsResolver.Callback<List<InetAddress>> {
                        override fun onAnswer(answer: List<InetAddress>, rcode: Int) {
                            val rtt = (System.nanoTime() - t0) / 1_000_000
                            if (cont.isActive) cont.resume(
                                DnsQueryResult("System (Android)", "netd", domain, DnsPacket.TYPE_A, attempt, rtt, rcode,
                                    answer.mapNotNull { it.hostAddress }, null, if (rcode == 0) null else DnsPacket.rcodeName(rcode))
                            )
                        }

                        override fun onError(error: DnsResolver.DnsException) {
                            if (cont.isActive) cont.resume(
                                DnsQueryResult("System (Android)", "netd", domain, DnsPacket.TYPE_A, attempt, null, null,
                                    emptyList(), null, error.message ?: "error")
                            )
                        }
                    })
            }
        }
        return res ?: DnsQueryResult("System (Android)", "netd", domain, DnsPacket.TYPE_A, attempt, null, null, emptyList(), null, "timeout")
    }

    // ---------------------------------------------------------------- Latency + HTTP

    fun runLatency() = viewModelScope.launch(Dispatchers.IO) {
        if (!begin("Latency")) return@launch
        try {
            val n = network()
            val opDns = n?.let { cm.getLinkProperties(it)?.dnsServers?.firstOrNull { a -> a is Inet4Address } }?.hostAddress
            val targets = listOfNotNull(
                opDns?.let { "Operator DNS (core)" to it },
                "Google DNS" to "8.8.8.8",
                "Cloudflare" to "1.1.1.1"
            )
            val pings = targets.map { (label, ip) ->
                progress("Ping $label…")
                ping(label, ip) ?: tcpPing(label, ip, if (label.startsWith("Operator")) 53 else 443, n)
            }
            _state.update { it.copy(pings = pings, pingFindings = NetAnalysis.pingFindings(pings)) }
            log("Latency done")

            val urls = listOf(
                "https://www.google.com/generate_204",
                "https://www.youtube.com/",
                "https://www.facebook.com/"
            )
            val http = urls.map { u ->
                progress("HTTP ${URL(u).host}…")
                httpTiming(u, n)
            }
            _state.update { it.copy(http = http) }
            log("HTTP done")
        } catch (e: Exception) {
            log("Latency test failed: ${e.message}")
        }
        end()
    }

    private fun ping(label: String, ip: String): PingResult? {
        val r = Shell.run("ping -c 10 -i 0.2 -W 2 $ip", root = false, timeoutMs = 25_000)
        val times = Regex("time=([0-9.]+)").findAll(r.out).mapNotNull { it.groupValues[1].toFloatOrNull() }.toList()
        val m = Regex("(\\d+) packets transmitted, (\\d+) (?:packets )?received").find(r.out) ?: return null
        val sent = m.groupValues[1].toInt()
        val recv = m.groupValues[2].toInt()
        return PingResult(ip, label, "ICMP", sent, recv, times.minOrNull(), times.takeIf { it.isNotEmpty() }?.average()?.toFloat(),
            times.maxOrNull(), jitter(times))
    }

    private fun tcpPing(label: String, ip: String, port: Int, n: Network?): PingResult {
        val times = mutableListOf<Float>()
        val tries = 10
        repeat(tries) {
            try {
                Socket().use { s ->
                    n?.bindSocket(s)
                    val t0 = System.nanoTime()
                    s.connect(InetSocketAddress(ip, port), 2000)
                    times += (System.nanoTime() - t0) / 1_000_000f
                }
            } catch (_: Exception) { }
            Thread.sleep(150)
        }
        return PingResult(ip, label, "TCP:$port", tries, times.size, times.minOrNull(),
            times.takeIf { it.isNotEmpty() }?.average()?.toFloat(), times.maxOrNull(), jitter(times))
    }

    private fun jitter(t: List<Float>): Float? =
        if (t.size < 2) null else t.zipWithNext { a, b -> abs(b - a) }.average().toFloat()

    private fun httpTiming(u: String, n: Network?): HttpResult {
        fun once(): Pair<Int, Long> {
            val url = URL(u)
            val c = (n?.openConnection(url) ?: url.openConnection()) as HttpURLConnection
            c.connectTimeout = 6000
            c.readTimeout = 6000
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", "RadioKPI/1.3")
            val t0 = System.nanoTime()
            val code = c.responseCode
            val ms = (System.nanoTime() - t0) / 1_000_000
            try { (if (code >= 400) c.errorStream else c.inputStream)?.use { it.read(ByteArray(1024)) } } catch (_: Exception) { }
            return code to ms
        }
        return try {
            val (code, cold) = once()
            val (_, warm) = once()
            HttpResult(u, code, cold, warm, null)
        } catch (e: Exception) {
            HttpResult(u, null, null, null, e.message ?: e.javaClass.simpleName)
        }
    }

    // ---------------------------------------------------------------- Speed

    fun runSpeed(radioContext: String, bwMhz: Int? = null, rsrq: Int? = null, cell: String? = null) = viewModelScope.launch(Dispatchers.IO) {
        if (!begin("Speed")) return@launch
        val n = network()
        var dl: Float? = null
        var ul: Float? = null
        var dlBytes = 0L
        var ulBytes = 0L
        var err: String? = null
        try {
            progress("Download (max 10 s)…")
            val url = URL("https://speed.cloudflare.com/__down?bytes=60000000")
            val c = (n?.openConnection(url) ?: url.openConnection()) as HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 8000
            val buf = ByteArray(64 * 1024)
            c.inputStream.use { ins ->
                val start = System.nanoTime()
                var measuredFrom = 0L
                var bytesAfterWarmup = 0L
                while (true) {
                    val r = ins.read(buf)
                    if (r < 0) break
                    dlBytes += r
                    val el = (System.nanoTime() - start) / 1_000_000
                    if (el >= 1000) {
                        if (measuredFrom == 0L) measuredFrom = el
                        bytesAfterWarmup += r
                    }
                    if (el > 10_000) break
                }
                val el = (System.nanoTime() - start) / 1_000_000
                val window = (el - measuredFrom).coerceAtLeast(1)
                dl = if (measuredFrom > 0) bytesAfterWarmup * 8f / window / 1000f else dlBytes * 8f / el.coerceAtLeast(1) / 1000f
            }
            log("Download ${"%.1f".format(dl)} Mbps")

            progress("Upload (max 8 s)…")
            val uu = URL("https://speed.cloudflare.com/__up")
            val u = (n?.openConnection(uu) ?: uu.openConnection()) as HttpURLConnection
            u.connectTimeout = 8000; u.readTimeout = 15000
            u.doOutput = true
            u.requestMethod = "POST"
            u.setChunkedStreamingMode(64 * 1024)
            val chunk = ByteArray(64 * 1024) { (it % 251).toByte() }
            val start = System.nanoTime()
            u.outputStream.use { os ->
                while ((System.nanoTime() - start) / 1_000_000 < 8000 && ulBytes < 40_000_000) {
                    os.write(chunk); ulBytes += chunk.size
                }
            }
            val el = (System.nanoTime() - start) / 1_000_000
            try { u.responseCode } catch (_: Exception) { }
            ul = ulBytes * 8f / el.coerceAtLeast(1) / 1000f
            log("Upload ${"%.1f".format(ul)} Mbps")
        } catch (e: Exception) {
            err = e.message ?: e.javaClass.simpleName
            log("Speed test error: $err")
        }
        _state.update {
            it.copy(speed = SpeedResult(System.currentTimeMillis(), dl, ul, dlBytes / 1e6f, ulBytes / 1e6f, radioContext, err, bwMhz, rsrq, cell))
        }
        end()
    }
}
