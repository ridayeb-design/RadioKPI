package com.radiokpi.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.radiokpi.app.net.NetUi
import com.radiokpi.app.radio.Grade

data class NetActions(
    val onRefresh: () -> Unit,
    val onDns: () -> Unit,
    val onLatency: () -> Unit,
    val onSpeed: () -> Unit
)

private fun msColor(v: Long?): androidx.compose.ui.graphics.Color = when {
    v == null -> C.grade(Grade.BAD)
    v <= 30 -> C.grade(Grade.EXCELLENT)
    v <= 60 -> C.grade(Grade.GOOD)
    v <= 120 -> C.grade(Grade.FAIR)
    else -> C.grade(Grade.POOR)
}

@Composable
fun NetworkTab(n: NetUi, a: NetActions) {
    val link = n.link

    // ---- Link / IP config
    Panel(title = "Data connection", trailing = link?.transport) {
        if (link == null) {
            Text("No active data connection.", color = C.Muted, fontSize = 13.sp)
        } else {
            if (!link.cellular) {
                Text("You're on ${link.transport}. Turn Wi-Fi off to test the mobile network.",
                    color = C.grade(Grade.FAIR), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
            }
            InfoGrid(
                listOf(
                    "Interface" to link.iface,
                    "IP stack" to link.stack,
                    "IPv4" to link.ipv4.firstOrNull(),
                    "CGNAT" to if (link.ipv4.isEmpty()) "—" else if (link.cgnat) "Yes (private IP)" else "No (public IP)",
                    "MTU" to link.mtu?.toString(),
                    "Private DNS" to link.privateDns,
                    "Validated" to if (link.validated) "Yes" else "No (captive/blocked?)",
                    "Est. DL / UL" to listOf(link.downKbps, link.upKbps).joinToString(" / ") { it?.let { k -> "${k / 1000} Mbps" } ?: "—" }
                ),
                cols = 2
            )
            if (link.ipv6.isNotEmpty()) InfoItem("IPv6", link.ipv6.first())
            InfoItem("DNS servers (from network)", link.dns.joinToString(", ").ifBlank { null })
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = a.onRefresh) { Text("Refresh", color = C.Text) }
    }

    // ---- Test buttons
    Panel(title = "Tests") {
        val busy = n.running != null
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = a.onDns, enabled = !busy,
                colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.Bg)) { Text("DNS", fontWeight = FontWeight.Bold) }
            Button(onClick = a.onLatency, enabled = !busy,
                colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.Bg)) { Text("Latency", fontWeight = FontWeight.Bold) }
            Button(onClick = a.onSpeed, enabled = !busy,
                colors = ButtonDefaults.buttonColors(containerColor = C.Accent2, contentColor = C.Bg)) { Text("Speed", fontWeight = FontWeight.Bold) }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            if (busy) "Running ${n.running}… ${n.progress ?: ""}"
            else "DNS: ~100 lookups on 4 resolvers. Latency: ping + HTTP. Speed: 10 s download + 8 s upload (can use 50–150 MB).",
            color = if (busy) C.Accent else C.Muted, fontSize = 12.sp
        )
    }

    // ---- DNS results
    n.dns?.let { d ->
        Panel(title = "DNS resolvers", trailing = "median cold / cached") {
            Row(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
                listOf("Resolver" to 2.2f, "Cold" to 1f, "Cached" to 1f, "OK" to 0.9f, "T/O" to 0.7f).forEach { (h, w) ->
                    Text(h, color = C.Muted, fontSize = 11.sp, modifier = Modifier.weight(w))
                }
            }
            d.resolvers.forEach { r ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    Column(Modifier.weight(2.2f)) {
                        Text(r.name, color = C.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(r.server, color = C.Muted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                    Text(r.medianColdMs?.let { "${it}ms" } ?: "—", color = msColor(r.medianColdMs), fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text(r.medianWarmMs?.let { "${it}ms" } ?: "—", color = msColor(r.medianWarmMs), fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text("%.0f%%".format(r.successPct), color = C.Text, fontSize = 13.sp, fontFamily = FontFamily.Monospace,
                        modifier = Modifier.weight(0.9f))
                    Text(r.timeouts.toString(), color = if (r.timeouts > 0) C.grade(Grade.POOR) else C.Muted, fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.7f))
                }
            }
            Spacer(Modifier.height(6.dp))
            InfoGrid(
                d.resolvers.filter { it.nxdomainHijack != null }.map {
                    "${it.name} NXDOMAIN" to if (it.nxdomainHijack == true) "HIJACKED" else "Clean"
                },
                cols = 2
            )
        }
        Panel(title = "DNS findings") {
            d.findings.forEach { FindingLine(it) }
        }
        Panel(title = "Lookup time per domain (cold, ms)") {
            val names = d.resolvers.map { it.name }
            Row(Modifier.fillMaxWidth()) {
                Text("Domain", color = C.Muted, fontSize = 10.sp, modifier = Modifier.weight(2f))
                names.forEach { nm -> Text(nm.replace("Network DNS", "Op").replace("System (Android)", "Sys").take(6),
                    color = C.Muted, fontSize = 10.sp, modifier = Modifier.weight(1f)) }
            }
            d.perDomain.forEach { (dom, m) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Text(dom, color = C.Text, fontSize = 12.sp, modifier = Modifier.weight(2f))
                    names.forEach { nm ->
                        val v = m[nm]
                        Text(v?.toString() ?: "✗", color = msColor(v), fontSize = 12.sp, fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }

    // ---- Latency
    if (n.pings.isNotEmpty()) {
        Panel(title = "Latency (RTT)") {
            n.pings.forEach { p ->
                Column(Modifier.padding(vertical = 5.dp)) {
                    Row {
                        Text(p.label, color = C.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text("${p.method} · ${p.target}", color = C.Muted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                    Text(
                        "avg ${p.avgMs?.let { "%.0f".format(it) } ?: "—"} ms · min ${p.minMs?.let { "%.0f".format(it) } ?: "—"} · " +
                            "max ${p.maxMs?.let { "%.0f".format(it) } ?: "—"} · jitter ${p.jitterMs?.let { "%.0f".format(it) } ?: "—"} · " +
                            "loss ${"%.0f".format(p.lossPct)}%",
                        color = msColor(p.avgMs?.toLong()), fontSize = 12.sp, fontFamily = FontFamily.Monospace
                    )
                }
            }
            if (n.pingFindings.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                n.pingFindings.forEach { FindingLine(it) }
            }
        }
    }

    // ---- HTTP
    if (n.http.isNotEmpty()) {
        Panel(title = "HTTP response time", trailing = "first / repeat") {
            n.http.forEach { h ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Text(h.url.removePrefix("https://").trimEnd('/'), color = C.Text, fontSize = 12.sp, modifier = Modifier.weight(2f))
                    Text(
                        if (h.error != null) h.error.take(24) else "${h.coldMs}ms / ${h.warmMs}ms · ${h.code}",
                        color = if (h.error != null) C.grade(Grade.BAD) else msColor(h.coldMs?.let { it / 4 }),
                        fontSize = 12.sp, fontFamily = FontFamily.Monospace
                    )
                }
            }
            Text("First request includes DNS + TCP + TLS handshake + TTFB; the repeat reuses the connection.",
                color = C.Muted, fontSize = 11.sp)
        }
    }

    // ---- Speed
    n.speed?.let { s ->
        Panel(title = "Throughput") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                KpiTile("Download", s.dlMbps?.let { "%.1f".format(it) } ?: "—", "Mbps · ${"%.0f".format(s.dlMB)} MB",
                    C.Accent, Modifier.weight(1f))
                KpiTile("Upload", s.ulMbps?.let { "%.1f".format(it) } ?: "—", "Mbps · ${"%.0f".format(s.ulMB)} MB",
                    C.Accent2, Modifier.weight(1f))
            }
            Spacer(Modifier.height(6.dp))
            Text("Radio during test: ${s.radio}", color = C.Muted, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            s.error?.let { Text("Error: $it", color = C.grade(Grade.BAD), fontSize = 12.sp) }
        }
    }

    if (n.log.isNotEmpty()) {
        Panel(title = "Test log") {
            n.log.takeLast(12).forEach { Text(it, color = C.Muted, fontSize = 11.sp, fontFamily = FontFamily.Monospace) }
        }
    }
}

@Composable
private fun FindingLine(t: String) {
    Row(Modifier.padding(vertical = 3.dp)) {
        Text("•", color = C.Accent, fontSize = 13.sp)
        Spacer(Modifier.width(8.dp))
        Text(t, color = C.Text, fontSize = 13.sp)
    }
}
