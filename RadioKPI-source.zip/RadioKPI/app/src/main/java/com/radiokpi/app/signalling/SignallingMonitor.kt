package com.radiokpi.app.signalling

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.telephony.PhoneStateListener
import android.telephony.ServiceState
import android.telephony.TelephonyCallback
import android.telephony.TelephonyDisplayInfo
import android.telephony.TelephonyManager
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat

/**
 * Listens to Android telephony callbacks (service state, data connection, data activity,
 * display info, call state) and turns them into signalling events.
 */
class SignallingMonitor(private val context: Context, private val emit: (SigEvent) -> Unit) {

    // Listen on the data SIM only, so the second SIM's events don't appear in the log.
    private var tm: TelephonyManager = com.radiokpi.app.radio.DataSim.manager(context)
    private var callback: Any? = null
    private var legacy: PhoneStateListener? = null

    // ---- state
    @Volatile var rrc: RrcEstimate = RrcEstimate.UNKNOWN
        private set
    @Volatile var dormantSeen = false
        private set
    private var rrcSince = System.currentTimeMillis()
    var connectedMs = 0L
        private set
    var idleMs = 0L
        private set

    private var lastService: String? = null
    private var lastData: Int? = null
    private var lastDisplay: Int? = null
    private var lastCall = 0

    fun rrcTimes(now: Long): Pair<Long, Long> {
        val extra = now - rrcSince
        return when (rrc) {
            RrcEstimate.CONNECTED -> (connectedMs + extra) to idleMs
            RrcEstimate.IDLE -> connectedMs to (idleMs + extra)
            RrcEstimate.UNKNOWN -> connectedMs to idleMs
        }
    }

    fun resetCounters() {
        connectedMs = 0; idleMs = 0; rrcSince = System.currentTimeMillis()
    }

    fun start() {
        if (callback != null || legacy != null) return
        tm = com.radiokpi.app.radio.DataSim.manager(context)
        try {
            if (Build.VERSION.SDK_INT >= 31) startModern() else startLegacy()
        } catch (_: SecurityException) {
        } catch (_: Exception) {
        }
    }

    fun stop() {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                (callback as? TelephonyCallback)?.let { tm.unregisterTelephonyCallback(it) }
            }
            @Suppress("DEPRECATION")
            legacy?.let { tm.listen(it, PhoneStateListener.LISTEN_NONE) }
        } catch (_: Exception) {
        }
        callback = null
        legacy = null
    }

    // ---------------------------------------------------------------- handlers

    private fun onService(ss: ServiceState) {
        val state = ss.state
        val plmn = ss.operatorNumeric ?: ""
        val name = ss.operatorAlphaLong ?: ""
        val roaming = ss.roaming
        val chan = if (Build.VERSION.SDK_INT >= 28) ss.channelNumber else -1
        val duplex = if (Build.VERSION.SDK_INT >= 28) TelephonyNames.duplex(ss.duplexMode) else "?"
        val bws = if (Build.VERSION.SDK_INT >= 28) ss.cellBandwidths.filter { it > 0 } else emptyList()
        val sig = "$state|$plmn|$roaming"
        if (sig == lastService) return
        val prev = lastService
        lastService = sig
        val type = when (state) {
            0 -> SigType.IN_SERVICE
            1 -> SigType.OUT_OF_SERVICE
            2 -> SigType.EMERGENCY_ONLY
            else -> SigType.OUT_OF_SERVICE
        }
        val parts = mutableListOf(TelephonyNames.serviceState(state))
        if (plmn.isNotBlank()) parts += "PLMN $plmn ${name.trim()}".trim()
        if (roaming) parts += "ROAMING"
        if (chan > 0) parts += "channel $chan $duplex"
        if (bws.isNotEmpty()) parts += "${bws.size}CC ${bws.sum() / 1000} MHz"
        val samePrevState = prev?.substringBefore('|') == state.toString()
        emit(SigEvent(System.currentTimeMillis(), if (samePrevState) SigType.PLMN_CHANGE else type, parts.joinToString(" · ")))
    }

    private fun onData(state: Int, networkType: Int) {
        if (state == lastData) return
        lastData = state
        val type = when (state) {
            2 -> SigType.BEARER_CONNECTED
            3 -> SigType.BEARER_SUSPENDED
            0, 4 -> SigType.BEARER_DISCONNECTED
            else -> SigType.BEARER_CONNECTING
        }
        val hint = when (state) {
            3 -> " (typical during CSFB/2G-3G voice call or RAT change)"
            else -> ""
        }
        emit(SigEvent(System.currentTimeMillis(), type,
            "Data ${TelephonyNames.dataState(state)} on network type $networkType$hint"))
    }

    private fun onActivity(direction: Int) {
        val next = when (direction) {
            4 -> RrcEstimate.IDLE
            1, 2, 3 -> RrcEstimate.CONNECTED
            else -> return // NONE: can't tell (connected without traffic, or idle)
        }
        if (direction == 4) dormantSeen = true
        if (next == rrc) return
        val now = System.currentTimeMillis()
        when (rrc) {
            RrcEstimate.CONNECTED -> connectedMs += now - rrcSince
            RrcEstimate.IDLE -> idleMs += now - rrcSince
            RrcEstimate.UNKNOWN -> {}
        }
        rrcSince = now
        rrc = next
        emit(SigEvent(now,
            if (next == RrcEstimate.CONNECTED) SigType.RRC_CONNECTED else SigType.RRC_IDLE,
            "Data activity ${TelephonyNames.dataActivity(direction)}" +
                if (next == RrcEstimate.IDLE) " (inactivity timer expired → RRC release)" else " (traffic → RRC connection)"))
    }

    private fun onDisplay(override: Int, networkType: Int) {
        if (override == lastDisplay) return
        lastDisplay = override
        emit(SigEvent(System.currentTimeMillis(), SigType.DISPLAY,
            "${TelephonyNames.displayOverride(override)} (network type $networkType)"))
    }

    private fun onCall(state: Int) {
        if (state == lastCall) return
        val prev = lastCall
        lastCall = state
        val now = System.currentTimeMillis()
        when (state) {
            1 -> emit(SigEvent(now, SigType.CALL_MT, "Ringing" +
                if (rrc == RrcEstimate.IDLE) " (UE was idle: paging → RRC setup → INVITE)" else ""))
            2 -> emit(SigEvent(now, SigType.CALL_ACTIVE, if (prev == 1) "Answered (MT)" else "Off-hook (MO or answered)"))
            0 -> emit(SigEvent(now, SigType.CALL_END, "Call released"))
        }
    }

    // ---------------------------------------------------------------- registration

    @SuppressLint("MissingPermission")
    @RequiresApi(31)
    private fun startModern() {
        val cb = Modern()
        tm.registerTelephonyCallback(ContextCompat.getMainExecutor(context), cb)
        callback = cb
    }

    @RequiresApi(31)
    private inner class Modern : TelephonyCallback(),
        TelephonyCallback.ServiceStateListener,
        TelephonyCallback.DataConnectionStateListener,
        TelephonyCallback.DataActivityListener,
        TelephonyCallback.DisplayInfoListener,
        TelephonyCallback.CallStateListener {
        override fun onServiceStateChanged(serviceState: ServiceState) = onService(serviceState)
        override fun onDataConnectionStateChanged(state: Int, networkType: Int) = onData(state, networkType)
        override fun onDataActivity(direction: Int) = onActivity(direction)
        override fun onDisplayInfoChanged(telephonyDisplayInfo: TelephonyDisplayInfo) =
            onDisplay(telephonyDisplayInfo.overrideNetworkType, telephonyDisplayInfo.networkType)
        override fun onCallStateChanged(state: Int) = onCall(state)
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    private fun startLegacy() {
        val l = object : PhoneStateListener() {
            @Deprecated("Deprecated in Java")
            override fun onServiceStateChanged(serviceState: ServiceState?) {
                serviceState?.let { onService(it) }
            }
            @Deprecated("Deprecated in Java")
            override fun onDataConnectionStateChanged(state: Int, networkType: Int) = onData(state, networkType)
            @Deprecated("Deprecated in Java")
            override fun onDataActivity(direction: Int) = onActivity(direction)
            @Deprecated("Deprecated in Java")
            override fun onCallStateChanged(state: Int, phoneNumber: String?) = onCall(state)
        }
        tm.listen(
            l,
            PhoneStateListener.LISTEN_SERVICE_STATE or
                PhoneStateListener.LISTEN_DATA_CONNECTION_STATE or
                PhoneStateListener.LISTEN_DATA_ACTIVITY or
                PhoneStateListener.LISTEN_CALL_STATE
        )
        legacy = l
    }
}
