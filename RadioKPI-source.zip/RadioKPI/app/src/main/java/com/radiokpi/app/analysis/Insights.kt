package com.radiokpi.app.analysis

import com.radiokpi.app.radio.CellStat
import com.radiokpi.app.radio.SessionKpis
import java.util.Locale

data class HealthScore(
    val total: Int,
    val coverage: Float,      // out of 40
    val quality: Float,       // out of 30
    val availability: Float,  // out of 20
    val stability: Float,     // out of 10
    val verdict: String
)

enum class FindingLevel { GOOD, INFO, WARN, BAD }

data class Finding(val level: FindingLevel, val title: String, val text: String)

data class WorstCell(val stat: CellStat, val anomalies: Int)

/** Turns session KPIs + anomalies into a score, findings and recommendations. */
object Insights {

    const val MIN_SAMPLES = 10

    private fun f1(v: Float) = String.format(Locale.US, "%.1f", v)
    private fun f0(v: Float) = String.format(Locale.US, "%.0f", v)

    fun hours(k: SessionKpis, now: Long): Float = ((now - k.startedAt) / 3_600_000f).coerceAtLeast(1f / 60f)

    fun score(k: SessionKpis, events: List<Anomaly>, now: Long): HealthScore? {
        if (k.samples < MIN_SAMPLES) return null
        val coverage = k.goodCoveragePct * 0.40f
        val quality = if (k.sinrCount > 0) k.goodSinrPct * 0.30f else k.goodCoveragePct * 0.30f
        val availability = k.availabilityPct * 0.20f
        val penaltyPerHour = events.sumOf { it.type.severity.weight.toDouble() }.toFloat() / hours(k, now)
        val stability = (10f - penaltyPerHour).coerceIn(0f, 10f)
        val total = (coverage + quality + availability + stability).toInt().coerceIn(0, 100)
        val verdict = when {
            total >= 85 -> "Excellent"
            total >= 70 -> "Good"
            total >= 55 -> "Fair"
            total >= 40 -> "Poor"
            else -> "Bad"
        }
        return HealthScore(total, coverage, quality, availability, stability, verdict)
    }

    fun countsByType(events: List<Anomaly>): List<Pair<AnomalyType, Int>> =
        events.groupingBy { it.type }.eachCount().entries
            .sortedWith(compareBy<Map.Entry<AnomalyType, Int>> { it.key.severity.ordinal }.thenByDescending { it.value })
            .map { it.key to it.value }

    fun countsBySeverity(events: List<Anomaly>): Map<Severity, Int> =
        Severity.values().associateWith { sev -> events.count { it.type.severity == sev } }

    private fun topCell(events: List<Anomaly>, type: AnomalyType): Pair<String, Int>? =
        events.filter { it.type == type && it.cell != null }
            .groupingBy { it.cell!! }.eachCount()
            .maxByOrNull { it.value }?.let { it.key to it.value }

    fun worstCells(k: SessionKpis, events: List<Anomaly>, limit: Int = 5): List<WorstCell> {
        val perCell = events.filter { it.cell != null }.groupingBy { it.cell!! }.eachCount()
        return k.cellStats.values
            .filter { it.samples >= 3 }
            .sortedWith(
                compareByDescending<CellStat> { perCell[it.label] ?: 0 }
                    .thenBy { it.avgLevel ?: 0f }
            )
            .take(limit)
            .map { WorstCell(it, perCell[it.label] ?: 0) }
    }

    fun findings(k: SessionKpis, events: List<Anomaly>): List<Finding> {
        if (k.samples < MIN_SAMPLES) return emptyList()
        val out = mutableListOf<Finding>()
        val count = events.groupingBy { it.type }.eachCount()
        fun n(t: AnomalyType) = count[t] ?: 0
        fun where(t: AnomalyType) = topCell(events, t)?.let { " Most affected: ${it.first} (${it.second}×)." } ?: ""

        // Availability
        if (k.noServicePct > 0.5f) {
            out += Finding(FindingLevel.BAD, "Service interruptions",
                "No service ${f1(k.noServicePct)}% of the time (${n(AnomalyType.NO_SERVICE)} event(s)). " +
                    AnomalyType.NO_SERVICE.advice)
        }

        // Coverage
        when {
            k.badCoveragePct >= 10f -> out += Finding(FindingLevel.BAD, "Weak coverage",
                "Level was bad on ${f1(k.badCoveragePct)}% of samples (good on ${f1(k.goodCoveragePct)}%)." +
                    where(AnomalyType.WEAK_COVERAGE) + " " + AnomalyType.WEAK_COVERAGE.advice)
            k.goodCoveragePct < 90f -> out += Finding(FindingLevel.WARN, "Coverage could be better",
                "Good level on only ${f1(k.goodCoveragePct)}% of samples (target ≥ 90%)." + where(AnomalyType.WEAK_COVERAGE))
            else -> out += Finding(FindingLevel.GOOD, "Coverage OK",
                "Good level on ${f1(k.goodCoveragePct)}% of samples, average ${k.avgPrimary?.let { f0(it) } ?: "—"} dBm.")
        }

        // Quality / interference
        if (k.sinrCount > 0) {
            when {
                k.goodSinrPct < 40f -> out += Finding(FindingLevel.BAD, "Poor signal quality",
                    "SINR ≥ 13 dB only ${f1(k.goodSinrPct)}% of the time (average ${k.avgSinr?.let { f1(it) } ?: "—"} dB). " +
                        "Interference or heavy cell overlap is likely.")
                k.goodSinrPct < 65f -> out += Finding(FindingLevel.WARN, "Average signal quality",
                    "SINR ≥ 13 dB ${f1(k.goodSinrPct)}% of the time (average ${k.avgSinr?.let { f1(it) } ?: "—"} dB).")
                else -> out += Finding(FindingLevel.GOOD, "Signal quality OK",
                    "SINR ≥ 13 dB ${f1(k.goodSinrPct)}% of the time.")
            }
        }
        if (n(AnomalyType.INTERFERENCE) > 0) {
            out += Finding(FindingLevel.BAD, "Interference suspected",
                "${n(AnomalyType.INTERFERENCE)} period(s) with good level but bad quality." +
                    where(AnomalyType.INTERFERENCE) + " " + AnomalyType.INTERFERENCE.advice)
        }
        if (n(AnomalyType.NO_DOMINANT) > 0) {
            out += Finding(FindingLevel.WARN, "Pilot pollution",
                "${n(AnomalyType.NO_DOMINANT)} period(s) without a dominant cell." +
                    where(AnomalyType.NO_DOMINANT) + " " + AnomalyType.NO_DOMINANT.advice)
        }

        // Mobility
        val mobility = n(AnomalyType.PING_PONG) + n(AnomalyType.EXCESSIVE_HO)
        if (mobility > 0) {
            out += Finding(FindingLevel.WARN, "Unstable mobility",
                "${n(AnomalyType.PING_PONG)} ping-pong and ${n(AnomalyType.EXCESSIVE_HO)} excessive-handover event(s), " +
                    "${k.cellChanges} cell changes in total." + where(AnomalyType.PING_PONG) + " " + AnomalyType.PING_PONG.advice)
        }
        if (n(AnomalyType.MISSED_HO) > 0) {
            out += Finding(FindingLevel.BAD, "Missed handovers",
                "${n(AnomalyType.MISSED_HO)} time(s) a much stronger neighbour wasn't used." +
                    where(AnomalyType.MISSED_HO) + " " + AnomalyType.MISSED_HO.advice)
        }
        if (n(AnomalyType.OVERSHOOT) > 0) {
            out += Finding(FindingLevel.WARN, "Overshooting cell",
                "Served from far away ${n(AnomalyType.OVERSHOOT)} time(s)." + where(AnomalyType.OVERSHOOT) + " " +
                    AnomalyType.OVERSHOOT.advice)
        }

        // Technology
        if (n(AnomalyType.FALLBACK_LEGACY) > 0) {
            out += Finding(FindingLevel.BAD, "Fallback to 2G/3G",
                "${n(AnomalyType.FALLBACK_LEGACY)} fallback(s) from 4G/5G." + where(AnomalyType.FALLBACK_LEGACY) + " " +
                    AnomalyType.FALLBACK_LEGACY.advice)
        }
        val fiveGSeen = k.fiveG > 0
        if (fiveGSeen) {
            if (k.fiveGPct < 50f) {
                out += Finding(FindingLevel.INFO, "Limited 5G time",
                    "On 5G ${f1(k.fiveGPct)}% of the time, with ${n(AnomalyType.FIVE_G_DROP)} 5G drop(s).")
            } else {
                out += Finding(FindingLevel.GOOD, "Good 5G presence", "On 5G ${f1(k.fiveGPct)}% of the time.")
            }
        }
        if (k.caSamples > 0 && k.caPct < 30f) {
            out += Finding(FindingLevel.INFO, "Little carrier aggregation",
                "Carrier aggregation active only ${f1(k.caPct)}% of the time: peak speeds will be limited.")
        }

        // Data quality
        if (n(AnomalyType.STALE_DATA) > 0) {
            out += Finding(FindingLevel.INFO, "Data may be cached", AnomalyType.STALE_DATA.advice)
        }

        if (out.none { it.level == FindingLevel.BAD || it.level == FindingLevel.WARN }) {
            out += Finding(FindingLevel.GOOD, "No major issues", "No significant radio problems detected in this session.")
        }
        return out.sortedBy {
            when (it.level) { FindingLevel.BAD -> 0; FindingLevel.WARN -> 1; FindingLevel.INFO -> 2; FindingLevel.GOOD -> 3 }
        }
    }
}
