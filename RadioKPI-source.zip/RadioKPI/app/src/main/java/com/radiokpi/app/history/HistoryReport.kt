package com.radiokpi.app.history

import com.radiokpi.app.analysis.AnomalyType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Small SVG chart renderer for the HTML history report. */
object Svg {
    private const val W = 860
    private const val PL = 44   // left padding for y labels
    private const val PR = 10
    private const val PT = 10
    private const val PB = 26   // bottom padding for x labels

    private fun f(v: Float) = String.format(Locale.US, "%.1f", v)

    private fun timeFmt(spanMs: Long) = SimpleDateFormat(if (spanMs <= 86_400_000L) "HH:mm" else "dd/MM HH'h'", Locale.US)

    private fun frame(sb: StringBuilder, h: Int, from: Long, to: Long, yMin: Float, yMax: Float, yTicks: Int = 4) {
        val ph = h - PT - PB
        for (i in 0..yTicks) {
            val v = yMin + (yMax - yMin) * i / yTicks
            val y = PT + ph - ph * i / yTicks
            sb.append("<line x1='$PL' x2='${W - PR}' y1='$y' y2='$y' stroke='#e3e6ea' stroke-width='1'/>")
            sb.append("<text x='${PL - 6}' y='${y + 4}' font-size='11' text-anchor='end' fill='#5b6570'>${v.toInt()}</text>")
        }
        val tf = timeFmt(to - from)
        for (i in 0..4) {
            val t = from + (to - from) * i / 4
            val x = PL + (W - PL - PR) * i / 4
            val anchor = when (i) { 0 -> "start"; 4 -> "end"; else -> "middle" }
            sb.append("<text x='$x' y='${h - 6}' font-size='11' text-anchor='$anchor' fill='#5b6570'>${tf.format(Date(t))}</text>")
        }
    }

    private fun open(h: Int) = StringBuilder("<svg viewBox='0 0 $W $h' width='100%' xmlns='http://www.w3.org/2000/svg' style='background:#fff;border:1px solid #e3e6ea;border-radius:10px'>")

    /**
     * Line chart with an optional min–max envelope and coloured threshold zones.
     * [zones] = (lowerBound, colour) from the top (best) down.
     */
    fun line(
        from: Long, to: Long, gapMs: Long,
        points: List<Pair<Long, Float?>>, envelope: List<Triple<Long, Float?, Float?>>?,
        yMin: Float, yMax: Float, zones: List<Pair<Float, String>>, color: String, h: Int = 220
    ): String {
        val sb = open(h)
        val pw = W - PL - PR
        val ph = h - PT - PB
        fun x(t: Long) = PL + pw * ((t - from).toFloat() / (to - from).coerceAtLeast(1))
        fun y(v: Float) = PT + ph - ph * ((v.coerceIn(yMin, yMax) - yMin) / (yMax - yMin))
        var top = yMax
        zones.forEach { (lower, c) ->
            sb.append("<rect x='$PL' y='${f(y(top))}' width='$pw' height='${f(y(lower) - y(top))}' fill='$c' fill-opacity='0.08'/>")
            top = lower
        }
        val span = yMax - yMin
        frame(sb, h, from, to, yMin, yMax, if (span % 20f == 0f && span >= 80f) 5 else 4)
        envelope?.let { env ->
            env.filter { it.second != null && it.third != null }.forEach { (t, lo, hi) ->
                sb.append("<line x1='${f(x(t))}' x2='${f(x(t))}' y1='${f(y(lo!!))}' y2='${f(y(hi!!))}' stroke='$color' stroke-opacity='0.25' stroke-width='3'/>")
            }
        }
        val path = StringBuilder()
        var prevT: Long? = null
        var prevV: Float? = null
        points.forEach { (t, v) ->
            if (v == null) return@forEach
            val pt = prevT
            val pv = prevV
            val gap = pt != null && t - pt > gapMs
            if (gap && pt != null && pv != null) {
                sb.append("<line x1='${f(x(pt))}' y1='${f(y(pv))}' x2='${f(x(t))}' y2='${f(y(v))}' stroke='#9aa3ad' stroke-width='1.5' stroke-dasharray='6 6'/>")
            }
            val cmd = if (pt == null || gap) "M" else "L"
            path.append("$cmd${f(x(t))},${f(y(v))} ")
            prevT = t
            prevV = v
        }
        sb.append("<path d='$path' fill='none' stroke='$color' stroke-width='2' stroke-linejoin='round' stroke-linecap='round'/>")
        sb.append("</svg>")
        return sb.toString()
    }

    fun stacked(from: Long, to: Long, bucketMs: Long, buckets: List<TechBucket>, h: Int = 180): String {
        val sb = open(h)
        val pw = W - PL - PR
        val ph = h - PT - PB
        frame(sb, h, from, to, 0f, 100f)
        val bw = (pw * bucketMs.toFloat() / (to - from).coerceAtLeast(1)).coerceAtLeast(1.5f)
        buckets.forEach { b ->
            val x = PL + pw * ((b.t - from).toFloat() / (to - from).coerceAtLeast(1))
            var acc = 0f
            b.counts.entries.sortedBy { it.key }.forEach { (tech, n) ->
                val frac = n.toFloat() / b.total.coerceAtLeast(1)
                val yTop = PT + ph - ph * (acc + frac)
                sb.append("<rect x='${f(x)}' y='${f(yTop)}' width='${f(bw * 0.9f)}' height='${f(ph * frac)}' fill='${TechColors.hex(tech)}'/>")
                acc += frac
            }
        }
        sb.append("</svg>")
        return sb.toString()
    }

    fun bars(from: Long, to: Long, bucketMs: Long, counts: List<CountBucket>, color: String, h: Int = 150): String {
        val raw = (counts.maxOfOrNull { it.count } ?: 0).coerceAtLeast(4)
        val max = (((raw + 3) / 4) * 4).toFloat()
        val sb = open(h)
        val pw = W - PL - PR
        val ph = h - PT - PB
        frame(sb, h, from, to, 0f, max)
        val bw = (pw * bucketMs.toFloat() / (to - from).coerceAtLeast(1)).coerceAtLeast(2f)
        counts.forEach { c ->
            val x = PL + pw * ((c.t - from).toFloat() / (to - from).coerceAtLeast(1))
            val hh = ph * c.count / max
            sb.append("<rect x='${f(x)}' y='${f(PT + ph - hh)}' width='${f(bw * 0.85f)}' height='${f(hh)}' fill='$color'/>")
        }
        sb.append("</svg>")
        return sb.toString()
    }

    /** 24 bars (hour of day) coloured by value. */
    fun hours(hours: List<HourProfile>, value: (HourProfile) -> Float?, yMin: Float, yMax: Float, colorFor: (Float) -> String, h: Int = 170): String {
        val sb = open(h)
        val pw = W - PL - PR
        val ph = h - PT - PB
        val ticks = 4
        for (i in 0..ticks) {
            val v = yMin + (yMax - yMin) * i / ticks
            val y = PT + ph - ph * i / ticks
            sb.append("<line x1='$PL' x2='${W - PR}' y1='$y' y2='$y' stroke='#e3e6ea'/>")
            sb.append("<text x='${PL - 6}' y='${y + 4}' font-size='11' text-anchor='end' fill='#5b6570'>${v.toInt()}</text>")
        }
        val slot = pw / 24f
        for (hr in 0 until 24) {
            val x = PL + slot * hr
            if (hr % 3 == 0) sb.append("<text x='${f(x + slot / 2)}' y='${h - 6}' font-size='11' text-anchor='middle' fill='#5b6570'>${hr}h</text>")
            val p = hours.firstOrNull { it.hour == hr } ?: continue
            val v = value(p) ?: continue
            val frac = ((v - yMin) / (yMax - yMin)).coerceIn(0.02f, 1f)
            sb.append("<rect x='${f(x + 2)}' y='${f(PT + ph - ph * frac)}' width='${f(slot - 4)}' height='${f(ph * frac)}' fill='${colorFor(v)}' rx='2'/>")
        }
        sb.append("</svg>")
        return sb.toString()
    }
}

object HistoryReport {

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    private fun f1(v: Float?) = v?.let { String.format(Locale.US, "%.1f", it) } ?: "—"
    private fun pct(v: Float?) = v?.let { String.format(Locale.US, "%.1f%%", it) } ?: "—"

    fun levelColor(v: Float) = when {
        v >= -80 -> "#22C55E"; v >= -90 -> "#84CC16"; v >= -100 -> "#EAB308"; v >= -110 -> "#F97316"; else -> "#EF4444"
    }

    fun sinrColor(v: Float) = when {
        v >= 20 -> "#22C55E"; v >= 13 -> "#84CC16"; v >= 0 -> "#EAB308"; else -> "#F97316"
    }

    val LEVEL_ZONES = listOf(-80f to "#22C55E", -90f to "#84CC16", -100f to "#EAB308", -110f to "#F97316", -140f to "#EF4444")
    val SINR_ZONES = listOf(20f to "#22C55E", 13f to "#84CC16", 0f to "#EAB308", -10f to "#F97316")

    fun anomalyTitle(name: String) = try { AnomalyType.valueOf(name).title } catch (_: Exception) { name }

    fun build(d: HistoryData, device: String, operator: String): String {
        val df = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        val s = d.summary
        val gap = d.bucketMs * 3
        val sb = StringBuilder()
        sb.append(
            """<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Radio KPI history ${esc(d.range.label)}</title><style>
body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;margin:0;background:#f5f6f8;color:#1b1f24}
main{max-width:900px;margin:0 auto;padding:20px}h1{font-size:24px;margin:0 0 4px}
h2{font-size:17px;margin:26px 0 10px;border-bottom:2px solid #e3e6ea;padding-bottom:6px}.sub{color:#5b6570;font-size:13px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}
.card{background:#fff;border:1px solid #e3e6ea;border-radius:12px;padding:12px}.l{font-size:12px;color:#5b6570}
.v{font-size:21px;font-weight:700;font-family:ui-monospace,monospace}
table{width:100%;border-collapse:collapse;font-size:13px;background:#fff}th,td{text-align:left;padding:7px 8px;border-bottom:1px solid #eceef1}
th{background:#f0f2f5}td.n{font-family:ui-monospace,monospace}.lg{display:flex;flex-wrap:wrap;gap:12px;font-size:12px;margin:6px 0}
.lg i{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:4px;vertical-align:middle}
footer{color:#8a939c;font-size:11px;margin:30px 0 10px}@media print{body{background:#fff}svg,table{break-inside:avoid}}
</style></head><body><main>"""
        )
        sb.append("<h1>Radio KPI history · ${esc(d.range.label)}</h1>")
        sb.append("<div class=\"sub\">${df.format(Date(d.from))} → ${df.format(Date(d.to))} · ${s.samples} samples · ${esc(device)} · ${esc(operator)}</div>")

        sb.append("<h2>Summary</h2><div class=\"grid\">")
        fun kpi(l: String, v: String) = sb.append("<div class=\"card\"><div class=\"l\">${esc(l)}</div><div class=\"v\">${esc(v)}</div></div>")
        kpi("Availability", pct(s.availabilityPct))
        kpi("Avg level", "${f1(s.levelAvg)} dBm")
        kpi("Min / max", "${s.levelMin ?: "—"} / ${s.levelMax ?: "—"}")
        kpi("Good coverage", pct(s.goodPct))
        kpi("Avg SINR", "${f1(s.sinrAvg)} dB")
        kpi("SINR ≥ 13 dB", pct(s.sinrGoodPct))
        kpi("Avg RSRQ", "${f1(s.rsrqAvg)} dB")
        kpi("5G time", pct(s.fiveGPct))
        kpi("CA time", pct(s.caPct))
        kpi("Anomalies", s.anomalies.toString())
        kpi("Cell changes", s.cellChanges.toString())
        kpi("Cells seen", s.uniqueCells.toString())
        sb.append("</div>")

        if (d.buckets.isEmpty()) {
            sb.append("<p>No data stored in this period.</p></main></body></html>")
            return sb.toString()
        }

        sb.append("<h2>Signal level (avg, with min–max)</h2>")
        sb.append(Svg.line(d.from, d.to, gap, d.buckets.map { it.t to it.levelAvg },
            d.buckets.map { Triple(it.t, it.levelMin?.toFloat(), it.levelMax?.toFloat()) },
            -140f, -40f, LEVEL_ZONES, "#0891B2"))
        if (d.buckets.any { it.sinrAvg != null }) {
            sb.append("<h2>SINR (4G)</h2>")
            sb.append(Svg.line(d.from, d.to, gap, d.buckets.map { it.t to it.sinrAvg }, null, -10f, 30f, SINR_ZONES, "#7C3AED"))
        } else {
            sb.append("<h2>SINR (4G)</h2><p class=\"sub\">Not reported by this phone; 4G quality is judged from RSRQ.</p>")
        }
        if (d.buckets.any { it.nrSinrAvg != null }) {
            sb.append("<h2>5G NR SS-SINR</h2>")
            sb.append(Svg.line(d.from, d.to, gap, d.buckets.map { it.t to it.nrSinrAvg }, null, -10f, 30f, SINR_ZONES, "#7C3AED"))
        }
        if (d.buckets.any { it.rsrqAvg != null }) {
            sb.append("<h2>RSRQ</h2>")
            sb.append(Svg.line(d.from, d.to, gap, d.buckets.map { it.t to it.rsrqAvg }, null, -25f, -5f,
                listOf(-10f to "#22C55E", -15f to "#84CC16", -20f to "#EAB308", -25f to "#F97316"), "#0E7490", 180))
        }
        sb.append("<h2>Good coverage share per period (%)</h2>")
        sb.append(Svg.line(d.from, d.to, gap, d.buckets.map { it.t to it.goodPct }, null, 0f, 100f, emptyList(), "#16A34A", 160))

        sb.append("<h2>Technology share</h2><div class=\"lg\">")
        d.techTotals.entries.sortedByDescending { it.value }.forEach { (t, n) ->
            sb.append("<span><i style=\"background:${TechColors.hex(t)}\"></i>${esc(t)} ${pct(n * 100f / s.samples.coerceAtLeast(1))}</span>")
        }
        sb.append("</div>")
        sb.append(Svg.stacked(d.from, d.to, d.bucketMs, d.tech))

        sb.append("<h2>Anomalies per period</h2>")
        sb.append(Svg.bars(d.from, d.to, d.bucketMs, d.anomalyBuckets, "#F97316"))
        if (d.anomalyTypes.isNotEmpty()) {
            sb.append("<table><tr><th>Anomaly</th><th>Count</th></tr>")
            d.anomalyTypes.forEach { (t, n) -> sb.append("<tr><td>${esc(anomalyTitle(t))}</td><td class=\"n\">$n</td></tr>") }
            sb.append("</table>")
        }
        sb.append("<h2>Cell changes per period (handovers + reselections)</h2>")
        sb.append(Svg.bars(d.from, d.to, d.bucketMs, d.mobilityBuckets, "#2563EB"))

        if (d.hours.size >= 2) {
            sb.append("<h2>Hour-of-day profile</h2><div class=\"sub\">Average per hour across the period. Quality dips at busy hours point to load/interference.</div>")
            sb.append("<h3 style=\"font-size:14px\">Level (dBm)</h3>")
            sb.append(Svg.hours(d.hours, { it.levelAvg }, -130f, -50f, ::levelColor))
            if (d.hours.any { it.sinrAvg != null }) {
                sb.append("<h3 style=\"font-size:14px\">SINR (dB)</h3>")
                sb.append(Svg.hours(d.hours, { it.sinrAvg }, -10f, 30f, ::sinrColor))
            }
        }

        if (d.bandTotals.isNotEmpty()) {
            sb.append("<h2>Bands</h2><table><tr><th>Band</th><th>Share</th></tr>")
            d.bandTotals.forEach { (b, n) ->
                sb.append("<tr><td>${esc(b)}</td><td class=\"n\">${pct(n * 100f / s.samples.coerceAtLeast(1))}</td></tr>")
            }
            sb.append("</table>")
        }
        if (d.cells.isNotEmpty()) {
            sb.append("<h2>Most used cells</h2><table><tr><th>Cell</th><th>Samples</th><th>Avg level</th><th>Avg SINR</th></tr>")
            d.cells.forEach { c ->
                sb.append("<tr><td>${esc(c.cell)}</td><td class=\"n\">${c.samples}</td><td class=\"n\">${f1(c.levelAvg)}</td><td class=\"n\">${f1(c.sinrAvg)}</td></tr>")
            }
            sb.append("</table>")
        }
        sb.append("<footer>Generated by Radio KPI. Data stored on the phone for 14 days.</footer></main></body></html>")
        return sb.toString()
    }
}
