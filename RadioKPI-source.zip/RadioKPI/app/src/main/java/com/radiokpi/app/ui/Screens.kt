package com.radiokpi.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.radiokpi.app.UiState
import com.radiokpi.app.radio.CellMeasurement
import com.radiokpi.app.radio.Grade
import com.radiokpi.app.radio.RadioSnapshot
import com.radiokpi.app.radio.Rat
import com.radiokpi.app.radio.Thresholds
import java.util.concurrent.TimeUnit

data class Actions(
    val onToggleRun: () -> Unit,
    val onToggleLog: () -> Unit,
    val onShareLog: () -> Unit,
    val onReset: () -> Unit,
    val onInterval: (Long) -> Unit,
    val onOpenLocationSettings: () -> Unit
)

@Composable
fun RadioApp(state: UiState, actions: Actions) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Header(state, actions)
        TabRow(
            selectedTabIndex = tab,
            containerColor = C.Bg,
            contentColor = C.Accent,
            indicator = { pos ->
                TabRowDefaults.SecondaryIndicator(Modifier.tabIndicatorOffset(pos[tab]), color = C.Accent)
            }
        ) {
            listOf("Dashboard", "Cells", "KPIs").forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i },
                    text = { Text(t, color = if (tab == i) C.Accent else C.Muted, fontWeight = FontWeight.SemiBold) })
            }
        }
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Banners(state, actions)
            when (tab) {
                0 -> DashboardTab(state)
                1 -> CellsTab(state.snapshot)
                else -> KpiTab(state, actions)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun Header(state: UiState, a: Actions) {
    val s = state.snapshot
    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Radio KPI", color = C.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Dot(if (state.running) C.grade(Grade.EXCELLENT) else C.Muted)
                    Spacer(Modifier.width(6.dp))
                    Text(
                        (s?.operator ?: "—") + " · " + (s?.networkType ?: "—"),
                        color = C.Muted, fontSize = 13.sp
                    )
                }
            }
            Badge(s?.techLabel ?: "—", techColor(s))
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = a.onToggleRun,
                colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.Bg)
            ) { Text(if (state.running) "Pause" else "Start", fontWeight = FontWeight.Bold) }
            Button(
                onClick = a.onToggleLog,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (state.logging) C.Rec else C.Surface2,
                    contentColor = C.Text
                )
            ) { Text(if (state.logging) "● REC ${state.logRows}" else "Log CSV") }
            if (state.logFile != null) {
                OutlinedButton(onClick = a.onShareLog) { Text("Share", color = C.Text) }
            }
        }
    }
}

private fun techColor(s: RadioSnapshot?): Color {
    val rat = s?.serving?.rat ?: return C.Muted
    return when {
        s.isNsa || rat == Rat.NR -> C.Accent2
        rat == Rat.LTE -> C.Accent
        rat == Rat.WCDMA -> C.grade(Grade.FAIR)
        else -> C.grade(Grade.POOR)
    }
}

@Composable
private fun Banners(state: UiState, a: Actions) {
    state.error?.let { Banner(it, C.Rec) }
    if (state.locationOff) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                .background(C.grade(Grade.FAIR).copy(alpha = 0.15f)).padding(12.dp)
        ) {
            Text("Location is off. Android hides cell info until Location is turned on.",
                color = C.grade(Grade.FAIR), fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            OutlinedButton(onClick = a.onOpenLocationSettings) { Text("Open location settings", color = C.Text) }
        }
    }
}

@Composable
private fun Banner(text: String, color: Color) {
    Text(
        text, color = color, fontSize = 13.sp,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.15f)).padding(12.dp)
    )
}

// ---------------------------------------------------------------- Dashboard

@Composable
private fun DashboardTab(state: UiState) {
    val s: RadioSnapshot? = state.snapshot
    if (s == null) {
        Panel(title = "Serving cell") {
            Text("Waiting for first measurement…", color = C.Muted, fontSize = 14.sp)
        }
        return
    }
    val c: CellMeasurement? = s.serving
    if (c == null) {
        Panel(title = "Serving cell") {
            Text("No registered cell reported (no service, airplane mode or SIM missing).",
                color = C.Muted, fontSize = 14.sp)
        }
        return
    }

    // Main metric tiles depend on the technology
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        val m = Modifier.weight(1f)
        when (c.rat) {
            Rat.LTE, Rat.NR -> {
                val p = if (c.rat == Rat.NR) "SS-" else ""
                MetricCard("${p}RSRP", c.rsrp, "dBm", Thresholds.rsrp(c.rsrp), -140, -44, m)
                MetricCard("${p}RSRQ", c.rsrq, "dB", Thresholds.rsrq(c.rsrq), -30, -3, m)
                MetricCard("${p}SINR", c.sinr, "dB", Thresholds.sinr(c.sinr), -10, 30, m)
            }
            Rat.WCDMA, Rat.TDSCDMA -> {
                MetricCard("RSCP", c.rscp, "dBm", Thresholds.rscp(c.rscp), -120, -25, m)
                MetricCard("Ec/No", c.ecno, "dB", Thresholds.ecno(c.ecno), -24, 0, m)
            }
            else -> {
                MetricCard("RSSI", c.rssi ?: c.dbm, "dBm", Thresholds.gsmRssi(c.rssi ?: c.dbm), -113, -51, m)
                MetricCard("Bars", c.level, "/4", Grade.NA, 0, 4, m)
            }
        }
    }

    // 5G NSA leg
    val nsa = s.nsa
    if (s.isNsa && nsa != null) {
        Panel(title = "5G NR leg (NSA)") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val m = Modifier.weight(1f)
                MetricCard("SS-RSRP", nsa.ssRsrp, "dBm", Thresholds.rsrp(nsa.ssRsrp), -140, -44, m)
                MetricCard("SS-RSRQ", nsa.ssRsrq, "dB", Thresholds.rsrq(nsa.ssRsrq), -30, -3, m)
                MetricCard("SS-SINR", nsa.ssSinr, "dB", Thresholds.sinr(nsa.ssSinr), -10, 30, m)
            }
        }
    }

    Panel(title = "Serving cell", trailing = c.rat.label) {
        InfoGrid(servingItems(c))
    }

    val primaryLabel = when (c.rat) {
        Rat.LTE -> "RSRP trend"; Rat.NR -> "SS-RSRP trend"
        Rat.WCDMA, Rat.TDSCDMA -> "RSCP trend"; else -> "RSSI trend"
    }
    TrendChart(
        primaryLabel, "dBm", state.history.map { it.primary }, -140f, -40f,
        bands = listOf(
            -80f to C.grade(Grade.EXCELLENT), -90f to C.grade(Grade.GOOD),
            -100f to C.grade(Grade.FAIR), -110f to C.grade(Grade.POOR), -140f to C.grade(Grade.BAD)
        ),
        lineColor = C.Accent
    )
    if (c.rat == Rat.LTE || c.rat == Rat.NR) {
        TrendChart(
            "SINR trend", "dB", state.history.map { it.sinr }, -10f, 35f,
            bands = listOf(
                20f to C.grade(Grade.EXCELLENT), 13f to C.grade(Grade.GOOD),
                0f to C.grade(Grade.FAIR), -10f to C.grade(Grade.POOR)
            ),
            lineColor = C.Accent2
        )
    }

    s.location?.let { g ->
        Panel(title = "Position") {
            InfoGrid(
                listOf(
                    "Lat" to "%.5f".format(g.lat), "Lon" to "%.5f".format(g.lon),
                    "Speed" to "%.0f km/h".format(g.speedKmh)
                )
            )
        }
    }
}

private fun servingItems(c: CellMeasurement): List<Pair<String, String?>> {
    val items = mutableListOf<Pair<String, String?>>(
        "MCC-MNC" to if (c.mcc != null) "${c.mcc}-${c.mnc}" else null,
        c.pciLabel to c.pci?.toString(),
        c.arfcnLabel to c.arfcn?.toString(),
        "Band" to c.band,
        c.areaLabel to c.tac?.toString(),
        (if (c.rat == Rat.NR) "NCI" else "Cell ID") to c.cellId?.toString()
    )
    when (c.rat) {
        Rat.LTE -> {
            items += "eNB-Sector" to c.enbSector
            items += "RSSI" to c.rssi?.let { "$it dBm" }
            items += "TA" to c.ta?.toString()
            items += "CQI" to c.cqi?.toString()
        }
        Rat.NR -> items += "CSI-RSRP" to c.csiRsrp?.let { "$it dBm" }
        Rat.GSM -> items += "TA" to c.ta?.toString()
        else -> {}
    }
    items += "Bars" to "${c.level}/4"
    return items
}

// ---------------------------------------------------------------- Cells

@Composable
private fun CellsTab(s: RadioSnapshot?) {
    if (s == null) {
        Panel { Text("Waiting for first measurement…", color = C.Muted) }
        return
    }
    val all = listOfNotNull(s.serving) + s.neighbours
    Panel(title = "Measured cells", trailing = "${s.neighbours.size} neighbours") {
        Row(Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
            listOf("RAT" to 1.1f, "PCI" to 0.9f, "ARFCN" to 1.3f, "Level" to 1f, "Qual" to 0.9f, "SINR" to 0.9f)
                .forEach { (h, w) -> Text(h, color = C.Muted, fontSize = 11.sp, modifier = Modifier.weight(w)) }
        }
        if (all.isEmpty()) Text("No cells reported by the modem.", color = C.Muted, fontSize = 13.sp)
        all.forEach { c -> CellRow(c) }
    }
    Text(
        "Neighbour reporting depends on the phone model. Many devices only report neighbours on the same technology, and some report none at all.",
        color = C.Muted, fontSize = 12.sp
    )
}

@Composable
private fun CellRow(c: CellMeasurement) {
    val lvl = c.primaryDbm
    val qual = if (c.rat == Rat.WCDMA) c.ecno else c.rsrq
    val g = Thresholds.primary(c.rat, lvl)
    Row(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(if (c.registered) C.Accent.copy(alpha = 0.10f) else Color.Transparent)
            .padding(vertical = 7.dp, horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val mono = FontFamily.Monospace
        Row(Modifier.weight(1.1f), verticalAlignment = Alignment.CenterVertically) {
            Dot(C.grade(g)); Spacer(Modifier.width(5.dp))
            Text(c.rat.name + if (c.registered) "*" else "", color = C.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
        Text(c.pci?.toString() ?: "—", color = C.Text, fontSize = 13.sp, fontFamily = mono, modifier = Modifier.weight(0.9f))
        Text(c.arfcn?.toString() ?: "—", color = C.Text, fontSize = 13.sp, fontFamily = mono, modifier = Modifier.weight(1.3f))
        Text(lvl?.toString() ?: "—", color = C.grade(g), fontSize = 13.sp, fontFamily = mono, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Text(qual?.toString() ?: "—", color = C.Text, fontSize = 13.sp, fontFamily = mono, modifier = Modifier.weight(0.9f))
        Text(c.sinr?.toString() ?: "—", color = C.Text, fontSize = 13.sp, fontFamily = mono, modifier = Modifier.weight(0.9f))
    }
}

// ---------------------------------------------------------------- KPIs

@Composable
private fun KpiTab(state: UiState, a: Actions) {
    val k = state.kpis
    val dur = (state.snapshot?.timestamp ?: System.currentTimeMillis()) - k.startedAt
    val hh = TimeUnit.MILLISECONDS.toHours(dur)
    val mm = TimeUnit.MILLISECONDS.toMinutes(dur) % 60
    val ss = TimeUnit.MILLISECONDS.toSeconds(dur) % 60

    fun f1(v: Float?) = v?.let { "%.1f".format(it) } ?: "—"
    fun pct(v: Float) = "%.1f%%".format(v)

    val tiles = listOf(
        Triple("Availability", pct(k.availabilityPct), C.grade(if (k.availabilityPct >= 99) Grade.EXCELLENT else if (k.availabilityPct >= 95) Grade.FAIR else Grade.BAD)),
        Triple("Avg level (dBm)", f1(k.avgPrimary), C.grade(Thresholds.rsrp(k.avgPrimary?.toInt()))),
        Triple("Avg RSRQ (dB)", f1(k.avgRsrq), C.grade(Thresholds.rsrq(k.avgRsrq?.toInt()))),
        Triple("Avg SINR (dB)", f1(k.avgSinr), C.grade(Thresholds.sinr(k.avgSinr?.toInt()))),
        Triple("Good coverage", pct(k.goodCoveragePct), C.Text),
        Triple("SINR ≥ 13 dB", pct(k.goodSinrPct), C.Text),
        Triple("5G time share", pct(k.fiveGPct), C.Accent2),
        Triple("Cell changes", k.cellChanges.toString(), C.Text),
        Triple("RAT changes", k.ratChanges.toString(), C.Text),
        Triple("Unique cells", k.uniqueCells.size.toString(), C.Text)
    )

    Panel(title = "Session", trailing = "%02d:%02d:%02d · %d samples".format(hh, mm, ss, k.samples)) {
        InfoGrid(
            listOf(
                "Min level" to k.primaryMin?.let { "$it dBm" },
                "Max level" to k.primaryMax?.let { "$it dBm" },
                "No service" to pct(k.noServicePct)
            )
        )
    }

    tiles.chunked(2).forEach { row ->
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            row.forEach { (l, v, col) -> KpiTile(l, v, color = col, modifier = Modifier.weight(1f)) }
            if (row.size == 1) Spacer(Modifier.weight(1f))
        }
    }

    Panel(title = "Coverage distribution") {
        PctBar("Excellent (≥ -90 dBm)", k.excellentCoveragePct, C.grade(Grade.EXCELLENT))
        PctBar("Good or better (≥ -100 dBm)", k.goodCoveragePct, C.grade(Grade.GOOD))
        PctBar("Bad (< -110 dBm or no service)", k.badCoveragePct, C.grade(Grade.BAD))
    }

    Panel(title = "Technology share") {
        if (k.ratCounts.isEmpty()) Text("No samples yet.", color = C.Muted, fontSize = 13.sp)
        k.ratCounts.entries.sortedByDescending { it.value }.forEach { (tech, n) ->
            val color = when {
                tech.startsWith("5G") -> C.Accent2
                tech.startsWith("4G") -> C.Accent
                tech.startsWith("3G") -> C.grade(Grade.FAIR)
                tech == "No service" -> C.grade(Grade.BAD)
                else -> C.grade(Grade.POOR)
            }
            PctBar(tech, if (k.samples == 0) 0f else n * 100f / k.samples, color)
        }
    }

    Panel(title = "Settings") {
        Text("Sampling interval", color = C.Muted, fontSize = 12.sp)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(1000L to "1 s", 2000L to "2 s", 5000L to "5 s", 10000L to "10 s").forEach { (ms, l) ->
                Chip(l, state.intervalMs == ms) { a.onInterval(ms) }
            }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = a.onReset) { Text("Reset KPIs", color = C.Text) }
    }

    Text(
        "Coverage thresholds: LTE/NR RSRP, 3G RSCP and 2G RSSI each use their own scale. Avg level mixes technologies if the phone changed RAT during the session.",
        color = C.Muted, fontSize = 12.sp
    )
}
