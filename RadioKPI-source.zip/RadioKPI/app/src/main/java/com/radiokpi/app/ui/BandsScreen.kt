package com.radiokpi.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.radiokpi.app.UiState
import com.radiokpi.app.radio.BandResult
import com.radiokpi.app.radio.CellMeasurement
import com.radiokpi.app.radio.Duplex
import com.radiokpi.app.radio.Grade
import com.radiokpi.app.radio.Rat
import com.radiokpi.app.radio.Thresholds
import com.radiokpi.app.radio.mhz

private fun duplexColor(d: Duplex): Color = when (d) {
    Duplex.FDD -> C.Accent
    Duplex.TDD -> C.Accent2
    Duplex.SDL -> C.grade(Grade.FAIR)
}

private fun bandColor(name: String): Color = when {
    name.startsWith("n") -> C.Accent2
    name.startsWith("B") -> C.Accent
    name.startsWith("3G") -> C.grade(Grade.FAIR)
    else -> C.grade(Grade.POOR)
}

@Composable
fun BandsTab(state: UiState) {
    val s = state.snapshot
    val c = s?.serving

    // ---- Serving band
    Panel(title = "Serving band", trailing = c?.rat?.label) {
        if (c == null) {
            Text("No serving cell.", color = C.Muted, fontSize = 14.sp)
        } else {
            val b = c.bandResult
            if (b == null) {
                Text(
                    "Band details are calculated for 4G and 5G cells. You're on ${c.rat.label} (channel ${c.arfcn ?: "—"}).",
                    color = C.Muted, fontSize = 14.sp
                )
            } else {
                BandDetails(c, b)
            }
        }
    }

    // ---- 5G NSA leg
    if (s != null && s.isNsa) {
        val nrCells = s.neighbours.filter { it.rat == Rat.NR }
        Panel(title = "5G NR leg (NSA)") {
            if (nrCells.isEmpty()) {
                Text(
                    "5G is active on top of 4G. This phone doesn't list the NR cell, so Android can't show the NR band. " +
                        "Signal values are on the Dashboard tab.",
                    color = C.Muted, fontSize = 13.sp
                )
            } else {
                nrCells.forEach { nc ->
                    val nb = nc.bandResult
                    InfoGrid(
                        listOf(
                            "Band" to nb?.name,
                            "NR-ARFCN" to nc.arfcn?.toString(),
                            "DL freq" to nb?.dlMHz?.mhz(),
                            "PCI" to nc.pci?.toString(),
                            "SS-RSRP" to nc.rsrp?.let { "$it dBm" },
                            "SS-SINR" to nc.sinr?.let { "$it dB" }
                        )
                    )
                }
            }
        }
    }

    // ---- Carrier aggregation
    Panel(title = "Carrier aggregation") {
        val cc = s?.ccBandwidthsKhz ?: emptyList()
        if (cc.isEmpty()) {
            Text(
                "Not reported by this phone. Android 9+ is needed, and some modems never share it.",
                color = C.Muted, fontSize = 13.sp
            )
        } else {
            InfoGrid(
                listOf(
                    "Carriers" to cc.size.toString(),
                    "Total BW" to "${cc.sum() / 1000} MHz",
                    "Status" to if (cc.size > 1) "CA active" else "Single"
                )
            )
            Spacer(Modifier.height(6.dp))
            cc.forEachIndexed { i, bw ->
                val label = if (i == 0) "PCC (primary)" else "SCC $i"
                ValueBar(label, "${bw / 1000} MHz", bw / 100_000f, if (i == 0) C.Accent else C.Accent2)
            }
            Text("Bar scale: 100 MHz", color = C.Muted, fontSize = 11.sp)
        }
    }

    // ---- Neighbour bands
    if (s != null && s.neighbours.isNotEmpty()) {
        Panel(title = "Neighbour bands", trailing = "${s.neighbours.size} cells") {
            s.neighbours.groupBy { it.bandKey }
                .entries
                .sortedByDescending { e -> e.value.maxOf { it.primaryDbm ?: -999 } }
                .forEach { (band, cells) ->
                    val best = cells.mapNotNull { it.primaryDbm }.maxOrNull()
                    val g = Thresholds.primary(cells.first().rat, best)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Dot(C.grade(g)); Spacer(Modifier.width(8.dp))
                        Text(band, color = bandColor(band), fontSize = 14.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f))
                        Text("${cells.size} cell${if (cells.size > 1) "s" else ""} · best ${best ?: "—"} dBm",
                            color = C.Muted, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                    }
                    Spacer(Modifier.height(8.dp))
                }
        }
    }

    // ---- Band usage over the session
    val k = state.kpis
    Panel(title = "Band usage (session)", trailing = "${k.samples} samples") {
        if (k.bandStats.isEmpty()) {
            Text("No samples yet.", color = C.Muted, fontSize = 13.sp)
        }
        k.bandStats.entries.sortedByDescending { it.value.samples }.forEach { (band, st) ->
            val pct = if (k.samples == 0) 0f else st.samples * 100f / k.samples
            val label = if (st.common.isNotBlank()) "$band · ${st.common}" else band
            val avg = st.avgLevel?.let { "%.0f dBm".format(it) } ?: "—"
            ValueBar(label, "%.0f%% · %s".format(pct, avg), pct / 100f, bandColor(band))
        }
        if (k.caSamples > 0) {
            Spacer(Modifier.height(6.dp))
            Text("Carrier aggregation active %.1f%% of the time".format(k.caPct), color = C.Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun BandDetails(c: CellMeasurement, b: BandResult) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(b.name, color = bandColor(b.name), fontSize = 34.sp, fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            if (b.common.isNotBlank()) Text(b.common, color = C.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(c.rat.label, color = C.Muted, fontSize = 12.sp)
        }
        Badge(b.duplex.name, duplexColor(b.duplex))
    }
    Spacer(Modifier.height(10.dp))
    InfoGrid(
        listOf(
            c.arfcnLabel to c.arfcn?.toString(),
            "DL freq" to b.dlMHz?.mhz(),
            "UL freq" to when (b.duplex) {
                Duplex.SDL -> "DL only"
                Duplex.TDD -> b.ulMHz?.mhz()?.let { "$it (TDD)" }
                Duplex.FDD -> b.ulMHz?.mhz()
            },
            "Bandwidth" to c.bandwidthKhz?.let { "${it / 1000} MHz" },
            c.pciLabel to c.pci?.toString(),
            "Duplex" to b.duplex.name
        ),
        cols = 2
    )
}
