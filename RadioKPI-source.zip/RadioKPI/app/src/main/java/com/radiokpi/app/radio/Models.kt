package com.radiokpi.app.radio

enum class Rat(val label: String) {
    GSM("2G GSM"), WCDMA("3G WCDMA"), TDSCDMA("3G TD-SCDMA"), CDMA("CDMA"),
    LTE("4G LTE"), NR("5G NR"), UNKNOWN("Unknown")
}

/** One measured cell (serving or neighbour). Null = not reported by the modem. */
data class CellMeasurement(
    val rat: Rat,
    val registered: Boolean,
    val mcc: String? = null,
    val mnc: String? = null,
    val pci: Int? = null,          // PCI (LTE/NR), PSC (WCDMA), BSIC (GSM)
    val arfcn: Int? = null,        // EARFCN / NR-ARFCN / UARFCN / ARFCN
    val band: String? = null,
    val tac: Int? = null,          // TAC (LTE/NR) or LAC (2G/3G)
    val cellId: Long? = null,      // ECI / NCI / CID
    val rsrp: Int? = null,         // dBm (LTE RSRP / NR SS-RSRP)
    val rsrq: Int? = null,         // dB
    val sinr: Int? = null,         // dB (LTE RSSNR / NR SS-SINR)
    val rssi: Int? = null,         // dBm
    val rscp: Int? = null,         // dBm (WCDMA)
    val ecno: Int? = null,         // dB (WCDMA)
    val csiRsrp: Int? = null,      // dBm (NR)
    val ta: Int? = null,           // timing advance
    val cqi: Int? = null,
    val dbm: Int? = null,
    val level: Int = 0,            // 0..4 Android signal bars
    val bandwidthKhz: Int? = null  // LTE channel bandwidth (Android 9+)
) {
    /** Band, DL/UL frequency and duplex derived from ARFCN (LTE / NR only). */
    val bandResult: BandResult? get() = BandPlan.forCell(this)

    /** Short band label for any RAT, used for per-band KPIs. */
    val bandKey: String
        get() = bandResult?.name ?: when (rat) {
            Rat.WCDMA -> "3G" + (arfcn?.let { " U$it" } ?: "")
            Rat.GSM -> "2G" + (arfcn?.let { if (it in 512..885) " 1800" else " 900" } ?: "")
            else -> rat.label
        }

    /** Main strength metric for this technology, used for trends & coverage KPIs. */
    val primaryDbm: Int?
        get() = when (rat) {
            Rat.LTE, Rat.NR -> rsrp ?: dbm
            Rat.WCDMA, Rat.TDSCDMA -> rscp ?: dbm
            else -> rssi ?: dbm
        }

    val arfcnLabel: String
        get() = when (rat) {
            Rat.LTE -> "EARFCN"; Rat.NR -> "NR-ARFCN"; Rat.WCDMA -> "UARFCN"; else -> "ARFCN"
        }
    val pciLabel: String
        get() = when (rat) {
            Rat.WCDMA, Rat.TDSCDMA -> "PSC"; Rat.GSM -> "BSIC"; else -> "PCI"
        }
    val areaLabel: String
        get() = if (rat == Rat.LTE || rat == Rat.NR) "TAC" else "LAC"

    /** LTE eNodeB ID / sector, NR gNB is operator-specific so we only split LTE. */
    val enbSector: String?
        get() = if (rat == Rat.LTE && cellId != null) "${cellId / 256}-${cellId % 256}" else null

    val key: String get() = "${rat.name}:${arfcn}:${pci}:${cellId}"
}

/** 5G NSA secondary-leg signal (NR leg reported via SignalStrength while anchored on LTE). */
data class NrNsaSignal(val ssRsrp: Int?, val ssRsrq: Int?, val ssSinr: Int?, val csiRsrp: Int?)

data class GeoFix(val lat: Double, val lon: Double, val accuracyM: Float, val speedKmh: Float)

data class RadioSnapshot(
    val timestamp: Long,
    val operator: String,
    val networkType: String,
    val serving: CellMeasurement?,
    val neighbours: List<CellMeasurement>,
    val nsa: NrNsaSignal?,
    val location: GeoFix?,
    val ccBandwidthsKhz: List<Int> = emptyList()  // per component carrier, from ServiceState
) {
    val caActive: Boolean get() = ccBandwidthsKhz.size > 1

    val isNsa: Boolean get() = serving?.rat == Rat.LTE && nsa?.ssRsrp != null
    val techLabel: String
        get() = when {
            serving == null -> "No service"
            isNsa -> "5G NSA"
            serving.rat == Rat.NR -> "5G SA"
            else -> serving.rat.label
        }
}

enum class Grade(val label: String) { EXCELLENT("Excellent"), GOOD("Good"), FAIR("Fair"), POOR("Poor"), BAD("Bad"), NA("—") }

object Thresholds {
    fun rsrp(v: Int?) = grade(v, -80, -90, -100, -110)
    fun rsrq(v: Int?) = grade(v, -10, -15, -20, -24)
    fun sinr(v: Int?) = grade(v, 20, 13, 0, -5)
    fun rscp(v: Int?) = grade(v, -75, -85, -95, -105)
    fun ecno(v: Int?) = grade(v, -6, -10, -14, -18)
    fun gsmRssi(v: Int?) = grade(v, -70, -85, -95, -105)

    fun primary(rat: Rat, v: Int?) = when (rat) {
        Rat.LTE, Rat.NR -> rsrp(v)
        Rat.WCDMA, Rat.TDSCDMA -> rscp(v)
        else -> gsmRssi(v)
    }

    private fun grade(v: Int?, ex: Int, good: Int, fair: Int, poor: Int): Grade = when {
        v == null -> Grade.NA
        v >= ex -> Grade.EXCELLENT
        v >= good -> Grade.GOOD
        v >= fair -> Grade.FAIR
        v >= poor -> Grade.POOR
        else -> Grade.BAD
    }
}
