package com.radiokpi.app.net

import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException

/** Minimal RFC 1035 DNS message builder/parser (UDP, A/AAAA). */
object DnsPacket {
    const val TYPE_A = 1
    const val TYPE_AAAA = 28
    const val TYPE_CNAME = 5

    fun query(id: Int, name: String, type: Int): ByteArray {
        val out = ByteArrayOutputStream()
        fun u16(v: Int) { out.write((v shr 8) and 0xFF); out.write(v and 0xFF) }
        u16(id)
        u16(0x0100)   // standard query, recursion desired
        u16(1); u16(0); u16(0); u16(0)
        name.trimEnd('.').split('.').forEach { label ->
            val b = label.toByteArray(Charsets.US_ASCII)
            out.write(b.size); out.write(b, 0, b.size)
        }
        out.write(0)
        u16(type); u16(1)  // class IN
        return out.toByteArray()
    }

    data class Answer(
        val id: Int,
        val rcode: Int,
        val truncated: Boolean,
        val recursionAvailable: Boolean,
        val addresses: List<String>,
        val cnames: Int,
        val minTtl: Int?
    )

    private fun u16(b: ByteArray, i: Int) = ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
    private fun u32(b: ByteArray, i: Int): Long =
        ((u16(b, i).toLong()) shl 16) or u16(b, i + 2).toLong()

    /** Returns the index just after a (possibly compressed) name. */
    private fun skipName(b: ByteArray, start: Int, len: Int): Int {
        var i = start
        var guard = 0
        while (i < len && guard++ < 128) {
            val l = b[i].toInt() and 0xFF
            when {
                l == 0 -> return i + 1
                (l and 0xC0) == 0xC0 -> return i + 2
                else -> i += l + 1
            }
        }
        throw IllegalArgumentException("bad name")
    }

    fun parse(b: ByteArray, len: Int): Answer {
        require(len >= 12) { "short response" }
        val id = u16(b, 0)
        val flags = u16(b, 2)
        val qd = u16(b, 4)
        val an = u16(b, 6)
        var i = 12
        repeat(qd) { i = skipName(b, i, len) + 4 }
        val addrs = mutableListOf<String>()
        var cn = 0
        var minTtl: Int? = null
        repeat(an) {
            if (i >= len) return@repeat
            i = skipName(b, i, len)
            val type = u16(b, i)
            val ttl = u32(b, i + 4).toInt()
            val rdLen = u16(b, i + 8)
            val rd = i + 10
            when (type) {
                TYPE_A -> if (rdLen == 4) addrs += (0 until 4).joinToString(".") { k -> (b[rd + k].toInt() and 0xFF).toString() }
                TYPE_AAAA -> if (rdLen == 16) addrs += (0 until 8).joinToString(":") { k ->
                    Integer.toHexString(u16(b, rd + k * 2))
                }
                TYPE_CNAME -> cn++
            }
            if (type == TYPE_A || type == TYPE_AAAA) minTtl = minOf(minTtl ?: ttl, ttl)
            i = rd + rdLen
        }
        return Answer(
            id = id,
            rcode = flags and 0x0F,
            truncated = (flags and 0x0200) != 0,
            recursionAvailable = (flags and 0x0080) != 0,
            addresses = addrs,
            cnames = cn,
            minTtl = minTtl
        )
    }

    fun rcodeName(r: Int?) = when (r) {
        null -> "—"; 0 -> "NOERROR"; 1 -> "FORMERR"; 2 -> "SERVFAIL"; 3 -> "NXDOMAIN"
        4 -> "NOTIMP"; 5 -> "REFUSED"; else -> "RCODE$r"
    }
}

data class DnsQueryResult(
    val resolver: String,
    val server: String,
    val domain: String,
    val type: Int,
    val attempt: Int,          // 1 = first (cold), 2 = repeat (cached at resolver)
    val rttMs: Long?,
    val rcode: Int?,
    val answers: List<String>,
    val ttl: Int?,
    val error: String?
) {
    val ok: Boolean get() = rttMs != null && rcode == 0
    val timeout: Boolean get() = error == "timeout"
}

object DnsClient {
    private var nextId = (System.nanoTime() and 0x7FFF).toInt()

    /** One UDP query with one retry. [bind] lets Android bind the socket to a specific Network. */
    fun query(
        resolver: String, server: InetAddress, domain: String, type: Int, attempt: Int,
        timeoutMs: Int = 2000, bind: (DatagramSocket) -> Unit = {}
    ): DnsQueryResult {
        var lastErr = "timeout"
        repeat(2) { tryNo ->
            val id = synchronized(this) { nextId = (nextId + 1) and 0xFFFF; nextId }
            val q = DnsPacket.query(id, domain, type)
            try {
                DatagramSocket().use { sock ->
                    bind(sock)
                    sock.soTimeout = timeoutMs
                    val t0 = System.nanoTime()
                    sock.send(DatagramPacket(q, q.size, server, 53))
                    val buf = ByteArray(1500)
                    while (true) {
                        val pkt = DatagramPacket(buf, buf.size)
                        sock.receive(pkt)
                        val rtt = (System.nanoTime() - t0) / 1_000_000
                        val a = DnsPacket.parse(buf, pkt.length)
                        if (a.id != id) continue
                        return DnsQueryResult(resolver, server.hostAddress ?: "", domain, type,
                            attempt, rtt, a.rcode, a.addresses, a.minTtl,
                            if (a.rcode == 0) null else DnsPacket.rcodeName(a.rcode))
                    }
                }
            } catch (e: SocketTimeoutException) {
                lastErr = "timeout"
            } catch (e: Exception) {
                lastErr = e.message ?: e.javaClass.simpleName
                if (tryNo == 0) return@repeat
            }
        }
        return DnsQueryResult(resolver, server.hostAddress ?: "", domain, type, attempt, null, null, emptyList(), null, lastErr)
    }
}
