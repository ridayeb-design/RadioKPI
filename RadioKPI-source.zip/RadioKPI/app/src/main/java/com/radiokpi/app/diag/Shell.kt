package com.radiokpi.app.diag

import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** Minimal shell runner (normal or root through `su`). Always call from a background thread. */
object Shell {
    data class Result(val code: Int, val out: String, val err: String) {
        val ok get() = code == 0
    }

    private val suPaths = listOf(
        "/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su",
        "/system/sbin/su", "/vendor/bin/su", "/debug_ramdisk/su"
    )

    fun suBinaryPresent(): Boolean =
        suPaths.any { File(it).exists() } || run("command -v su", root = false).out.isNotBlank()

    fun run(cmd: String, root: Boolean, timeoutMs: Long = 8000): Result = try {
        val p = ProcessBuilder(if (root) listOf("su", "-c", cmd) else listOf("sh", "-c", cmd)).start()
        val out = StringBuilder()
        val err = StringBuilder()
        val t1 = thread { try { out.append(p.inputStream.bufferedReader().readText()) } catch (_: Exception) { } }
        val t2 = thread { try { err.append(p.errorStream.bufferedReader().readText()) } catch (_: Exception) { } }
        val done = p.waitFor(timeoutMs, TimeUnit.MILLISECONDS)
        if (!done) p.destroy()
        t1.join(1000); t2.join(1000)
        Result(if (done) p.exitValue() else -1, out.toString(), err.toString())
    } catch (e: Exception) {
        Result(-1, "", e.message ?: e.javaClass.simpleName)
    }

    fun getprop(name: String): String = run("getprop $name", root = false).out.trim()
}
