package com.radiokpi.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.radiokpi.app.UiState
import com.radiokpi.app.radio.Grade
import com.radiokpi.app.signalling.Layer
import com.radiokpi.app.signalling.RrcEstimate
import com.radiokpi.app.signalling.SigEvent
import com.radiokpi.app.signalling.SigSummary
import com.radiokpi.app.signalling.SigType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun layerColor(l: Layer): Color = when (l) {
    Layer.RRC -> C.Accent
    Layer.NAS -> C.Accent2
    Layer.MOB -> C.grade(Grade.GOOD)
    Layer.PDN -> C.grade(Grade.FAIR)
    Layer.PHY -> Color(0xFF60A5FA)
    Layer.CALL -> C.grade(Grade.POOR)
}

@Composable
fun SignallingTab(state: UiState) {
    val ev = state.sigEvents
    val counts = SigSummary.counts(ev)
    fun n(t: SigType) = counts[t] ?: 0

    Panel(title = "About these events") {
        Text(
            "Reconstructed from Android telephony callbacks and cell measurements, labelled in 3GPP terms. " +
                "Raw RRC/NAS messages (Paging, RRC Connection Setup, Measurement Report…) are only readable " +
                "with a modem diag capture (Diag tab, rooted Qualcomm).",
            color = C.Muted, fontSize = 12.sp
        )
    }

    // ---- RRC state estimate
    Panel(title = "RRC state (estimated)") {
        val (label, col) = when (state.rrc) {
            RrcEstimate.CONNECTED -> "RRC_CONNECTED" to C.grade(Grade.EXCELLENT)
            RrcEstimate.IDLE -> "RRC_IDLE" to C.Accent
            RrcEstimate.UNKNOWN -> "Unknown" to C.Muted
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = col, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace,
                modifier = Modifier.weight(1f))
            Badge(if (state.dormantSeen) "dormancy reported" else "no dormancy reports", if (state.dormantSeen) C.Accent else C.Muted)
        }
        val tot = (state.rrcConnectedMs + state.rrcIdleMs).coerceAtLeast(1)
        Spacer(Modifier.padding(top = 6.dp))
        ValueBar("Connected", "%.0f%% · %ds".format(state.rrcConnectedMs * 100f / tot, state.rrcConnectedMs / 1000),
            state.rrcConnectedMs.toFloat() / tot, C.grade(Grade.EXCELLENT))
        ValueBar("Idle", "%.0f%% · %ds".format(state.rrcIdleMs * 100f / tot, state.rrcIdleMs / 1000),
            state.rrcIdleMs.toFloat() / tot, C.Accent)
        Text(
            "Based on the modem's data-activity indicator: DORMANT = inactivity timer expired (RRC release). " +
                "Some phones never report dormancy; then handovers and reselections can't be told apart.",
            color = C.Muted, fontSize = 11.sp
        )
    }

    // ---- Counters
    val tiles = listOf(
        Triple("Handovers", SigSummary.handovers(counts).toString(),
            "intra ${n(SigType.HO_INTRA)} · inter ${n(SigType.HO_INTER)} · IRAT ${n(SigType.HO_IRAT)}"),
        Triple("Reselections", SigSummary.reselections(counts).toString(),
            "intra ${n(SigType.RESEL_INTRA)} · inter ${n(SigType.RESEL_INTER)} · IRAT ${n(SigType.RESEL_IRAT)}"),
        Triple("TAU / LAU", "${n(SigType.TAU)} / ${n(SigType.LAU)}", "tracking/location area changes"),
        Triple("SgNB add / rel", "${n(SigType.SGNB_ADD)} / ${n(SigType.SGNB_REL)}", "EN-DC NR leg"),
        Triple("RRC setup / release", "${n(SigType.RRC_CONNECTED)} / ${n(SigType.RRC_IDLE)}", "estimated transitions"),
        Triple("Out of service", (n(SigType.OUT_OF_SERVICE) + n(SigType.EMERGENCY_ONLY)).toString(), "incl. limited service"),
        Triple("Bearer drops", (n(SigType.BEARER_DISCONNECTED) + n(SigType.BEARER_SUSPENDED)).toString(), "PDN disconnect/suspend"),
        Triple("Unclassified", n(SigType.CELL_CHANGE).toString(), "cell changes, RRC state unknown")
    )
    tiles.chunked(2).forEach { row ->
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            row.forEach { (l, v, sub) -> KpiTile(l, v, sub, modifier = Modifier.weight(1f)) }
        }
    }

    // ---- Event log with layer filter
    var filter by rememberSaveable { mutableStateOf("ALL") }
    Panel(title = "Signalling log", trailing = "${ev.size} events") {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            (listOf("ALL") + Layer.values().map { it.name }).take(4).forEach { f -> Chip(f, filter == f) { filter = f } }
        }
        Spacer(Modifier.padding(top = 4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Layer.values().drop(3).forEach { l -> Chip(l.name, filter == l.name) { filter = l.name } }
        }
        Spacer(Modifier.padding(top = 8.dp))
        val list = ev.asReversed().filter { filter == "ALL" || it.type.layer.name == filter }
        if (list.isEmpty()) Text("No events yet. Move around or toggle airplane mode to see some.", color = C.Muted, fontSize = 13.sp)
        var all by rememberSaveable { mutableStateOf(false) }
        (if (all) list.take(300) else list.take(30)).forEach { SigRow(it) }
        if (list.size > 30) {
            OutlinedButton(onClick = { all = !all }) { Text(if (all) "Show less" else "Show more", color = C.Text) }
        }
    }
}

private val tf = SimpleDateFormat("HH:mm:ss", Locale.US)

@Composable
private fun SigRow(e: SigEvent) {
    val col = layerColor(e.type.layer)
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Text(tf.format(Date(e.t)), color = C.Muted, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(top = 2.dp))
        Spacer(Modifier.width(6.dp))
        Box(
            Modifier.widthIn(min = 40.dp).clip(RoundedCornerShape(4.dp)).background(col.copy(alpha = 0.18f))
                .padding(horizontal = 4.dp, vertical = 1.dp),
            contentAlignment = Alignment.Center
        ) { Text(e.type.layer.tag, color = col, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace) }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(e.type.title, color = C.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(e.detail, color = C.Muted, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        }
    }
}
