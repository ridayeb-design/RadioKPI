package com.radiokpi.app.diag.samsung

import android.app.Application
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.radiokpi.app.diag.Shell
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------- transports

/** Candidate DM interface on a USB device: vendor-specific class with bulk IN + OUT. */
data class DmPort(val device: UsbDevice, val intf: UsbInterface, val epIn: UsbEndpoint, val epOut: UsbEndpoint) {
    val label: String
        get() = "${device.manufacturerNameSafe()} ${device.productNameSafe()} · interface #${intf.id}"
}

private fun UsbDevice.manufacturerNameSafe(): String = try { manufacturerName ?: "" } catch (_: Exception) { "" }.ifBlank {
    if (vendorId == 0x04E8) "Samsung" else "VID %04X".format(vendorId)
}
private fun UsbDevice.productNameSafe(): String = try { productName ?: "" } catch (_: Exception) { "" }.ifBlank { "PID %04X".format(productId) }

object DmPorts {
    /** All vendor-class bulk interfaces, best guess first (ADB excluded). */
    fun find(dev: UsbDevice): List<DmPort> {
        val out = mutableListOf<DmPort>()
        for (i in 0 until dev.interfaceCount) {
            val intf = dev.getInterface(i)
            if (intf.interfaceClass == UsbConstants.USB_CLASS_CDC_DATA || intf.interfaceClass == UsbConstants.USB_CLASS_MASS_STORAGE) continue
            if (intf.interfaceClass == 0xFF && intf.interfaceSubclass == 0x42) continue // ADB
            var epIn: UsbEndpoint? = null; var epOut: UsbEndpoint? = null
            for (e in 0 until intf.endpointCount) {
                val ep = intf.getEndpoint(e)
                if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
                if (ep.direction == UsbConstants.USB_DIR_IN) epIn = epIn ?: ep else epOut = epOut ?: ep
            }
            if (epIn != null && epOut != null) out += DmPort(dev, intf, epIn, epOut)
        }
        // vendor class first; among those prefer the highest interface number (DM comes after RNDIS/ACM)
        return out.sortedWith(compareByDescending<DmPort> { it.intf.interfaceClass == 0xFF }.thenByDescending { it.intf.id })
    }
}

class UsbSdmTransport(
    private val conn: UsbDeviceConnection,
    private val port: DmPort,
    private val attached: () -> Boolean
) : SdmTransport {
    override val label = "USB OTG: " + port.label
    override fun write(data: ByteArray) {
        var off = 0
        while (off < data.size) {
            val n = conn.bulkTransfer(port.epOut, data, off, data.size - off, 2000)
            if (n < 0) throw IOException("USB write failed")
            off += n
        }
    }
    override fun read(buf: ByteArray): Int {
        val n = conn.bulkTransfer(port.epIn, buf, buf.size, 500)
        return when {
            n > 0 -> n
            !attached() -> -1
            else -> 0
        }
    }
    override fun close() {
        try { conn.releaseInterface(port.intf) } catch (_: Exception) {}
        try { conn.close() } catch (_: Exception) {}
    }
}

/**
 * Rooted Samsung reading its own modem: one root shell opens the DM node read/write on fd 3,
 * streams it to stdout, and writes each command file named on stdin into it.
 * The node name differs between firmwares; this is experimental.
 */
class RootSdmTransport(private val ctx: Context, private val node: String) : SdmTransport {
    override val label = "Root (this phone): $node"
    private val dir = File(ctx.cacheDir, "sdm_cmd").apply { mkdirs() }
    private var proc: Process? = null
    private var input: InputStream? = null
    private var stdin: OutputStream? = null
    @Volatile private var dead = false
    private var seq = 0

    fun open() {
        val script = File(ctx.filesDir, "sdm_bridge.sh")
        script.writeText(
            "exec 3<>$node || exit 9\n" +
                "cat <&3 &\n" +
                "while read f; do cat \"\$f\" >&3; done\n" +
                "kill %1 2>/dev/null\n"
        )
        val p = ProcessBuilder("su", "-c", "sh ${script.absolutePath}").start()
        proc = p; input = p.inputStream; stdin = p.outputStream
    }

    override fun write(data: ByteArray) {
        val f = File(dir, "c${seq++ % 64}.bin")
        f.writeBytes(data)
        f.setReadable(true, false)
        val o = stdin ?: throw IOException("root shell not open")
        o.write((f.absolutePath + "\n").toByteArray()); o.flush()
    }

    override fun read(buf: ByteArray): Int {
        val inp = input ?: return -1
        if (dead) return -1
        if (inp.available() <= 0) {
            val p = proc
            if (p != null && !p.isAliveCompat()) { dead = true; return -1 }
            Thread.sleep(50); return 0
        }
        val n = inp.read(buf, 0, minOf(buf.size, maxOf(1, inp.available())))
        return if (n < 0) { dead = true; -1 } else n
    }

    override fun close() {
        try { stdin?.close() } catch (_: Exception) {}
        try { proc?.destroy() } catch (_: Exception) {}
    }

    private fun Process.isAliveCompat(): Boolean = try { exitValue(); false } catch (_: IllegalThreadStateException) { true }

    companion object {
        val CANDIDATES = listOf("/dev/umts_dm0", "/dev/umts_dm1", "/dev/dm0", "/dev/umts_boot0")
    }
}

// ---------------------------------------------------------------- view model

data class SamsungUi(
    val ports: List<String> = emptyList(),
    val portIndex: Int = 0,
    val usbStatus: String = "Tap Scan after connecting the Samsung phone with an OTG cable.",
    val rootNodes: List<String> = emptyList(),
    val rootChecked: Boolean = false,
    val busy: Boolean = false,
    val live: SamsungLive = SamsungLive(),
    val lastOutDir: String? = null,
    val noDataHint: Boolean = false
)

data class SamsungActions(
    val onScan: () -> Unit = {},
    val onNextPort: () -> Unit = {},
    val onStartUsb: () -> Unit = {},
    val onCheckRootNodes: () -> Unit = {},
    val onStartRoot: (String) -> Unit = {},
    val onStop: () -> Unit = {},
    val onShare: () -> Unit = {}
)

class SamsungDiagViewModel(app: Application) : AndroidViewModel(app) {
    private val _s = MutableStateFlow(SamsungUi())
    val state: StateFlow<SamsungUi> = _s.asStateFlow()

    private val usb get() = getApplication<Application>().getSystemService(Context.USB_SERVICE) as UsbManager
    private var ports: List<DmPort> = emptyList()
    @Volatile private var session: SdmSession? = null

    fun scan() {
        val devs = try { usb.deviceList.values.toList() } catch (_: Exception) { emptyList() }
        ports = devs.flatMap { DmPorts.find(it) }
        val status = when {
            devs.isEmpty() -> "No USB device. Use an OTG adapter (this phone = host) and set the Samsung to DM mode with *#0808#."
            ports.isEmpty() -> "Found ${devs.joinToString { it.productNameSafe() }} but no DM interface. On the Samsung choose *#0808# › RNDIS + ACM + DM (or DM + MODEM + ADB) and reboot it."
            else -> "${ports.size} possible DM interface(s). If no data comes, tap Next interface."
        }
        _s.update { it.copy(ports = ports.map { p -> p.label }, portIndex = 0, usbStatus = status) }
    }

    fun nextPort() {
        if (ports.isEmpty()) return
        _s.update { it.copy(portIndex = (it.portIndex + 1) % ports.size) }
    }

    fun startUsb() {
        if (session != null) return
        if (ports.isEmpty()) scan()
        val port = ports.getOrNull(_s.value.portIndex) ?: return
        viewModelScope.launch {
            _s.update { it.copy(busy = true) }
            if (!usb.hasPermission(port.device)) {
                _s.update { it.copy(usbStatus = "Allow USB access in the popup…") }
                requestPermission(port.device)
                var waited = 0
                while (!usb.hasPermission(port.device) && waited < 30000) { delay(500); waited += 500 }
                if (!usb.hasPermission(port.device)) {
                    _s.update { it.copy(busy = false, usbStatus = "USB permission not granted.") }
                    return@launch
                }
            }
            val conn = usb.openDevice(port.device)
            if (conn == null || !conn.claimInterface(port.intf, true)) {
                conn?.close()
                _s.update { it.copy(busy = false, usbStatus = "Could not open interface #${port.intf.id}. Try Next interface.") }
                return@launch
            }
            val name = port.device.deviceName
            val t = UsbSdmTransport(conn, port) { usb.deviceList.containsKey(name) }
            run(t)
        }
    }

    private fun requestPermission(dev: UsbDevice) {
        val ctx = getApplication<Application>()
        val intent = Intent("com.radiokpi.app.USB_PERMISSION").setPackage(ctx.packageName)
        val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
        usb.requestPermission(dev, PendingIntent.getBroadcast(ctx, 7, intent, flags))
    }

    fun checkRootNodes() {
        viewModelScope.launch {
            _s.update { it.copy(busy = true) }
            val found = withContext(Dispatchers.IO) {
                val r = Shell.run("ls " + RootSdmTransport.CANDIDATES.joinToString(" ") + " 2>/dev/null", root = true)
                r.out.lines().map { it.trim() }.filter { it in RootSdmTransport.CANDIDATES }
            }
            _s.update { it.copy(busy = false, rootChecked = true, rootNodes = found) }
        }
    }

    fun startRoot(node: String) {
        if (session != null) return
        viewModelScope.launch {
            _s.update { it.copy(busy = true) }
            val t = RootSdmTransport(getApplication(), node)
            val ok = withContext(Dispatchers.IO) { try { t.open(); true } catch (e: Exception) { false } }
            if (!ok) { _s.update { it.copy(busy = false, usbStatus = "Root shell failed.") }; return@launch }
            run(t)
        }
    }

    private fun run(t: SdmTransport) {
        val ctx = getApplication<Application>()
        val tag = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val dir = File(ctx.getExternalFilesDir("logs") ?: ctx.filesDir, "samsung_diag_$tag")
        val s = SdmSession(t, dir, { live ->
            _s.update { it.copy(live = live, noDataHint = live.running && !live.gotData && System.currentTimeMillis() - live.startedAt > 8000) }
        })
        session = s
        _s.update { it.copy(busy = false, lastOutDir = dir.absolutePath) }
        Thread({
            try { s.run() } finally {
                session = null
                _s.update { it.copy(live = s.snapshot().copy(running = false)) }
            }
        }, "sdm-session").start()
    }

    fun stop() { session?.stop() }

    /** Files of the last capture, for the share sheet. */
    fun lastFiles(): List<File> {
        val d = _s.value.lastOutDir?.let { File(it) } ?: return emptyList()
        return listOf("summary.md", "l3_log.csv", "l3.pcap", "capture.sdmraw").map { File(d, it) }.filter { it.exists() && it.length() > 0 }
    }

    override fun onCleared() { session?.stop() }
}
