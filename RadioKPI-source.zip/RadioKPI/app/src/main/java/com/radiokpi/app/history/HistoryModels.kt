package com.radiokpi.app.history

/** Time ranges for the History tab, with the bucket size used to aggregate samples. */
enum class Range(val label: String, val ms: Long, val bucketMs: Long) {
    H1("1 h", 3_600_000L, 60_000L),
    H6("6 h", 6 * 3_600_000L, 5 * 60_000L),
    H24("24 h", 24 * 3_600_000L, 15 * 60_000L),
    D3("3 d", 3 * 86_400_000L, 3_600_000L),
    D7("7 d", 7 * 86_400_000L, 2 * 3_600_000L),
    D14("14 d", 14 * 86_400_000L, 4 * 3_600_000L)
}

data class Bucket(
    val t: Long,
    val samples: Int,
    val levelAvg: Float?,
    val levelMin: Int?,
    val levelMax: Int?,
    val sinrAvg: Float?,
    val rsrqAvg: Float?,
    val cqiAvg: Float?,
    val goodPct: Float,
    val noServicePct: Float,
    val fiveGPct: Float,
    val caPct: Float
)

data class TechBucket(val t: Long, val counts: Map<String, Int>) {
    val total: Int get() = counts.values.sum()
}

data class CountBucket(val t: Long, val count: Int)

data class HourProfile(val hour: Int, val samples: Int, val levelAvg: Float?, val sinrAvg: Float?)

data class CellRow(val cell: String, val samples: Int, val levelAvg: Float?, val sinrAvg: Float?, val band: String?)

data class RangeSummary(
    val samples: Int,
    val firstTs: Long?,
    val lastTs: Long?,
    val levelAvg: Float?,
    val levelMin: Int?,
    val levelMax: Int?,
    val sinrAvg: Float?,
    val rsrqAvg: Float?,
    val goodPct: Float,
    val sinrGoodPct: Float?,
    val availabilityPct: Float,
    val fiveGPct: Float,
    val caPct: Float,
    val anomalies: Int,
    val cellChanges: Int,
    val uniqueCells: Int
)

data class HistoryData(
    val range: Range,
    val from: Long,
    val to: Long,
    val summary: RangeSummary,
    val buckets: List<Bucket>,
    val tech: List<TechBucket>,
    val techTotals: Map<String, Int>,
    val bandTotals: Map<String, Int>,
    val anomalyBuckets: List<CountBucket>,
    val anomalyTypes: Map<String, Int>,
    val mobilityBuckets: List<CountBucket>,
    val hours: List<HourProfile>,
    val cells: List<CellRow>,
    val dbSamples: Long,
    val dbSizeKb: Long
)

/** Fixed colours per technology label, shared by app charts and the HTML report. */
object TechColors {
    fun hex(tech: String): String = when {
        tech.startsWith("5G") -> "#A78BFA"
        tech.startsWith("4G") -> "#22D3EE"
        tech.startsWith("3G") -> "#EAB308"
        tech.startsWith("2G") -> "#F97316"
        tech == "No service" -> "#EF4444"
        else -> "#6B7280"
    }
}
