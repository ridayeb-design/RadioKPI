package com.radiokpi.app.radio

import android.content.Context
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager

/** TelephonyManager bound to the SIM used for mobile data (ignores the second SIM on dual-SIM phones). */
object DataSim {
    fun manager(ctx: Context): TelephonyManager {
        val base = ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        return try {
            val sub = SubscriptionManager.getDefaultDataSubscriptionId()
            if (sub != SubscriptionManager.INVALID_SUBSCRIPTION_ID) base.createForSubscriptionId(sub) else base
        } catch (_: Exception) {
            base
        }
    }
}
