package com.radiokpi.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.radiokpi.app.history.CountBucket
import com.radiokpi.app.history.HistoryData
import com.radiokpi.app.history.HistoryReport
import com.radiokpi.app.history.HistoryUi
import com.radiokpi.app.history.HourProfile
import com.radiokpi.app.history.Range
import com.radiokpi.app.history.TechBucket
import com.radiokpi.app.history.TechColors
import com.radiokpi.app.radio.Grade
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class HistoryActions(
    val onRange: (Range) -> Unit,
    val onRefresh: () -> Unit,
    val onReport: () -> Unit,
    val onCsv: () -> Unit,
    val onClear: () -> Unit,
    val onToggle247: () -> Unit,
    val onBatterySettings: () -> Unit
)

private fun hexColor(h: String): Color = Color(android.graphics.Color.parseColor(h))

private val LEVEL_BANDS = listOf(
    -80f to C.grade(Grade.EXCELLENT), -90f to C.grade(Grade.GOOD), -100f to C.grade(Grade.FAIR),
    -110f to C.grade(Grade.POOR), -140f to C.grade(Grade.BAD)
)
private val SINR_BANDS = listOf(
    20f to C.grade(Grade.EXCELLENT), 13f to C.grade(Grade.GOOD), 0f to C.grade(Grade.FAIR), -10f to C.grade(Grade.POOR)
)

@Composable
fun HistoryTab(h: HistoryUi, background: Boolean, a: HistoryActions) {
    LaunchedEffect(Unit) { a.onRefresh() }

    // ---- 24/7 collection
    Panel(title = "24/7 collection", trailing = if (background) "ON" else "off") {
        Text(
            if (background) "Collecting in the background, even with the screen off. A notification shows the live status."
            else "Turn on to keep measuring when the app is closed. Every sample is stored for 14 days and charted here.",
            color = C.Muted, fontSize = 12.sp
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = a.onToggle247,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (background) C.Rec else C.Accent, contentColor = if (background) C.Text else C.Bg
                )
            ) { Text(if (background) "Stop 24/7" else "Start 24/7", fontWeight = FontWeight.Bold) }
            OutlinedButton(onClick = a.onBatterySettings) { Text("Battery settings", color = C.Text) }
        }
        Text(
            "On OPPO/ColorOS also allow: Settings › Battery › Radio KPI › \"Allow background activity\", and lock the app in Recents.",
            color = C.Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp)
        )
    }

    // ---- Range selector
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Range.values().forEach { r -> Chip(r.label, h.range == r) { a.onRange(r) } }
    }

    val d = h.data
    if (h.loading && d == null) {
        Panel { Text("Loading…", color = C.Muted) }
        return
    }
    h.error?.let { Panel { Text("Error: $it", color = C.grade(Grade.BAD)) } }
    if (d == null) return

    val s = d.summary
    if (s.samples == 0) {
        Panel(title = "No data yet") {
            Text("Nothing stored in the last ${d.range.label}. Keep the app measuring (or start 24/7) and come back.",
                color = C.Muted, fontSize = 13.sp)
        }
        StorageRow(d, a)
        return
    }

    // ---- Summary tiles
    fun f1(v: Float?) = v?.let { "%.1f".format(it) } ?: "—"
    fun pct(v: Float?) = v?.let { "%.1f%%".format(it) } ?: "—"
    val tiles = listOf(
        "Availability" to pct(s.availabilityPct), "Avg level" to "${f1(s.levelAvg)} dBm",
        "Good coverage" to pct(s.goodPct), "Avg SINR" to "${f1(s.sinrAvg)} dB",
        "SINR ≥ 13 dB" to pct(s.sinrGoodPct), "Anomalies" to s.anomalies.toString(),
        "Cell changes" to s.cellChanges.toString(), "Cells seen" to s.uniqueCells.toString()
    )
    tiles.chunked(2).forEach { row ->
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            row.forEach { (l, v) -> KpiTile(l, v, modifier = Modifier.weight(1f)) }
        }
    }

    val gap = d.range.bucketMs * 3
    TimeChart("Signal level", "dBm", d, d.buckets.map { it.t to it.levelAvg },
        d.buckets.map { Triple(it.t, it.levelMin?.toFloat(), it.levelMax?.toFloat()) },
        -140f, -40f, LEVEL_BANDS, C.Accent, gap)
    TimeChart("SINR", "dB", d, d.buckets.map { it.t to it.sinrAvg }, null, -10f, 30f, SINR_BANDS, C.Accent2, gap)
    if (d.buckets.any { it.rsrqAvg != null }) {
        TimeChart("RSRQ", "dB", d, d.buckets.map { it.t to it.rsrqAvg }, null, -25f, -5f,
            listOf(-10f to C.grade(Grade.EXCELLENT), -15f to C.grade(Grade.GOOD), -20f to C.grade(Grade.FAIR), -25f to C.grade(Grade.POOR)),
            Color(0xFF38BDF8), gap)
    }
    TimeChart("Good coverage per period", "%", d, d.buckets.map { it.t to it.goodPct }, null, 0f, 100f, emptyList(),
        C.grade(Grade.EXCELLENT), gap)

    StackedTech(d)
    CountBars("Anomalies per period", d, d.anomalyBuckets, C.grade(Grade.POOR))
    if (d.anomalyTypes.isNotEmpty()) {
        Panel(title = "Anomalies by type") {
            val max = d.anomalyTypes.values.maxOrNull()?.toFloat() ?: 1f
            d.anomalyTypes.forEach { (t, n) -> ValueBar(HistoryReport.anomalyTitle(t), n.toString(), n / max, C.grade(Grade.POOR)) }
        }
    }
    CountBars("Cell changes per period", d, d.mobilityBuckets, Color(0xFF60A5FA))
    if (d.hours.size >= 2) HourChart(d.hours)

    if (d.bandTotals.isNotEmpty()) {
        Panel(title = "Band share") {
            d.bandTotals.forEach { (b, n) ->
                val p = n * 100f / s.samples
                ValueBar(b, "%.1f%%".format(p), p / 100f, if (b.startsWith("n")) C.Accent2 else C.Accent)
            }
        }
    }
    if (d.cells.isNotEmpty()) {
        Panel(title = "Most used cells") {
            d.cells.forEach { c ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Text(c.cell, color = C.Text, fontSize = 13.sp, modifier = Modifier.weight(2f))
                    Text("${c.samples}", color = C.Muted, fontSize = 12.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                    Text(f1(c.levelAvg), color = C.Text, fontSize = 12.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                    Text(f1(c.sinrAvg), color = C.Text, fontSize = 12.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f))
                }
            }
            Text("cell · samples · avg level · avg SINR", color = C.Muted, fontSize = 11.sp)
        }
    }
    StorageRow(d, a)
}

@Composable
private fun StorageRow(d: HistoryData, a: HistoryActions) {
    var confirm by remember { mutableStateOf(false) }
    Panel(title = "Stored data", trailing = "${d.dbSamples} samples · ${d.dbSizeKb / 1024} MB") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = a.onReport, colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.Bg)) {
                Text("Report", fontWeight = FontWeight.Bold)
            }
            OutlinedButton(onClick = a.onCsv) { Text("CSV", color = C.Text) }
            OutlinedButton(onClick = { if (confirm) { a.onClear(); confirm = false } else confirm = true }) {
                Text(if (confirm) "Tap to confirm" else "Clear", color = if (confirm) C.Rec else C.Text)
            }
        }
        Text("Report = HTML with all charts for the selected range (opens in any browser, print to PDF). Data older than 14 days is deleted automatically.",
            color = C.Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

private fun timeLabels(d: HistoryData): List<String> {
    val f = SimpleDateFormat(if (d.range.ms <= 86_400_000L) "HH:mm" else "dd/MM", Locale.US)
    return (0..4).map { i -> f.format(Date(d.from + (d.to - d.from) * i / 4)) }
}

@Composable
private fun XAxis(d: HistoryData) {
    Row(Modifier.fillMaxWidth().padding(start = 34.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        timeLabels(d).forEach { Text(it, color = C.Muted, fontSize = 10.sp) }
    }
}

@Composable
private fun TimeChart(
    title: String, unit: String, d: HistoryData,
    points: List<Pair<Long, Float?>>, envelope: List<Triple<Long, Float?, Float?>>?,
    yMin: Float, yMax: Float, bands: List<Pair<Float, Color>>, color: Color, gapMs: Long
) {
    val last = points.lastOrNull { it.second != null }?.second
    Panel(title = title, trailing = last?.let { "latest " + "%.1f".format(it) + " " + unit }) {
        Row {
            Column(Modifier.height(140.dp).width(34.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Text(yMax.toInt().toString(), color = C.Muted, fontSize = 10.sp)
                Text(((yMax + yMin) / 2).toInt().toString(), color = C.Muted, fontSize = 10.sp)
                Text(yMin.toInt().toString(), color = C.Muted, fontSize = 10.sp)
            }
            Canvas(Modifier.weight(1f).height(140.dp)) {
                val w = size.width
                val hh = size.height
                val span = (d.to - d.from).coerceAtLeast(1).toFloat()
                fun x(t: Long) = (t - d.from) / span * w
                fun y(v: Float) = hh - (v.coerceIn(yMin, yMax) - yMin) / (yMax - yMin) * hh
                var top = yMax
                bands.forEach { (lower, c) ->
                    drawRect(c.copy(alpha = 0.09f), Offset(0f, y(top)), Size(w, y(lower) - y(top)))
                    top = lower
                }
                envelope?.forEach { (t, lo, hi) ->
                    if (lo != null && hi != null) {
                        drawLine(color.copy(alpha = 0.25f), Offset(x(t), y(lo)), Offset(x(t), y(hi)), strokeWidth = 3.dp.toPx())
                    }
                }
                val path = Path()
                var prev: Long? = null
                points.forEach { (t, v) ->
                    if (v == null) { prev = null; return@forEach }
                    val p = prev
                    if (p == null || t - p > gapMs) path.moveTo(x(t), y(v)) else path.lineTo(x(t), y(v))
                    prev = t
                }
                drawPath(path, color, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                if (points.count { it.second != null } == 1) {
                    points.first { it.second != null }.let { (t, v) -> drawCircle(color, 3.dp.toPx(), Offset(x(t), y(v!!))) }
                }
            }
        }
        XAxis(d)
    }
}

@Composable
private fun StackedTech(d: HistoryData) {
    Panel(title = "Technology share over time") {
        Canvas(Modifier.fillMaxWidth().height(110.dp)) {
            val w = size.width
            val hh = size.height
            val span = (d.to - d.from).coerceAtLeast(1).toFloat()
            val bw = (d.range.bucketMs / span * w).coerceAtLeast(1.5f)
            d.tech.forEach { b: TechBucket ->
                val x = (b.t - d.from) / span * w
                var acc = 0f
                b.counts.entries.sortedBy { it.key }.forEach { (tech, n) ->
                    val frac = n.toFloat() / b.total.coerceAtLeast(1)
                    drawRect(hexColor(TechColors.hex(tech)), Offset(x, hh - hh * (acc + frac)), Size(bw * 0.9f, hh * frac))
                    acc += frac
                }
            }
        }
        XAxisPlain(d)
        Spacer(Modifier.height(6.dp))
        val total = d.techTotals.values.sum().coerceAtLeast(1)
        d.techTotals.entries.sortedByDescending { it.value }.forEach { (t, n) ->
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                Box(Modifier.size(10.dp).clip(RoundedCornerShape(2.dp)).background(hexColor(TechColors.hex(t))))
                Spacer(Modifier.width(6.dp))
                Text(t, color = C.Text, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Text("%.1f%%".format(n * 100f / total), color = C.Muted, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
private fun XAxisPlain(d: HistoryData) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        timeLabels(d).forEach { Text(it, color = C.Muted, fontSize = 10.sp) }
    }
}

@Composable
private fun CountBars(title: String, d: HistoryData, counts: List<CountBucket>, color: Color) {
    val total = counts.sumOf { it.count }
    Panel(title = title, trailing = "$total total") {
        val max = (counts.maxOfOrNull { it.count } ?: 0).coerceAtLeast(1).toFloat()
        Canvas(Modifier.fillMaxWidth().height(80.dp)) {
            val w = size.width
            val hh = size.height
            val span = (d.to - d.from).coerceAtLeast(1).toFloat()
            val bw = (d.range.bucketMs / span * w).coerceAtLeast(2f)
            drawLine(C.Border, Offset(0f, hh), Offset(w, hh))
            counts.forEach { c ->
                val x = (c.t - d.from) / span * w
                val bh = hh * c.count / max
                drawRect(color, Offset(x, hh - bh), Size(bw * 0.85f, bh))
            }
        }
        XAxisPlain(d)
        Text("peak ${max.toInt()} per ${bucketLabel(d.range)}", color = C.Muted, fontSize = 11.sp)
    }
}

private fun bucketLabel(r: Range): String {
    val m = r.bucketMs / 60_000
    return if (m < 60) "$m min" else "${m / 60} h"
}

@Composable
private fun HourChart(hours: List<HourProfile>) {
    var metric by remember { mutableStateOf("level") }
    Panel(title = "Hour-of-day profile") {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip("Level", metric == "level") { metric = "level" }
            Chip("SINR", metric == "sinr") { metric = "sinr" }
        }
        Spacer(Modifier.height(8.dp))
        val (lo, hi) = if (metric == "level") -130f to -50f else -10f to 30f
        Canvas(Modifier.fillMaxWidth().height(110.dp)) {
            val slot = size.width / 24f
            val hh = size.height
            for (hr in 0 until 24) {
                val p = hours.firstOrNull { it.hour == hr } ?: continue
                val v = (if (metric == "level") p.levelAvg else p.sinrAvg) ?: continue
                val frac = ((v - lo) / (hi - lo)).coerceIn(0.03f, 1f)
                val col = hexColor(if (metric == "level") HistoryReport.levelColor(v) else HistoryReport.sinrColor(v))
                drawRect(col, Offset(hr * slot + 2f, hh - hh * frac), Size(slot - 4f, hh * frac))
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            listOf("0h", "6h", "12h", "18h", "23h").forEach { Text(it, color = C.Muted, fontSize = 10.sp) }
        }
        Text("Average per hour of day across the range. Dips at busy hours suggest cell load or interference.",
            color = C.Muted, fontSize = 11.sp)
    }
}
