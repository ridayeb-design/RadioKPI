package com.radiokpi.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.radiokpi.app.UiState
import com.radiokpi.app.analysis.Anomaly
import com.radiokpi.app.analysis.FindingLevel
import com.radiokpi.app.analysis.Insights
import com.radiokpi.app.analysis.Severity
import com.radiokpi.app.radio.Grade
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun severityColor(s: Severity): Color = when (s) {
    Severity.CRITICAL -> C.grade(Grade.BAD)
    Severity.MAJOR -> C.grade(Grade.POOR)
    Severity.MINOR -> C.grade(Grade.FAIR)
}

private fun findingColor(l: FindingLevel): Color = when (l) {
    FindingLevel.BAD -> C.grade(Grade.BAD)
    FindingLevel.WARN -> C.grade(Grade.POOR)
    FindingLevel.INFO -> C.Accent
    FindingLevel.GOOD -> C.grade(Grade.EXCELLENT)
}

private fun scoreColor(score: Int): Color = when {
    score >= 85 -> C.grade(Grade.EXCELLENT)
    score >= 70 -> C.grade(Grade.GOOD)
    score >= 55 -> C.grade(Grade.FAIR)
    score >= 40 -> C.grade(Grade.POOR)
    else -> C.grade(Grade.BAD)
}

@Composable
fun AnalysisTab(state: UiState, a: Actions) {
    val k = state.kpis
    val events = state.anomalies
    val now = state.snapshot?.timestamp ?: System.currentTimeMillis()
    val score = Insights.score(k, events, now)

    // ---- Health score
    Panel(title = "Network health", trailing = "${k.samples} samples") {
        if (score == null) {
            Text(
                "Collecting data… the score appears after ${Insights.MIN_SAMPLES} samples. " +
                    "Anomalies below are detected live.",
                color = C.Muted, fontSize = 13.sp
            )
        } else {
            val col = scoreColor(score.total)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(110.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.size(110.dp)) {
                        val sw = 10.dp.toPx()
                        val arc = Size(size.width - sw, size.height - sw)
                        val tl = Offset(sw / 2, sw / 2)
                        drawArc(C.Surface2, 135f, 270f, false, tl, arc, style = Stroke(sw, cap = StrokeCap.Round))
                        drawArc(col, 135f, 270f * score.total / 100f, false, tl, arc, style = Stroke(sw, cap = StrokeCap.Round))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(score.total.toString(), color = C.Text, fontSize = 32.sp, fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace)
                        Text(score.verdict, color = col, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    ScorePart("Coverage", score.coverage, 40f)
                    ScorePart("Quality", score.quality, 30f)
                    ScorePart("Availability", score.availability, 20f)
                    ScorePart("Stability", score.stability, 10f)
                }
            }
        }
    }

    // ---- Severity counters
    val sev = Insights.countsBySeverity(events)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Severity.values().forEach { s ->
            KpiTile(s.label, (sev[s] ?: 0).toString(), color = severityColor(s), modifier = Modifier.weight(1f))
        }
    }

    // ---- Findings
    val findings = Insights.findings(k, events)
    if (findings.isNotEmpty()) {
        Panel(title = "Findings and recommendations") {
            findings.forEach { f ->
                val col = findingColor(f.level)
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Box(Modifier.width(4.dp).height(44.dp).clip(RoundedCornerShape(2.dp)).background(col))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(f.title, color = col, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(f.text, color = C.Text, fontSize = 13.sp)
                    }
                }
            }
        }
    }

    // ---- Anomalies by type
    val byType = Insights.countsByType(events)
    if (byType.isNotEmpty()) {
        val max = byType.maxOf { it.second }.toFloat()
        Panel(title = "Anomalies by type", trailing = "${events.size} total") {
            byType.forEach { (t, n) ->
                ValueBar(t.title, n.toString(), n / max, severityColor(t.severity))
            }
        }
    }

    // ---- Worst cells
    val worst = Insights.worstCells(k, events)
    if (worst.isNotEmpty()) {
        Panel(title = "Cells to check") {
            Row(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
                listOf("Cell" to 2f, "Avg" to 1f, "SINR" to 1f, "Issues" to 0.9f).forEach { (h, w) ->
                    Text(h, color = C.Muted, fontSize = 11.sp, modifier = Modifier.weight(w))
                }
            }
            worst.forEach { w ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(w.stat.label, color = C.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(2f))
                    Text(w.stat.avgLevel?.let { "%.0f".format(it) } ?: "—", color = C.Text, fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text(w.stat.avgSinr?.let { "%.1f".format(it) } ?: "—", color = C.Text, fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
                    Text(w.anomalies.toString(), color = if (w.anomalies > 0) C.grade(Grade.POOR) else C.Muted, fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.9f))
                }
            }
        }
    }

    // ---- Event timeline
    var showAll by rememberSaveable { mutableStateOf(false) }
    Panel(title = "Event timeline", trailing = if (events.isEmpty()) "none yet" else "newest first") {
        if (events.isEmpty()) {
            Text("No anomalies detected so far.", color = C.Muted, fontSize = 13.sp)
        }
        val list = events.asReversed()
        (if (showAll) list.take(200) else list.take(15)).forEach { EventRow(it) }
        if (list.size > 15) {
            OutlinedButton(onClick = { showAll = !showAll }) {
                Text(if (showAll) "Show less" else "Show all (${minOf(list.size, 200)})", color = C.Text)
            }
        }
    }

    // ---- Actions
    Panel(title = "Report") {
        Text(
            "Exports an HTML report with score, KPIs, findings, cells to check, band usage and the full event log " +
                "(with map links). Opens in any browser and can be printed to PDF.",
            color = C.Muted, fontSize = 12.sp
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = a.onExportReport, enabled = k.samples > 0,
                colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.Bg)
            ) { Text("Export report", fontWeight = FontWeight.Bold) }
            OutlinedButton(onClick = a.onReset) { Text("New session", color = C.Text) }
        }
    }
}

@Composable
private fun ScorePart(label: String, value: Float, max: Float) {
    ValueBar(label, "%.0f/%.0f".format(value, max), value / max, C.Accent)
}

private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

@Composable
private fun EventRow(e: Anomaly) {
    val col = severityColor(e.type.severity)
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Box(Modifier.padding(top = 5.dp).size(9.dp).clip(RoundedCornerShape(50)).background(col))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(e.type.title, color = C.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text(timeFmt.format(Date(e.start)), color = C.Muted, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            }
            Text(e.detail, color = C.Muted, fontSize = 12.sp)
            val extra = listOfNotNull(
                e.cell,
                if (e.ongoing) "ongoing ${e.durationS}s" else if (e.durationS > 0) "${e.durationS}s" else null,
                if (e.lat != null && e.lon != null) "%.5f, %.5f".format(e.lat, e.lon) else null
            ).joinToString(" · ")
            if (extra.isNotBlank()) {
                Text(extra, color = if (e.ongoing) col else C.Muted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}
