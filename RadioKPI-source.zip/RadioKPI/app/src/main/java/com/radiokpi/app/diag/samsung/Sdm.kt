package com.radiokpi.app.diag.samsung

// Samsung Shannon "SDM" diagnostic protocol (DM port).
// Ported from SCAT (https://github.com/fgsect/scat, GPL-2.0): framing, init/stop
// sequence and the LTE log item layouts. Pure Kotlin, no Android dependencies,
// so it is unit-tested against SCAT's own real-modem test vectors.

import java.util.Locale

private fun hex(s: String): ByteArray = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it.toInt() and 0xff) }

internal fun ByteArray.u8(i: Int) = this[i].toInt() and 0xff
internal fun ByteArray.u16(i: Int) = u8(i) or (u8(i + 1) shl 8)
internal fun ByteArray.s16(i: Int) = u16(i).toShort().toInt()
internal fun ByteArray.u32(i: Int): Long = (u16(i).toLong()) or (u16(i + 2).toLong() shl 16)

object SdmCmd {
    const val DIR_TO_MODEM = 0xA0
    const val GROUP_CONTROL = 0x00
    const val GROUP_COMMON = 0x01
    const val GROUP_LTE = 0x02
    const val GROUP_EDGE = 0x03
    const val GROUP_HSPA = 0x04
    const val GROUP_TRACE = 0x05
    const val GROUP_IP = 0x07

    /** SCAT generate_sdm_packet(): 0x7F + '<HBHHBBBL' header + payload + 0x7E. */
    fun packet(group: Int, command: Int, payload: ByteArray, direction: Int = DIR_TO_MODEM, timestamp: Long = 0): ByteArray {
        val pktLen = 2 + 3 + 4 + payload.size + 2
        val out = ByteArray(1 + 14 + payload.size + 1)
        var p = 0
        fun b(v: Int) { out[p++] = v.toByte() }
        fun h(v: Int) { b(v and 0xff); b((v shr 8) and 0xff) }
        b(0x7F)
        h(pktLen + 3); b(0); h(pktLen); h(0)
        b(direction); b(group); b(command)
        b((timestamp and 0xff).toInt()); b(((timestamp shr 8) and 0xff).toInt())
        b(((timestamp shr 16) and 0xff).toInt()); b(((timestamp shr 24) and 0xff).toInt())
        payload.copyInto(out, p); p += payload.size
        b(0x7E)
        return out
    }

    private fun sel(count: Int, vararg items: Int): ByteArray {
        val o = ByteArray(1 + items.size * 2); o[0] = count.toByte()
        items.forEachIndexed { i, it -> o[1 + i * 2] = it.toByte(); o[2 + i * 2] = 1 }
        return o
    }

    private val LTE_ITEMS = intArrayOf(
        0x00, 0x01, 0x02, 0x10, 0x11, 0x17, 0x39, 0x3A, 0x50, 0x51, 0x53, 0x55, 0x57, 0x58, 0x59,
        0x5B, 0x5C, 0x5D, 0x5E, 0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79,
        0x52, 0x54,   // RRC OTA + ASN version (layer rrc)
        0x5A, 0x5F    // NAS EMM + ESM (layer nas)
    )

    /** Exactly SCAT SamsungParser.init_diag() with layers rrc+nas (byte-identical, see test). */
    fun initSequence(): List<ByteArray> {
        val c = GROUP_CONTROL
        val l = mutableListOf<ByteArray>()
        l += packet(c, 0x00, hex("41414141"))                      // CONTROL_START
        l += packet(c, 0x06, byteArrayOf(5))                         // CHANGE_UPDATE_PERIOD
        for (cmd in intArrayOf(0x10, 0x20, 0x30, 0x40, 0x44)) l += packet(c, cmd, byteArrayOf(0)) // deselect all
        l += packet(c, 0x10, sel(9, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x08, 0x09))            // COMMON
        l += packet(c, 0x20, sel(LTE_ITEMS.size, *LTE_ITEMS))                                   // LTE
        l += packet(c, 0x30, sel(6, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0B))                        // EDGE
        l += packet(c, 0x40, sel(6, 0x10, 0x1B, 0x1C, 0x1D, 0x20, 0x22))                        // HSPA
        l += packet(c, 0x44, byteArrayOf(0xff.toByte()))                                        // CDMA
        for (cmd in intArrayOf(0x12, 0x22, 0x32, 0x42, 0x46)) l += packet(c, cmd, byteArrayOf(0xff.toByte())) // refresh
        repeat(2) { l += packet(c, 0x52, byteArrayOf(1)); l += packet(c, 0x52, byteArrayOf(2)) } // TRACE_STOP
        l += packet(c, 0x72, ByteArray(0))                           // ILM_STOP
        l += packet(c, 0xC0, ByteArray(0))                           // TRIGGER_TABLE
        l += packet(c, 0x90, byteArrayOf(0xdc.toByte(), 0x05, 0xdc.toByte(), 0x05)) // TCPIP_DUMP 1500/1500
        return l
    }

    fun stopSequence(): List<ByteArray> = listOf(
        packet(GROUP_CONTROL, 0x02, ByteArray(4)),
        packet(GROUP_CONTROL, 0x90, ByteArray(4))
    )
}

data class SdmHeader(
    val length1: Int, val length2: Int, val stamp: Int, val direction: Int,
    val groupRaw: Int, val command: Int, val timestamp: Long
) {
    val radioId: Int get() = groupRaw shr 5
    val group: Int get() = groupRaw and 0x1F
    companion object {
        fun parse(b: ByteArray, off: Int) = SdmHeader(
            b.u16(off), b.u16(off + 3), b.u16(off + 5), b.u8(off + 7),
            b.u8(off + 8), b.u8(off + 9), b.u32(off + 10)
        )
    }
}

/** Stream re-assembly, same rules as SCAT run_diag(). */
class SdmDeframer {
    companion object { const val MAX_LEN = 0x8000 }
    private var buf = ByteArray(0)
    var dropped = 0L; private set

    fun feed(data: ByteArray, len: Int = data.size): List<ByteArray> {
        val nb = ByteArray(buf.size + len)
        buf.copyInto(nb); data.copyInto(nb, buf.size, 0, len)
        buf = nb
        val out = mutableListOf<ByteArray>()
        var cur = 0
        while (cur < buf.size) {
            var pos = -1
            for (i in cur until buf.size) if (buf[i] == 0x7F.toByte()) { pos = i; break }
            if (pos < 0) { dropped += buf.size - cur; cur = buf.size; break }
            if (buf.size < pos + 15) { cur = pos; break }
            val h = SdmHeader.parse(buf, pos + 1)
            // Reject a false 0x7F start as soon as the header is visible (SCAT would wait here).
            if (h.length2 + 3 != h.length1 || h.length1 < 13 || h.length1 > MAX_LEN) { dropped++; cur = pos + 1; continue }
            if (buf.size < pos + 2 + h.length1) { cur = pos; break }
            if (buf.u8(pos + 1 + h.length1) != 0x7E) { dropped++; cur = pos + 1; continue }
            out += buf.copyOfRange(pos, pos + h.length1 + 2)
            cur = pos + h.length1 + 2
        }
        buf = if (cur >= buf.size) ByteArray(0) else buf.copyOfRange(cur, buf.size)
        if (buf.size > 1 shl 20) buf = ByteArray(0) // garbage guard
        return out
    }
}

data class NCell(val rat: String, val arfcn: Long, val pci: Int, val rssi: Double, val rsrp: Double, val rsrq: Double)

sealed class SdmEvent {
    data class StartResponse(val icdMajor: Int, val icdMinor: Int, val version: String, val date: String, val extra: String) : SdmEvent()
    data class RrcState(val state: Int) : SdmEvent() {
        val label: String get() = when (state) { 0 -> "IDLE"; 1 -> "CONNECTING"; 2 -> "CONNECTED"; else -> "UNKNOWN" }
    }
    data class ServingCell(val plmn: Long, val tac: Int, val cid: Long, val band: Int?) : SdmEvent()
    data class PhyCellInfo(
        val earfcn: Long, val pci: Int, val plmn: Long, val rssi: Double, val rsrp: Double, val rsrq: Double,
        val neighbours: List<NCell>
    ) : SdmEvent()
    data class RrcOta(val channel: String, val gsmtapSubtype: Int, val uplink: Boolean, val msg: ByteArray) : SdmEvent()
    data class Nas(val uplink: Boolean, val msg: ByteArray) : SdmEvent()
    data class Other(val group: Int, val command: Int, val len: Int) : SdmEvent()
}

/** Port of SCAT's control + LTE parsers for the items Radio KPI uses. */
class SdmParser {
    var icd: Pair<Int, Int> = Pair(4, 36)   // updated from the start response
    private fun icdAtLeast(maj: Int, min: Int) = icd.first > maj || (icd.first == maj && icd.second >= min)

    fun parse(pkt: ByteArray): SdmEvent? {
        if (pkt.size < 16 || pkt.u8(0) != 0x7F || pkt.u8(pkt.size - 1) != 0x7E) return null
        val h = SdmHeader.parse(pkt, 1)
        if (h.length2 + 3 != h.length1 || pkt.size != h.length1 + 2) return null
        if (h.direction != 0xA0 && h.direction != 0xA1) return null
        val p = pkt.copyOfRange(15, pkt.size - 1)
        return try {
            when ((h.group shl 8) or h.command) {
                0x0001 -> startResponse(p)
                0x0202 -> phyCellInfo(p)
                0x0250 -> servingCell(p)
                0x0251 -> if (p.isNotEmpty()) SdmEvent.RrcState(p.u8(0)) else null
                0x0252 -> rrcOta(p)
                0x025A, 0x025F -> nas(p)
                else -> SdmEvent.Other(h.group, h.command, p.size)
            }
        } catch (e: IndexOutOfBoundsException) { null }
    }

    private fun cstr(b: ByteArray, from: Int, to: Int): String {
        val end = minOf(to, b.size)
        if (from >= end) return ""
        var z = from; while (z < end && b[z] != 0.toByte()) z++
        return String(b, from, z - from, Charsets.ISO_8859_1)
    }

    private fun startResponse(p: ByteArray): SdmEvent? {
        if (p.size < 57) return null
        val v = p.copyOfRange(2, 27)
        val version = if (String(v, 0, 6, Charsets.ISO_8859_1) == "LibVer") {
            val l0 = v.u16(6); val l1 = v.u16(8); val l2 = v.u16(10)
            "LibVer: $l0.$l1.$l2, ASN: LTE Release ${v.u8(15)}.${v.u8(16)}.${v.u8(17)} (%02d.%02d), NR Release ${v.u8(20)}.${v.u8(21)}.${v.u8(22)} (%02d.%02d)"
                .format(v.u8(18), v.u8(19), v.u8(23), v.u8(24))
        } else cstr(v, 0, v.size)
        val date = cstr(p, 27, 52)
        val extraLen = p.u8(54)
        val extra = cstr(p, 57, 57 + extraLen)
        val min = (p.u8(55) and 0xf) + ((p.u8(55) and 0xf0) shr 4) * 10
        val maj = p.u8(56)
        if (maj > 0) icd = Pair(maj, min)
        return SdmEvent.StartResponse(maj, min, version, date, extra)
    }

    private fun phyCellInfo(p: ByteArray): SdmEvent? {
        val v540 = icdAtLeast(5, 40)
        val hl = if (v540) 29 else 27
        if (p.size < hl) return null
        var o = 0
        val plmn = p.u32(o); o += 4
        o += 4 // zero1
        val arfcn = if (v540) p.u32(o).also { o += 4 } else p.u16(o).toLong().also { o += 2 }
        val pci = p.u16(o); o += 2
        o += 2 // zero2
        val rssi = p.s16(o); o += 2
        o += 2 // reserved
        val rsrp = p.u32(o); o += 4
        val rsrq = p.u32(o); o += 4
        val n = p.u8(o); o += 1
        val nl = if (v540) 21 else 19
        val cells = mutableListOf<NCell>()
        if (n > 0 && p.size - hl == nl * n) {
            for (i in 0 until n) {
                var q = hl + i * nl
                val type = p.u8(q); q += 1
                val ea = if (v540) p.u32(q).also { q += 4 } else p.u16(q).toLong().also { q += 2 }
                val npci = p.u16(q); q += 2
                q += 2
                val nrssi = p.u16(q); q += 2
                val nrsrp = p.u32(q); q += 4
                val nrsrq = p.u32(q); q += 4
                var rsrqVal = nrsrq / -100.0
                val rat = when {
                    icdAtLeast(9, 0) -> when (type) { 0 -> "LTE"; 6 -> "NR"; else -> "T$type" }
                    icdAtLeast(7, 3) -> when (type) { 0 -> "GSM"; 1 -> "WCDMA"; 2 -> "LTE"; 6 -> "NR"; else -> "T$type" }
                    else -> when (type) {
                        0, 2 -> "LTE"; 1 -> "WCDMA"
                        3 -> { rsrqVal = (4294967296L - nrsrq) / -100.0; "GSM" }
                        6 -> "NR"; else -> "T$type"
                    }
                }
                cells += NCell(rat, ea, npci, nrssi / -100.0, nrsrp / -100.0, rsrqVal)
            }
        }
        return SdmEvent.PhyCellInfo(arfcn, pci, plmn, rssi / 100.0, rsrp / -100.0, rsrq / -100.0, cells)
    }

    private fun servingCell(p: ByteArray): SdmEvent? {
        val v541 = icdAtLeast(5, 41) && p.size >= 20
        if (p.size < 18) return null
        val cid = p.u32(0)
        val plmn = p.u32(12)
        val tacRaw = p.u16(16)
        val tac = ((tacRaw and 0xff) shl 8) or (tacRaw shr 8)
        val band = if (v541) p.u16(18) else null
        return SdmEvent.ServingCell(plmn, tac, cid, band)
    }

    private fun rrcOta(p: ByteArray): SdmEvent? {
        if (p.size < 4) return null
        val ch = p.u8(0); val dir = p.u8(1)
        val msg = p.copyOfRange(4, p.size)
        val (name, sub) = if (dir == 0) when (ch) {
            0 -> "DL-CCCH" to 0; 1 -> "PCCH" to 6; 2 -> "BCCH-BCH" to 4; 3 -> "BCCH-DL-SCH" to 5; 4 -> "DL-DCCH" to 1
            else -> "DL-ch$ch" to 0
        } else when (ch) {
            0 -> "UL-CCCH" to 2; 4 -> "UL-DCCH" to 3; else -> "UL-ch$ch" to 0
        }
        return SdmEvent.RrcOta(name, sub, dir != 0, msg)
    }

    private fun nas(p: ByteArray): SdmEvent? {
        if (p.size < 4) return null
        val len = p.u16(1)
        val msg = p.copyOfRange(4, p.size)
        if (len != msg.size) return null
        return SdmEvent.Nas(p.u8(0) != 0, msg)
    }
}

/** SCAT-identical text lines (used by the tests to compare with SCAT output). */
object SdmText {
    private fun f(d: Double) = String.format(Locale.US, "%.2f", d)
    fun of(e: SdmEvent): String = when (e) {
        is SdmEvent.RrcState -> "LTE RRC State: ${e.label}"
        is SdmEvent.ServingCell ->
            "LTE RRC Serving Cell: PLMN: ${e.plmn}, xTAC/xCID: ${Integer.toHexString(e.tac)}/${java.lang.Long.toHexString(e.cid)}" +
                (e.band?.let { ", Band: $it" } ?: "")
        is SdmEvent.PhyCellInfo -> buildString {
            append("LTE PHY Cell Info: EARFCN: ${e.earfcn}, PCI: ${e.pci}, PLMN: ${e.plmn}, RSSI: ${f(e.rssi)}, RSRP: ${f(e.rsrp)}, RSRQ: ${f(e.rsrq)}")
            e.neighbours.forEachIndexed { i, n ->
                val vals = "RSSI: ${f(n.rssi)}, RSRP: ${f(n.rsrp)}, RSRQ: ${f(n.rsrq)}"
                append("\n")
                append(when {
                    n.rat == "LTE" -> "LTE PHY Cell Info: NCell $i: EARFCN: ${n.arfcn}, PCI: ${n.pci}, $vals"
                    n.rat == "NR" -> "LTE PHY Cell Info: NCell $i (NR): NR-ARFCN: ${n.arfcn}, PCI: ${n.pci}, $vals"
                    n.rat == "WCDMA" -> "LTE PHY Cell Info: NCell $i (WCDMA): UARFCN: ${n.arfcn}, PSC: ${n.pci}, $vals"
                    n.rat == "GSM" -> "LTE PHY Cell Info: NCell $i (GSM): ARFCN: ${n.arfcn}, BSIC: ${n.pci}, $vals"
                    else -> "LTE PHY Cell Info: NCell $i (Type ${n.rat.drop(1)}): ARFCN: ${n.arfcn}, PCI: ${n.pci}, $vals"
                })
            }
        }
        is SdmEvent.StartResponse -> "SDM Start Response: Version: ${e.version}, ICD: ${e.icdMajor}.${e.icdMinor}, Date: ${e.date}" +
            (if (e.extra.isNotEmpty()) ", Extra: ${e.extra}" else "")
        is SdmEvent.RrcOta -> "LTE RRC ${e.channel} ${e.msg.toHex()}"
        is SdmEvent.Nas -> "LTE NAS ${if (e.uplink) "UL" else "DL"} ${e.msg.toHex()}"
        is SdmEvent.Other -> "SDM 0x%02x/0x%02x (%d bytes)".format(e.group, e.command, e.len)
    }
}

/** GSMTAP v2 header (SCAT util.create_gsmtap_header, version 2). */
object Gsmtap {
    const val TYPE_LTE_RRC = 0x0d
    const val TYPE_LTE_NAS = 0x12
    fun header(type: Int, subtype: Int = 0, arfcn: Int = 0): ByteArray {
        val a = if (arfcn < 0 || arfcn > 16383) 0 else arfcn
        return byteArrayOf(2, 4, type.toByte(), 0, (a shr 8).toByte(), (a and 0xff).toByte(), 0, 0, 0, 0, 0, 0,
            subtype.toByte(), 0, 0, 0)
    }
    /** dlEarfcn: last serving EARFCN, put in downlink RRC headers like SCAT does. */
    fun forEvent(e: SdmEvent, dlEarfcn: Long = 0): ByteArray? = when (e) {
        is SdmEvent.RrcOta -> header(TYPE_LTE_RRC, e.gsmtapSubtype, if (e.uplink) 0 else dlEarfcn.toInt()) + e.msg
        is SdmEvent.Nas -> header(TYPE_LTE_NAS) + e.msg
        else -> null
    }
}

/** pcap with Ethernet/IPv4/UDP→4729 framing, same as SCAT PcapWriter; opens directly in Wireshark. */
class PcapWriter(private val out: java.io.OutputStream) {
    private var ipId = 0
    init {
        out.write(le32(0xa1b2c3d4L) + le16(2) + le16(4) + le32(0) + le32(0) + le32(0xffff) + le32(1))
    }
    private fun le16(v: Int) = byteArrayOf((v and 0xff).toByte(), ((v shr 8) and 0xff).toByte())
    private fun le32(v: Long) = byteArrayOf((v and 0xff).toByte(), ((v shr 8) and 0xff).toByte(), ((v shr 16) and 0xff).toByte(), ((v shr 24) and 0xff).toByte())
    private fun be16(v: Int) = byteArrayOf(((v shr 8) and 0xff).toByte(), (v and 0xff).toByte())

    fun write(content: ByteArray, tsMillis: Long) {
        if (content.size > 65535 - 28) return
        val total = content.size + 8 + 20 + 14
        val eth = ByteArray(12) + byteArrayOf(0x08, 0x00)
        val ip = byteArrayOf(0x45, 0) + be16(content.size + 28) + be16(ipId) + byteArrayOf(0x40, 0, 0x40, 0x11) +
            be16(0xffff) + byteArrayOf(127, 0, 0, 1, 127, 0, 0, 1)
        val udp = be16(13337) + be16(4729) + be16(content.size + 8) + be16(0xffff)
        out.write(le32(tsMillis / 1000) + le32((tsMillis % 1000) * 1000) + le32(total.toLong()) + le32(total.toLong()))
        out.write(eth + ip + udp + content)
        ipId = (ipId + 1) and 0xffff
    }
}
