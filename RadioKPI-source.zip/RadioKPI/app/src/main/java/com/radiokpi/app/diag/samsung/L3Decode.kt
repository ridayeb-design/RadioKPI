package com.radiokpi.app.diag.samsung

// Light-weight LTE RRC (UPER, 3GPP TS 36.331) and EPS NAS (TS 24.301) decoders.
// They only decode the fields an RF/core engineer needs at a glance (message name,
// paging identity/domain, measurement report RSRP/RSRQ, handover target, release
// redirect, reject causes, SIB1 cell identity). Full decoding: open the pcap in Wireshark.

class BitReader(private val b: ByteArray) {
    var pos = 0; private set
    fun bit(): Int {
        val v = (b[pos ushr 3].toInt() shr (7 - (pos and 7))) and 1
        pos++; return v
    }
    fun bits(n: Int): Long { var v = 0L; repeat(n) { v = (v shl 1) or bit().toLong() }; return v }
    fun int(n: Int): Int = bits(n).toInt()
    fun skip(n: Int) { pos += n; if (pos > b.size * 8) throw IndexOutOfBoundsException() }
    /** UPER length determinant (unconstrained) in bits units for open types: returns octet count. */
    fun lengthDet(): Int {
        val first = int(8)
        return if (first and 0x80 == 0) first else ((first and 0x3f) shl 8) or int(8)
    }
    /** Skips extension additions of a SEQUENCE whose extension bit was set (open types). */
    fun skipExtensions() {
        val small = bit()
        val n = if (small == 0) int(6) + 1 else lengthDet()
        val present = (0 until n).count { bit() == 1 }
        repeat(present) { skip(lengthDet() * 8) }
    }
}

data class L3Info(
    val name: String,
    val detail: String = "",
    val tags: Set<String> = emptySet(),     // used for counters: PAGING, HO_CMD, REEST, SETUP, RELEASE, REJECT ...
    val values: Map<String, Any> = emptyMap()
)

object RrcLite {
    private val dlDcch = listOf("csfbParametersResponseCDMA2000", "dlInformationTransfer", "handoverFromEUTRAPreparationRequest",
        "mobilityFromEUTRACommand", "rrcConnectionReconfiguration", "rrcConnectionRelease", "securityModeCommand",
        "ueCapabilityEnquiry", "counterCheck", "ueInformationRequest", "loggedMeasurementConfiguration",
        "rnReconfiguration", "rrcConnectionResume", "spare3", "spare2", "spare1")
    private val ulDcch = listOf("csfbParametersRequestCDMA2000", "measurementReport", "rrcConnectionReconfigurationComplete",
        "rrcConnectionReestablishmentComplete", "rrcConnectionSetupComplete", "securityModeComplete", "securityModeFailure",
        "ueCapabilityInformation", "ulHandoverPreparationTransfer", "ulInformationTransfer", "counterCheckResponse",
        "ueInformationResponse", "proximityIndication", "rnReconfigurationComplete", "mbmsCountingResponse",
        "interFreqRSTDMeasurementIndication")
    private val dlCcch = listOf("rrcConnectionReestablishment", "rrcConnectionReestablishmentReject", "rrcConnectionReject", "rrcConnectionSetup")
    private val estCause = listOf("emergency", "highPriorityAccess", "mt-Access", "mo-Signalling", "mo-Data",
        "delayTolerantAccess", "mo-VoiceCall", "spare")
    private val reestCause = listOf("reconfigurationFailure", "handoverFailure", "otherFailure", "spare")
    private val relCause = listOf("loadBalancingTAUrequired", "other", "cs-FallbackHighPriority", "rrc-Suspend")
    private val bw = listOf("1.4", "3", "5", "10", "15", "20", "?", "?")
    private val sibNames = listOf("SIB2", "SIB3", "SIB4", "SIB5", "SIB6", "SIB7", "SIB8", "SIB9", "SIB10", "SIB11")

    fun rsrpDbm(v: Int) = v - 140
    fun rsrqDb(v: Int) = -20.0 + v * 0.5

    fun decode(channel: String, msg: ByteArray): L3Info = try {
        val r = BitReader(msg)
        when (channel) {
            "PCCH" -> paging(r)
            "BCCH-BCH" -> mib(r)
            "BCCH-DL-SCH" -> bcch(r)
            "DL-CCCH" -> if (r.bit() == 1) L3Info("DL-CCCH extension") else {
                val i = r.int(2)
                L3Info(dlCcch[i], tags = when (i) { 3 -> setOf("SETUP"); 2 -> setOf("REJECT", "SETUP_FAIL"); 1 -> setOf("REEST_FAIL"); else -> setOf("REEST_OK") })
            }
            "UL-CCCH" -> if (r.bit() == 1) L3Info("UL-CCCH extension") else if (r.bit() == 1) connRequest(r) else reestRequest(r)
            "UL-DCCH" -> if (r.bit() == 1) L3Info("UL-DCCH extension") else {
                val i = r.int(4)
                if (i == 1) measReport(r) else L3Info(ulDcch[i], tags = if (i == 2) setOf("RECONF_DONE") else emptySet())
            }
            "DL-DCCH" -> if (r.bit() == 1) L3Info("DL-DCCH extension") else {
                when (val i = r.int(4)) {
                    4 -> reconfiguration(r)
                    5 -> release(r)
                    3 -> L3Info("mobilityFromEUTRACommand", "Inter-RAT handover / CCO (e.g. SRVCC/CSFB)", setOf("IRAT_HO"))
                    else -> L3Info(dlDcch[i])
                }
            }
            else -> L3Info(channel)
        }
    } catch (e: Exception) { L3Info("$channel (undecoded)") }

    private fun paging(r: BitReader): L3Info {
        if (r.bit() == 1) return L3Info("paging extension")
        val hasList = r.bit(); val sysMod = r.bit(); val etws = r.bit(); r.bit()
        val parts = mutableListOf<String>()
        var cs = 0; var ps = 0; var n = 0
        val raw = mutableListOf<String>()
        if (hasList == 1) {
            n = r.int(4) + 1
            val ids = mutableListOf<String>()
            repeat(n) {
                r.bit() // PagingRecord extension marker
                r.bit() // ue-Identity extension marker
                val id = if (r.bit() == 0) "%d/%08X".format(r.int(8), r.bits(32)).also { raw += it }.let { "S-TMSI $it" }
                else { val len = r.int(4) + 6; "IMSI " + (0 until len).joinToString("") { r.int(4).toString() } }
                val dom = if (r.bit() == 0) "PS".also { ps++ } else "CS".also { cs++ }
                ids += "$id ($dom)"
            }
            parts += ids.take(3).joinToString(", ") + if (ids.size > 3) " +${ids.size - 3}" else ""
        }
        if (sysMod == 1) parts += "SI modification"
        if (etws == 1) parts += "ETWS"
        val tags = mutableSetOf("PAGING"); if (cs > 0) tags += "PAGING_CS"
        return L3Info("paging", parts.joinToString("; "), tags, mapOf("records" to n, "cs" to cs, "ps" to ps, "stmsi" to raw))
    }

    private fun mib(r: BitReader): L3Info {
        val b = r.int(3); r.skip(3); val sfn = r.int(8)
        return L3Info("MIB", "DL BW ${bw[b]} MHz, SFN ${sfn * 4}", values = mapOf("bwMhz" to bw[b]))
    }

    private fun bcch(r: BitReader): L3Info {
        if (r.bit() == 1) return L3Info("BCCH extension")
        return if (r.bit() == 0) {
            if (r.bit() == 1) return L3Info("systemInformation (future)")
            r.bit() // nonCriticalExtension present
            val n = r.int(5) + 1
            r.bit() // extension marker of the CHOICE
            val first = r.int(4)
            L3Info("systemInformation", (sibNames.getOrNull(first) ?: "SIB?") + if (n > 1) " +${n - 1}" else "")
        } else sib1(r)
    }

    private fun sib1(r: BitReader): L3Info {
        val hasPmax = r.bit(); r.bit(); r.bit() // p-Max, tdd-Config, nonCriticalExtension
        val hasCsg = r.bit()
        val nPlmn = r.int(3) + 1
        val plmns = mutableListOf<String>()
        repeat(nPlmn) {
            val hasMcc = r.bit()
            val mcc = if (hasMcc == 1) (0 until 3).joinToString("") { r.int(4).toString() } else "-"
            val mncLen = r.bit() + 2
            val mnc = (0 until mncLen).joinToString("") { r.int(4).toString() }
            r.bit() // cellReservedForOperatorUse
            plmns += "$mcc-$mnc"
        }
        val tac = r.int(16)
        val cellId = r.bits(28)
        val barred = r.bit() == 0
        r.bit(); r.bit()
        if (hasCsg == 1) r.skip(27)
        val hasOffset = r.bit()
        val qRxLevMin = (r.int(6) - 70) * 2
        if (hasOffset == 1) r.skip(3)
        if (hasPmax == 1) r.skip(6)
        val band = r.int(6) + 1
        val enb = cellId shr 8; val sector = cellId and 0xff
        return L3Info("systemInformationBlockType1",
            "PLMN ${plmns.joinToString("/")}, TAC $tac, ECI $cellId (eNB $enb-$sector), Band $band, qRxLevMin $qRxLevMin dBm" +
                if (barred) ", BARRED" else "",
            if (barred) setOf("BARRED") else emptySet(),
            mapOf("tac" to tac, "eci" to cellId, "band" to band, "plmn" to plmns.first()))
    }

    private fun connRequest(r: BitReader): L3Info {
        if (r.bit() == 1) return L3Info("rrcConnectionRequest")
        val tmsi = r.bit() == 0
        val id = if (tmsi) "%d/%08X".format(r.int(8), r.bits(32)) else { r.skip(40); null }
        val cause = estCause[r.int(3)]
        val values = mutableMapOf<String, Any>("cause" to cause)
        if (id != null) values["stmsi"] = id
        return L3Info("rrcConnectionRequest", "cause $cause, ${if (id != null) "S-TMSI $id" else "random id"}", setOf("REQUEST"), values)
    }

    private fun reestRequest(r: BitReader): L3Info {
        if (r.bit() == 1) return L3Info("rrcConnectionReestablishmentRequest")
        r.skip(16); val pci = r.int(9); r.skip(16)
        val cause = reestCause[r.int(2)]
        return L3Info("rrcConnectionReestablishmentRequest", "cause $cause, source PCI $pci",
            setOf("REEST") + if (cause == "handoverFailure") setOf("HO_FAIL") else emptySet(),
            mapOf("cause" to cause, "pci" to pci))
    }

    private fun measReport(r: BitReader): L3Info {
        if (r.bit() == 1) return L3Info("measurementReport")
        if (r.int(3) != 0) return L3Info("measurementReport")
        r.bit() // nonCriticalExtension
        r.bit() // MeasResults extension marker
        val hasNeigh = r.bit()
        val measId = r.int(5) + 1
        val rsrp = rsrpDbm(r.int(7)); val rsrq = rsrqDb(r.int(6))
        val sb = StringBuilder("measId $measId, serving RSRP $rsrp dBm / RSRQ $rsrq dB")
        val neigh = mutableListOf<Triple<Int, Int?, Double?>>()
        if (hasNeigh == 1) {
            val ext = r.bit()
            val kind = r.int(2)
            if (ext == 0 && kind == 0) {
                val n = r.int(3) + 1
                for (i in 0 until n) {
                    val hasCgi = r.bit()
                    val pci = r.int(9)
                    if (hasCgi == 1) { neigh += Triple(pci, null, null); break } // cgi-Info: stop here
                    val mext = r.bit()
                    val hp = r.bit(); val hq = r.bit()
                    val p = if (hp == 1) rsrpDbm(r.int(7)) else null
                    val q = if (hq == 1) rsrqDb(r.int(6)) else null
                    neigh += Triple(pci, p, q)
                    if (mext == 1) r.skipExtensions()
                }
                sb.append("; neighbours ").append(neigh.joinToString(", ") { (pci, p, q) ->
                    "PCI $pci" + (p?.let { " $it dBm" } ?: "") + (q?.let { " / $it dB" } ?: "")
                })
            } else sb.append("; inter-RAT neighbours (${listOf("EUTRA", "UTRA", "GERAN", "CDMA2000")[kind]})")
        }
        return L3Info("measurementReport", sb.toString(), setOf("MR"),
            mapOf("rsrp" to rsrp, "rsrq" to rsrq, "neigh" to neigh))
    }

    private fun reconfiguration(r: BitReader): L3Info {
        r.skip(2) // transaction id
        if (r.bit() == 1 || r.int(3) != 0) return L3Info("rrcConnectionReconfiguration")
        val meas = r.bit(); val mob = r.bit(); val nas = r.bit(); val rrc = r.bit(); r.bit(); r.bit()
        val what = mutableListOf<String>()
        if (meas == 1) what += "measConfig"
        if (nas == 1) what += "NAS"
        if (rrc == 1) what += "radioResourceConfig"
        if (mob == 0) return L3Info("rrcConnectionReconfiguration", what.joinToString(", "))
        var detail = "HANDOVER command"
        val values = mutableMapOf<String, Any>()
        if (meas == 0) { // target can be read directly only if measConfig is absent
            r.bit() // ext marker
            val hasFreq = r.bit(); r.bit(); r.bit(); r.bit()
            val pci = r.int(9); values["targetPci"] = pci
            detail += " → target PCI $pci"
            if (hasFreq == 1) { r.bit(); val f = r.int(16); values["targetEarfcn"] = f; detail += ", EARFCN $f (inter-freq)" }
        }
        return L3Info("rrcConnectionReconfiguration", (listOf(detail) + what).joinToString(", "), setOf("HO_CMD"), values)
    }

    private fun release(r: BitReader): L3Info {
        r.skip(2)
        if (r.bit() == 1 || r.int(2) != 0) return L3Info("rrcConnectionRelease", tags = setOf("RELEASE"))
        val redir = r.bit(); r.bit(); r.bit()
        val cause = relCause[r.int(2)]
        var detail = "cause $cause"
        val tags = mutableSetOf("RELEASE")
        if (redir == 1) {
            tags += "REDIRECT"
            r.bit()
            when (r.int(3)) {
                0 -> detail += ", redirect to LTE EARFCN ${r.int(16)}"
                1 -> detail += ", redirect to GERAN (2G)".also { tags += "REDIRECT_2G3G" }
                2 -> detail += ", redirect to UTRA-FDD UARFCN ${r.int(14)} (3G)".also { tags += "REDIRECT_2G3G" }
                3 -> detail += ", redirect to UTRA-TDD"
                else -> detail += ", redirect to CDMA2000"
            }
        }
        if (cause == "cs-FallbackHighPriority") tags += "CSFB"
        return L3Info("rrcConnectionRelease", detail, tags)
    }
}

object NasLite {
    private val emm = mapOf(
        0x41 to "Attach request", 0x42 to "Attach accept", 0x43 to "Attach complete", 0x44 to "Attach reject",
        0x45 to "Detach request", 0x46 to "Detach accept", 0x48 to "Tracking area update request",
        0x49 to "Tracking area update accept", 0x4A to "Tracking area update complete", 0x4B to "Tracking area update reject",
        0x4C to "Extended service request", 0x4E to "Service reject", 0x50 to "GUTI reallocation command",
        0x51 to "GUTI reallocation complete", 0x52 to "Authentication request", 0x53 to "Authentication response",
        0x54 to "Authentication reject", 0x5C to "Authentication failure", 0x55 to "Identity request",
        0x56 to "Identity response", 0x5D to "Security mode command", 0x5E to "Security mode complete",
        0x5F to "Security mode reject", 0x60 to "EMM status", 0x61 to "EMM information", 0x62 to "Downlink NAS transport",
        0x63 to "Uplink NAS transport", 0x64 to "CS service notification", 0x68 to "Downlink generic NAS transport",
        0x69 to "Uplink generic NAS transport")
    private val esm = mapOf(
        0xC1 to "Activate default EPS bearer context request", 0xC2 to "Activate default EPS bearer context accept",
        0xC3 to "Activate default EPS bearer context reject", 0xC5 to "Activate dedicated EPS bearer context request",
        0xC6 to "Activate dedicated EPS bearer context accept", 0xC7 to "Activate dedicated EPS bearer context reject",
        0xC9 to "Modify EPS bearer context request", 0xCA to "Modify EPS bearer context accept",
        0xCB to "Modify EPS bearer context reject", 0xCD to "Deactivate EPS bearer context request",
        0xCE to "Deactivate EPS bearer context accept", 0xD0 to "PDN connectivity request", 0xD1 to "PDN connectivity reject",
        0xD2 to "PDN disconnect request", 0xD3 to "PDN disconnect reject", 0xD4 to "Bearer resource allocation request",
        0xD5 to "Bearer resource allocation reject", 0xD6 to "Bearer resource modification request",
        0xD7 to "Bearer resource modification reject", 0xD9 to "ESM information request", 0xDA to "ESM information response",
        0xDB to "Notification", 0xE8 to "ESM status")
    val emmCause = mapOf(
        2 to "IMSI unknown in HSS", 3 to "Illegal UE", 5 to "IMEI not accepted", 6 to "Illegal ME",
        7 to "EPS services not allowed", 8 to "EPS and non-EPS services not allowed",
        9 to "UE identity cannot be derived by the network", 10 to "Implicitly detached", 11 to "PLMN not allowed",
        12 to "Tracking area not allowed", 13 to "Roaming not allowed in this tracking area",
        14 to "EPS services not allowed in this PLMN", 15 to "No suitable cells in tracking area", 16 to "MSC temporarily not reachable",
        17 to "Network failure", 18 to "CS domain not available", 19 to "ESM failure", 22 to "Congestion",
        25 to "Not authorized for this CSG", 35 to "Requested service option not authorized", 39 to "CS service temporarily not available",
        40 to "No EPS bearer context activated", 42 to "Severe network failure", 95 to "Semantically incorrect message",
        96 to "Invalid mandatory information", 111 to "Protocol error, unspecified")
    val esmCause = mapOf(
        8 to "Operator determined barring", 26 to "Insufficient resources", 27 to "Missing or unknown APN",
        28 to "Unknown PDN type", 29 to "User authentication failed", 30 to "Request rejected by Serving GW or PDN GW",
        31 to "Request rejected, unspecified", 32 to "Service option not supported", 33 to "Requested service option not subscribed",
        34 to "Service option temporarily out of order", 36 to "Regular deactivation", 38 to "Network failure",
        50 to "PDN type IPv4 only allowed", 51 to "PDN type IPv6 only allowed", 54 to "PDN connection does not exist",
        65 to "Maximum number of EPS bearers reached", 111 to "Protocol error, unspecified")

    fun decode(msg: ByteArray): L3Info = try { decodeInner(msg, 0) } catch (e: Exception) { L3Info("NAS (undecoded)") }

    private fun decodeInner(m: ByteArray, depth: Int): L3Info {
        val sh = m.u8(0) shr 4; val pd = m.u8(0) and 0x0f
        if (pd == 7 && sh == 0x0C) return L3Info("Service request", tags = setOf("SERVICE_REQ"))
        if (pd == 7 && sh != 0) {
            if (m.size <= 6 || depth > 0) return L3Info("Protected EMM message")
            return if (sh == 1 || sh == 3) decodeInner(m.copyOfRange(6, m.size), 1)
            else L3Info("Ciphered NAS message")
        }
        return when (pd) {
            7 -> {
                val t = m.u8(1)
                val name = emm[t] ?: "EMM 0x%02X".format(t)
                val reject = t == 0x44 || t == 0x4B || t == 0x4E || t == 0x54
                val cause = if (reject && t != 0x54 && m.size > 2) m.u8(2) else null
                val tags = mutableSetOf<String>()
                if (reject) tags += "NAS_REJECT"
                when (t) { 0x48 -> tags += "TAU"; 0x41 -> tags += "ATTACH"; 0x4C -> tags += "EXT_SR"; 0x64 -> tags += "CS_NOTIFY" }
                L3Info(name, cause?.let { "cause #$it ${emmCause[it] ?: ""}".trim() } ?: "", tags,
                    cause?.let { mapOf("cause" to it) } ?: emptyMap())
            }
            2 -> {
                val t = m.u8(2)
                val name = esm[t] ?: "ESM 0x%02X".format(t)
                val reject = t in setOf(0xC3, 0xC7, 0xCB, 0xD1, 0xD3, 0xD5, 0xD7)
                val cause = if ((reject || t == 0xCD) && m.size > 3) m.u8(3) else null
                L3Info(name, cause?.let { "ESM cause #$it ${esmCause[it] ?: ""}".trim() } ?: "",
                    if (reject) setOf("NAS_REJECT") else emptySet())
            }
            else -> L3Info("NAS PD $pd")
        }
    }
}
