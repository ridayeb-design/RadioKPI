package com.radiokpi.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.radiokpi.app.diag.samsung.Counter
import com.radiokpi.app.diag.samsung.SamsungActions
import com.radiokpi.app.diag.samsung.SamsungSummary
import com.radiokpi.app.diag.samsung.SamsungUi
import com.radiokpi.app.radio.Grade
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun rsrpGrade(v: Double?): Grade = when {
    v == null -> Grade.NA
    v >= -85 -> Grade.EXCELLENT
    v >= -95 -> Grade.GOOD
    v >= -105 -> Grade.FAIR
    v >= -115 -> Grade.POOR
    else -> Grade.BAD
}

private fun rsrqGrade(v: Double?): Grade = when {
    v == null -> Grade.NA
    v >= -9 -> Grade.EXCELLENT
    v >= -12 -> Grade.GOOD
    v >= -15 -> Grade.FAIR
    v >= -18 -> Grade.POOR
    else -> Grade.BAD
}

@Composable
fun SamsungDiagPanel(s: SamsungUi, a: SamsungActions) {
    val l = s.live
    Panel(title = "Samsung modem diag (Shannon / SCAT protocol)", trailing = if (l.running) "LIVE" else null) {
        Text(
            "Reads the Samsung baseband directly: RRC/NAS signalling, serving and neighbour cells with modem-grade RSRP/RSRQ. " +
                "Protocol ported from SCAT and checked against SCAT's real-modem test data.",
            color = C.Muted, fontSize = 12.sp
        )
        Spacer(Modifier.height(8.dp))
        if (l.running) {
            val secs = (System.currentTimeMillis() - l.startedAt) / 1000
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(C.Rec))
                Spacer(Modifier.width(8.dp))
                Text(
                    "%02d:%02d · %d packets · %d L3 msgs · %s".format(secs / 60, secs % 60, l.packets, l.l3Count, kb(l.bytes)),
                    color = C.Text, fontSize = 13.sp, fontFamily = FontFamily.Monospace
                )
            }
            Text(l.source, color = C.Muted, fontSize = 11.sp)
            if (s.noDataHint) {
                Spacer(Modifier.height(6.dp))
                Note("No data from the modem yet. Stop, tap Next interface, and start again. " +
                    "Check the Samsung is still in DM mode (*#0808#).", C.grade(Grade.FAIR))
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = a.onStop, colors = ButtonDefaults.buttonColors(containerColor = C.Rec, contentColor = C.Text)) {
                Text("Stop Samsung capture", fontWeight = FontWeight.Bold)
            }
        } else {
            // ---- USB OTG
            Text("A · This phone + Samsung over USB (no root)", color = C.Text, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Steps(listOf(
                "On the Samsung dial *#0808#, choose RNDIS + ACM + DM (or DM + MODEM + ADB), reboot it.",
                "Connect it to this phone with an OTG adapter (this phone must be the host).",
                "Tap Scan, then Start. Allow the USB popup."
            ))
            Text(s.usbStatus, color = C.Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp))
            if (s.ports.isNotEmpty()) {
                Text("Interface: " + s.ports[s.portIndex.coerceIn(0, s.ports.size - 1)], color = C.Text, fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace)
            }
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = a.onScan, enabled = !s.busy) { Text("Scan", color = C.Text) }
                if (s.ports.size > 1) OutlinedButton(onClick = a.onNextPort, enabled = !s.busy) { Text("Next interface", color = C.Text) }
                Button(
                    onClick = a.onStartUsb, enabled = s.ports.isNotEmpty() && !s.busy,
                    colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.Bg)
                ) { Text("Start", fontWeight = FontWeight.Bold) }
            }
            Spacer(Modifier.height(12.dp))
            // ---- Root on this phone
            Text("B · On this Samsung itself (root, experimental)", color = C.Text, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text("Uses the modem's DM device node. Its name varies by firmware, so this mode is unverified.",
                color = C.Muted, fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = a.onCheckRootNodes, enabled = !s.busy) { Text("Find DM node", color = C.Text) }
                if (s.rootChecked && s.rootNodes.isEmpty()) Text("None found (or no root)", color = C.Muted, fontSize = 12.sp)
            }
            s.rootNodes.forEach { node ->
                Button(
                    onClick = { a.onStartRoot(node) }, enabled = !s.busy,
                    colors = ButtonDefaults.buttonColors(containerColor = C.Accent2, contentColor = C.Bg),
                    modifier = Modifier.padding(top = 4.dp)
                ) { Text("Start on $node", fontWeight = FontWeight.Bold) }
            }
        }
        l.error?.let {
            Spacer(Modifier.height(8.dp))
            Note(it, C.grade(Grade.POOR))
        }
    }

    if (!l.gotData && l.startedAt == 0L) return

    // ---- Modem + serving cell
    Panel(title = "Serving cell (from modem)", trailing = l.rrcState?.let { "RRC $it" }) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            KpiTile("RSRP", l.rsrp?.let { "%.1f".format(it) } ?: "–", "dBm", C.grade(rsrpGrade(l.rsrp)), Modifier.weight(1f))
            KpiTile("RSRQ", l.rsrq?.let { "%.1f".format(it) } ?: "–", "dB", C.grade(rsrqGrade(l.rsrq)), Modifier.weight(1f))
            KpiTile("RSSI", l.rssi?.let { "%.0f".format(it) } ?: "–", "dBm", C.Text, Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        InfoGrid(listOf(
            "PLMN" to l.plmn,
            "TAC" to l.tac?.toString(),
            "eNB-sector" to l.enb?.let { "$it-${l.sector}" },
            "Band" to l.band?.let { "B$it" },
            "EARFCN" to l.earfcn?.toString(),
            "PCI" to l.pci?.toString(),
            "RSRP min/avg/max" to l.rsrpAvg?.let { "%.0f/%.0f/%.0f".format(l.rsrpMin, it, l.rsrpMax) },
            "Modem ICD" to l.icd,
            "Firmware" to l.firmware?.take(28)
        ), cols = 3)
        if (l.neighbours.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text("Neighbours measured by the modem", color = C.Muted, fontSize = 11.sp)
            l.neighbours.sortedByDescending { it.rsrp }.take(10).forEach { n ->
                val label = when (n.rat) { "NR" -> "5G NR-ARFCN"; "WCDMA" -> "3G UARFCN"; "GSM" -> "2G ARFCN"; else -> "4G EARFCN" }
                val id = when (n.rat) { "WCDMA" -> "PSC"; "GSM" -> "BSIC"; else -> "PCI" }
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                    Text("$label ${n.arfcn} · $id ${n.pci}", color = C.Text, fontSize = 12.sp, modifier = Modifier.weight(1f),
                        fontFamily = FontFamily.Monospace)
                    Text("%.0f dBm / %.1f dB".format(n.rsrp, n.rsrq), color = C.grade(rsrpGrade(n.rsrp)), fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace)
                }
            }
        }
    }

    // ---- Findings + counters
    if (l.counters.isNotEmpty()) {
        Panel(title = "Signalling findings") {
            SamsungSummary.findings(l).forEach { f ->
                val col = when (f.severity) { "Major" -> C.grade(Grade.BAD); "Minor" -> C.grade(Grade.FAIR); else -> C.grade(Grade.GOOD) }
                Row(Modifier.padding(vertical = 4.dp)) {
                    Badge(f.severity, col)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(f.title, color = C.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        if (f.action != "-") Text("${f.team}: ${f.action}", color = C.Muted, fontSize = 12.sp)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Counter.ORDER.forEach { k ->
                l.counters[k]?.let { v ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 1.dp)) {
                        Text(k, color = C.Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Text(v.toString(), color = C.Text, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }

    // ---- L3 log
    if (l.log.isNotEmpty()) {
        val tf = SimpleDateFormat("HH:mm:ss", Locale.US)
        Panel(title = "Layer 3 messages", trailing = "latest ${minOf(40, l.log.size)}") {
            l.log.takeLast(40).asReversed().forEach { m ->
                val dirCol = when (m.dir) { "UL" -> C.Accent2; "DL" -> C.Accent; else -> C.Muted }
                Column(Modifier.padding(vertical = 3.dp)) {
                    Row {
                        Text(tf.format(Date(m.t)) + " ", color = C.Muted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Text("${m.dir} ${m.layer} ", color = dirCol, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Text(m.name, color = C.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    if (m.detail.isNotBlank()) Text(m.detail, color = C.Muted, fontSize = 11.sp, modifier = Modifier.padding(start = 8.dp))
                }
            }
        }
    }

    if (!l.running && s.lastOutDir != null) {
        Panel(title = "Capture files") {
            Text("summary.md · l3_log.csv · l3.pcap (Wireshark) · capture.sdmraw (SCAT on PC)", color = C.Muted, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            Button(onClick = a.onShare, colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.Bg)) {
                Text("Share capture", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun Steps(items: List<String>) {
    items.forEachIndexed { i, t ->
        Row(Modifier.padding(vertical = 2.dp)) {
            Text("${i + 1}. ", color = C.Accent, fontSize = 12.sp)
            Text(t, color = C.Text, fontSize = 12.sp)
        }
    }
}

@Composable
private fun Note(text: String, col: Color) {
    Text(text, color = col, fontSize = 12.sp,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(col.copy(alpha = 0.12f)).padding(8.dp))
}

private fun kb(b: Long) = if (b < 1024 * 1024) "${b / 1024} KB" else "%.1f MB".format(b / 1048576.0)
