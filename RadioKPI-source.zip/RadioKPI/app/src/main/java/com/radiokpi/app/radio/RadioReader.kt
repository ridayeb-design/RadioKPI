package com.radiokpi.app.radio

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.telephony.CellIdentityNr
import android.telephony.CellInfo
import android.telephony.CellInfoCdma
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellInfoTdscdma
import android.telephony.CellInfoWcdma
import android.telephony.CellSignalStrengthNr
import android.telephony.TelephonyManager
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * Reads serving + neighbour cell measurements from the Android Telephony API.
 * All values come from the public API: what you get depends on the phone's modem/vendor.
 */
class RadioReader(private val context: Context) {

    /** Re-resolved on every use so a change of data SIM is followed. */
    private val tm: TelephonyManager get() = DataSim.manager(context)
    private val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

    @Volatile private var lastFix: GeoFix? = null

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            lastFix = GeoFix(
                location.latitude, location.longitude, location.accuracy,
                if (location.hasSpeed()) location.speed * 3.6f else 0f
            )
        }
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    @SuppressLint("MissingPermission")
    fun startLocation() {
        try {
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locationListener, Looper.getMainLooper())
            }
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000L, 0f, locationListener, Looper.getMainLooper())
            }
        } catch (_: Exception) { }
    }

    fun stopLocation() {
        try { lm.removeUpdates(locationListener) } catch (_: Exception) { }
    }

    fun isLocationEnabled(): Boolean =
        if (Build.VERSION.SDK_INT >= 28) lm.isLocationEnabled
        else lm.isProviderEnabled(LocationManager.GPS_PROVIDER) || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

    /** Takes one full measurement snapshot. Throws SecurityException if permissions are missing. */
    suspend fun read(): RadioSnapshot {
        val cells = fetchCellInfo()
        val parsed = cells.mapNotNull { parse(it) }
        // Dual SIM: keep only the registered cell(s) of the data SIM's network (PLMN match when known).
        val plmn = try { tm.networkOperator } catch (_: Exception) { null }
        val allRegistered = parsed.filter { it.registered }
        val registered = allRegistered.filter { c ->
            plmn.isNullOrBlank() || c.mcc == null || c.mnc == null || "${c.mcc}${c.mnc}" == plmn
        }.ifEmpty { allRegistered }
        // Prefer NR (SA) then LTE when several registered cells exist (e.g. dual SIM).
        val serving = registered.minByOrNull {
            when (it.rat) { Rat.NR -> 0; Rat.LTE -> 1; Rat.WCDMA -> 2; else -> 3 }
        }
        val neighbours = parsed.filter { !it.registered }
            .sortedByDescending { it.primaryDbm ?: -999 }

        return RadioSnapshot(
            timestamp = System.currentTimeMillis(),
            operator = tm.networkOperatorName?.takeIf { it.isNotBlank() } ?: "—",
            networkType = networkTypeName(),
            serving = serving,
            neighbours = neighbours,
            nsa = if (Build.VERSION.SDK_INT >= 29) readNsa() else null,
            location = lastFix,
            ccBandwidthsKhz = if (Build.VERSION.SDK_INT >= 28) readCellBandwidths() else emptyList()
        )
    }

    @SuppressLint("MissingPermission")
    private suspend fun fetchCellInfo(): List<CellInfo> {
        if (Build.VERSION.SDK_INT >= 29) {
            val fresh = withTimeoutOrNull(3000L) {
                suspendCancellableCoroutine<List<CellInfo>?> { cont ->
                    tm.requestCellInfoUpdate(
                        ContextCompat.getMainExecutor(context),
                        object : TelephonyManager.CellInfoCallback() {
                            override fun onCellInfo(cellInfo: MutableList<CellInfo>) {
                                if (cont.isActive) cont.resume(cellInfo)
                            }
                            override fun onError(errorCode: Int, detail: Throwable?) {
                                if (cont.isActive) cont.resume(null)
                            }
                        })
                }
            }
            if (fresh != null) return fresh
        }
        return tm.allCellInfo ?: emptyList()
    }

    /** Bandwidth of each aggregated carrier (PCC first). Empty if the modem doesn't report it. */
    @SuppressLint("MissingPermission")
    @RequiresApi(28)
    private fun readCellBandwidths(): List<Int> = try {
        tm.serviceState?.cellBandwidths?.filter { it > 0 && it != Int.MAX_VALUE } ?: emptyList()
    } catch (_: Exception) { emptyList() }

    @SuppressLint("MissingPermission")
    @RequiresApi(29)
    private fun readNsa(): NrNsaSignal? = try {
        val nr = tm.signalStrength
            ?.getCellSignalStrengths(CellSignalStrengthNr::class.java)
            ?.firstOrNull()
        nr?.let { NrNsaSignal(it.ssRsrp.v(), it.ssRsrq.v(), it.ssSinr.v(), it.csiRsrp.v()) }
            ?.takeIf { it.ssRsrp != null || it.csiRsrp != null }
    } catch (_: Exception) { null }

    @SuppressLint("MissingPermission")
    private fun networkTypeName(): String {
        val type = try { tm.dataNetworkType } catch (_: SecurityException) { TelephonyManager.NETWORK_TYPE_UNKNOWN }
        return when (type) {
            TelephonyManager.NETWORK_TYPE_NR -> "NR"
            TelephonyManager.NETWORK_TYPE_LTE -> "LTE"
            19 -> "LTE-CA" // NETWORK_TYPE_LTE_CA (hidden)
            TelephonyManager.NETWORK_TYPE_HSPAP -> "HSPA+"
            TelephonyManager.NETWORK_TYPE_HSPA -> "HSPA"
            TelephonyManager.NETWORK_TYPE_HSDPA -> "HSDPA"
            TelephonyManager.NETWORK_TYPE_HSUPA -> "HSUPA"
            TelephonyManager.NETWORK_TYPE_UMTS -> "UMTS"
            TelephonyManager.NETWORK_TYPE_TD_SCDMA -> "TD-SCDMA"
            TelephonyManager.NETWORK_TYPE_EDGE -> "EDGE"
            TelephonyManager.NETWORK_TYPE_GPRS -> "GPRS"
            TelephonyManager.NETWORK_TYPE_GSM -> "GSM"
            TelephonyManager.NETWORK_TYPE_IWLAN -> "IWLAN"
            TelephonyManager.NETWORK_TYPE_UNKNOWN -> "Unknown"
            else -> "Type $type"
        }
    }

    private fun parse(info: CellInfo): CellMeasurement? = when {
        info is CellInfoLte -> parseLte(info)
        Build.VERSION.SDK_INT >= 29 && info is CellInfoNr -> parseNr(info)
        info is CellInfoWcdma -> parseWcdma(info)
        info is CellInfoGsm -> parseGsm(info)
        Build.VERSION.SDK_INT >= 29 && info is CellInfoTdscdma -> CellMeasurement(
            rat = Rat.TDSCDMA, registered = info.isRegistered,
            dbm = info.cellSignalStrength.dbm.v(), rscp = info.cellSignalStrength.rscp.v(),
            level = info.cellSignalStrength.level
        )
        info is CellInfoCdma -> CellMeasurement(
            rat = Rat.CDMA, registered = info.isRegistered,
            dbm = info.cellSignalStrength.dbm.v(), level = info.cellSignalStrength.level
        )
        else -> null
    }

    private fun parseLte(info: CellInfoLte): CellMeasurement {
        val id = info.cellIdentity
        val s = info.cellSignalStrength
        return CellMeasurement(
            rat = Rat.LTE,
            registered = info.isRegistered,
            mcc = if (Build.VERSION.SDK_INT >= 28) id.mccString else null,
            mnc = if (Build.VERSION.SDK_INT >= 28) id.mncString else null,
            pci = id.pci.v(),
            arfcn = id.earfcn.v(),
            band = if (Build.VERSION.SDK_INT >= 30) id.bands.bandLabel("B") else null,
            tac = id.tac.v(),
            cellId = id.ci.v()?.toLong(),
            rsrp = s.rsrp.v()?.takeIf { it in -140..-44 },
            rsrq = s.rsrq.v()?.takeIf { it in -34..3 },
            sinr = s.rssnr.v(),
            rssi = if (Build.VERSION.SDK_INT >= 29) s.rssi.v() else null,
            ta = s.timingAdvance.v(),
            cqi = s.cqi.v(),
            dbm = s.dbm.v(),
            level = s.level,
            bandwidthKhz = if (Build.VERSION.SDK_INT >= 28) id.bandwidth.v()?.takeIf { it > 0 } else null
        )
    }

    @RequiresApi(29)
    private fun parseNr(info: CellInfoNr): CellMeasurement {
        val id = info.cellIdentity as CellIdentityNr
        val s = info.cellSignalStrength as CellSignalStrengthNr
        return CellMeasurement(
            rat = Rat.NR,
            registered = info.isRegistered,
            mcc = id.mccString,
            mnc = id.mncString,
            pci = id.pci.v(),
            arfcn = id.nrarfcn.v(),
            band = if (Build.VERSION.SDK_INT >= 30) id.bands.bandLabel("n") else null,
            tac = id.tac.v(),
            cellId = id.nci.takeIf { it != Long.MAX_VALUE && it >= 0 },
            rsrp = s.ssRsrp.v(),
            rsrq = s.ssRsrq.v(),
            sinr = s.ssSinr.v(),
            csiRsrp = s.csiRsrp.v(),
            dbm = s.dbm.v(),
            level = s.level
        )
    }

    private fun parseWcdma(info: CellInfoWcdma): CellMeasurement {
        val id = info.cellIdentity
        val s = info.cellSignalStrength
        return CellMeasurement(
            rat = Rat.WCDMA,
            registered = info.isRegistered,
            mcc = if (Build.VERSION.SDK_INT >= 28) id.mccString else null,
            mnc = if (Build.VERSION.SDK_INT >= 28) id.mncString else null,
            pci = id.psc.v(),
            arfcn = id.uarfcn.v(),
            tac = id.lac.v(),
            cellId = id.cid.v()?.toLong(),
            rscp = wcdmaRscp(s.dbm, s.asuLevel),
            // Ec/No is always negative; 0 or positive means "not reported".
            ecno = if (Build.VERSION.SDK_INT >= 30) s.ecNo.v()?.takeIf { it in -24..-1 } else null,
            dbm = wcdmaRscp(s.dbm, s.asuLevel),
            level = s.level
        )
    }

    private fun parseGsm(info: CellInfoGsm): CellMeasurement {
        val id = info.cellIdentity
        val s = info.cellSignalStrength
        return CellMeasurement(
            rat = Rat.GSM,
            registered = info.isRegistered,
            mcc = if (Build.VERSION.SDK_INT >= 28) id.mccString else null,
            mnc = if (Build.VERSION.SDK_INT >= 28) id.mncString else null,
            pci = id.bsic.v(),
            arfcn = id.arfcn.v(),
            tac = id.lac.v(),
            cellId = id.cid.v()?.toLong(),
            rssi = (if (Build.VERSION.SDK_INT >= 30) s.rssi.v() else s.dbm.v())?.takeIf { it in -113..-51 },
            ta = s.timingAdvance.v(),
            dbm = s.dbm.v(),
            level = s.level
        )
    }
}

/**
 * Some vendors (e.g. HONOR) put the ASU value (0–96) where RSCP in dBm is expected.
 * Accept real dBm values; convert plausible ASU values (RSCP = ASU − 120); drop anything else.
 */
private fun wcdmaRscp(dbm: Int, asu: Int): Int? {
    if (dbm in -120..-24) return dbm
    if (dbm in 0..96) return dbm - 120
    if (asu in 0..96) return asu - 120
    return null
}

/** Android reports "unavailable" as Int.MAX_VALUE (CellInfo.UNAVAILABLE); some vendors use MIN_VALUE. */
private fun Int.v(): Int? = if (this == Int.MAX_VALUE || this == Int.MIN_VALUE) null else this

private fun IntArray.bandLabel(prefix: String): String? =
    if (isEmpty()) null else joinToString("/") { "$prefix$it" }
