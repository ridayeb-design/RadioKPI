package com.radiokpi.app.net

import java.util.Locale

data class LinkInfo(
    val transport: String,          // Cellular / Wi-Fi / ...
    val iface: String?,             // rmnet_data0 ...
    val ipv4: List<String>,
    val ipv6: List<String>,
    val dns: List<String>,
    val privateDns: String,
    val mtu: Int?,
    val validated: Boolean,
    val metered: Boolean,
    val downKbps: Int?,
    val upKbps: Int?
) {
    val cellular: Boolean get() = transport == "Cellular"
    val stack: String
        get() = when {
            ipv4.isNotEmpty() && ipv6.isNotEmpty() -> "Dual-stack (IPv4 + IPv6)"
            ipv6.isNotEmpty() -> "IPv6-only (likely 464XLAT/NAT64 for IPv4)"
            ipv4.isNotEmpty() -> "IPv4-only"
            else -> "No IP"
        }
    val cgnat: Boolean
        get() = ipv4.any { a ->
            val p = a.split('.').mapNotNull { it.toIntOrNull() }
            p.size == 4 && (p[0] == 10 || (p[0] == 100 && p[1] in 64..127) || (p[0] == 172 && p[1] in 16..31) || (p[0] == 192 && p[1] == 168))
        }
}

data class ResolverStats(
    val name: String,
    val server: String,
    val queries: Int,
    val ok: Int,
    val timeouts: Int,
    val failures: Int,           // SERVFAIL / REFUSED / errors (excluding NXDOMAIN test)
    val medianColdMs: Long?,
    val medianWarmMs: Long?,
    val p90Ms: Long?,
    val maxMs: Long?,
    val nxdomainHijack: Boolean?,
    val aaaa: Boolean?
) {
    val successPct: Float get() = if (queries == 0) 0f else ok * 100f / queries
}

data class DnsReport(
    val at: Long,
    val resolvers: List<ResolverStats>,
    val perDomain: List<Pair<String, Map<String, Long?>>>,   // domain -> resolver -> cold RTT
    val findings: List<String>
)

data class PingResult(
    val target: String,
    val label: String,
    val method: String,      // ICMP / TCP:443
    val sent: Int,
    val received: Int,
    val minMs: Float?,
    val avgMs: Float?,
    val maxMs: Float?,
    val jitterMs: Float?
) {
    val lossPct: Float get() = if (sent == 0) 100f else (sent - received) * 100f / sent
}

data class HttpResult(val url: String, val code: Int?, val coldMs: Long?, val warmMs: Long?, val error: String?)

data class SpeedResult(
    val at: Long,
    val dlMbps: Float?,
    val ulMbps: Float?,
    val dlMB: Float,
    val ulMB: Float,
    val radio: String,
    val error: String?,
    val bwMhz: Int? = null,     // aggregated bandwidth during the test
    val rsrq: Int? = null,      // serving RSRQ during the test
    val cell: String? = null    // serving cell label during the test
)

data class NetUi(
    val link: LinkInfo? = null,
    val running: String? = null,
    val progress: String? = null,
    val dns: DnsReport? = null,
    val pings: List<PingResult> = emptyList(),
    val pingFindings: List<String> = emptyList(),
    val http: List<HttpResult> = emptyList(),
    val speed: SpeedResult? = null,
    val log: List<String> = emptyList()
)

object NetAnalysis {
    val DOMAINS = listOf(
        "google.com", "youtube.com", "facebook.com", "whatsapp.net", "instagram.com",
        "tiktok.com", "netflix.com", "microsoft.com", "apple.com", "wikipedia.org"
    )

    private fun median(v: List<Long>): Long? {
        if (v.isEmpty()) return null
        val s = v.sorted()
        return if (s.size % 2 == 1) s[s.size / 2] else (s[s.size / 2 - 1] + s[s.size / 2]) / 2
    }

    private fun p90(v: List<Long>): Long? {
        if (v.isEmpty()) return null
        val s = v.sorted()
        return s[((s.size - 1) * 0.9).toInt()]
    }

    fun summarize(
        results: List<DnsQueryResult>, hijackDomain: String, link: LinkInfo?, at: Long
    ): DnsReport {
        val byResolver = results.groupBy { it.resolver }
        val stats = byResolver.map { (name, rs) ->
            val normal = rs.filter { it.domain != hijackDomain && it.type == DnsPacket.TYPE_A }
            val cold = normal.filter { it.attempt == 1 }.mapNotNull { r -> r.rttMs.takeIf { r.ok } }
            val warm = normal.filter { it.attempt == 2 }.mapNotNull { r -> r.rttMs.takeIf { r.ok } }
            val all = normal.mapNotNull { r -> r.rttMs.takeIf { r.ok } }
            val hij = rs.firstOrNull { it.domain == hijackDomain }
            val aaaa = rs.firstOrNull { it.type == DnsPacket.TYPE_AAAA }
            ResolverStats(
                name = name,
                server = rs.first().server,
                queries = normal.size,
                ok = normal.count { it.ok },
                timeouts = normal.count { it.timeout },
                failures = normal.count { !it.ok && !it.timeout },
                medianColdMs = median(cold),
                medianWarmMs = median(warm),
                p90Ms = p90(all),
                maxMs = all.maxOrNull(),
                nxdomainHijack = hij?.let { if (it.rttMs == null) null else it.rcode == 0 && it.answers.isNotEmpty() },
                aaaa = aaaa?.let { if (it.rttMs == null) null else it.answers.isNotEmpty() }
            )
        }
        val perDomain = NetAnalysis.DOMAINS.map { d ->
            d to byResolver.mapValues { (_, rs) ->
                rs.firstOrNull { it.domain == d && it.attempt == 1 && it.type == DnsPacket.TYPE_A }?.let { r -> r.rttMs.takeIf { r.ok } }
            }
        }
        return DnsReport(at, stats, perDomain, findings(stats, link))
    }

    private fun ms(v: Long?) = v?.let { "$it ms" } ?: "—"

    fun findings(stats: List<ResolverStats>, link: LinkInfo?): List<String> {
        val out = mutableListOf<String>()
        val operator = stats.filter { it.name.startsWith("Network DNS") }
        val public = stats.filter { !it.name.startsWith("Network DNS") && !it.name.startsWith("System") }
        val bestOp = operator.filter { it.medianColdMs != null }.minByOrNull { it.medianColdMs!! }
        val bestPub = public.filter { it.medianColdMs != null }.minByOrNull { it.medianColdMs!! }

        if (link != null && !link.cellular) {
            out += "Tests ran over ${link.transport}, not the mobile network. Turn Wi-Fi off to test the operator."
        }
        if (operator.isEmpty()) {
            out += "No network-assigned DNS server was visible (Private DNS may be enforcing DoT)."
        }
        if (bestOp != null && bestPub != null) {
            val d = bestOp.medianColdMs!! - bestPub.medianColdMs!!
            out += when {
                d > 20 -> "Operator resolver ${bestOp.server} is slower than ${bestPub.name} by $d ms (median ${ms(bestOp.medianColdMs)} vs ${ms(bestPub.medianColdMs)}). Check resolver load, anycast placement or recursion path."
                d < -5 -> "Operator resolver ${bestOp.server} is faster than public resolvers (${ms(bestOp.medianColdMs)} vs ${bestPub.name} ${ms(bestPub.medianColdMs)}), as expected for an on-net resolver."
                else -> "Operator resolver and ${bestPub.name} perform similarly (${ms(bestOp.medianColdMs)} vs ${ms(bestPub.medianColdMs)})."
            }
        }
        stats.forEach { s ->
            val cold = s.medianColdMs
            val warm = s.medianWarmMs
            if (cold != null && warm != null && cold - warm > 30) {
                out += "${s.name}: first lookups ${cold - warm} ms slower than cached ones (cache-miss penalty: recursive resolution to authoritative servers)."
            }
            val failPct = if (s.queries == 0) 0f else (s.timeouts + s.failures) * 100f / s.queries
            if (failPct >= 5f) {
                out += "${s.name} (${s.server}): ${String.format(Locale.US, "%.0f", failPct)}% failed queries (${s.timeouts} timeouts, ${s.failures} errors). Possible UDP/53 loss, rate limiting or resolver issue."
            }
            if (s.nxdomainHijack == true) {
                out += "${s.name} (${s.server}) answers non-existent domains with an IP: NXDOMAIN redirection/hijacking detected."
            }
            if (s.p90Ms != null && s.p90Ms > 300) {
                out += "${s.name}: 10% of lookups take more than ${s.p90Ms} ms. Users will notice slow page starts."
            }
        }
        if (link != null) {
            if (link.ipv6.isNotEmpty() && operator.any { it.aaaa == false }) {
                out += "Device has IPv6 but the operator resolver returned no AAAA record for google.com."
            }
            if (link.cgnat) out += "IPv4 address ${link.ipv4.firstOrNull()} is private/CGNAT (shared public IP behind carrier NAT)."
            if (link.privateDns != "Off" && link.privateDns != "n/a") {
                out += "Private DNS is on (${link.privateDns}): apps use DNS-over-TLS, not the operator resolver directly."
            }
        }
        if (out.isEmpty()) out += "DNS looks healthy: fast, reliable and no manipulation detected."
        return out
    }

    fun pingFindings(p: List<PingResult>): List<String> {
        val out = mutableListOf<String>()
        p.forEach { r ->
            if (r.received == 0) {
                out += "${r.label} (${r.target}) unreachable over ${r.method}."
                return@forEach
            }
            if (r.lossPct >= 2f) out += "${r.label}: ${String.format(Locale.US, "%.0f", r.lossPct)}% packet loss."
            val avg = r.avgMs ?: return@forEach
            if (avg > 80) out += "${r.label}: high latency (avg ${String.format(Locale.US, "%.0f", avg)} ms). For LTE, under 50 ms is typical."
            val j = r.jitterMs
            if (j != null && j > 20) out += "${r.label}: high jitter (${String.format(Locale.US, "%.0f", j)} ms). Voice/video calls may be choppy."
        }
        val core = p.firstOrNull { it.label.startsWith("Operator") }?.avgMs
        val inet = p.firstOrNull { it.label.startsWith("Google") }?.avgMs
        if (core != null && inet != null) {
            out += "Operator core/DNS RTT ${String.format(Locale.US, "%.0f", core)} ms vs Internet RTT ${String.format(Locale.US, "%.0f", inet)} ms: " +
                if (inet - core > 30) "the extra ${String.format(Locale.US, "%.0f", inet - core)} ms is on the transit/peering path." else "transit adds little latency."
        }
        return out
    }
}
