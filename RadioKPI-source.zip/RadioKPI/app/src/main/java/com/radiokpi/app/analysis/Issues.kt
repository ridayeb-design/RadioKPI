package com.radiokpi.app.analysis

import com.radiokpi.app.net.DnsReport
import com.radiokpi.app.net.LinkInfo
import com.radiokpi.app.net.PingResult
import com.radiokpi.app.net.SpeedResult
import com.radiokpi.app.radio.CellStat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Team that should act on an issue. */
enum class Team(val label: String) {
    RF_OPT("RF Optimization"),
    RF_PLAN("RF Planning"),
    NOC("NOC / Site maintenance"),
    RAN_PARAM("RAN Parameters & Features"),
    CAPACITY("RAN Capacity"),
    TRANSPORT("Transport / IP backbone"),
    CORE_DNS("Packet Core / DNS"),
    IMS("IMS / VoLTE & provisioning"),
    DEVICE("Device (not a network fault)")
}

data class Issue(
    val id: String,
    val title: String,
    val severity: Severity,
    val team: Team,
    val cell: CellStat?,
    val cellLabel: String?,
    val lat: Double?,
    val lon: Double?,
    val first: Long?,
    val last: Long?,
    val occurrences: Int,
    val durationS: Long,
    val evidence: List<String>,
    val cause: String,
    val impact: String,
    val actions: List<String>,
    val verify: String
) {
    val mapLink: String? get() = if (lat != null && lon != null) "https://maps.google.com/?q=$lat,$lon" else null
}

data class IssueInput(
    val from: Long,
    val to: Long,
    val operator: String,
    val device: String,
    val samples: Int,
    val anomalies: List<Anomaly>,
    val cells: Map<String, CellStat>,
    val sinrReported: Boolean = true,
    val link: LinkInfo? = null,
    val dns: DnsReport? = null,
    val pings: List<PingResult> = emptyList(),
    val speed: SpeedResult? = null,
    val summary: com.radiokpi.app.history.RangeSummary? = null,
    val bands: Map<String, Int> = emptyMap()
)

object IssueBuilder {

    private class Template(
        val title: String,
        val team: Team,
        val cause: String,
        val impact: String,
        val actions: List<String>,
        val verify: String,
        val minOccurrences: Int = 1
    )

    private val templates: Map<AnomalyType, Template> = mapOf(
        AnomalyType.NO_SERVICE to Template(
            "No service", Team.NOC,
            "UE could not register on any cell. Either a site/cell outage at that time, or a coverage hole.",
            "Complete loss of service: no calls, SMS or data for the duration. Emergency calls may also fail.",
            listOf(
                "Check alarms and cell availability (outage, sleeping cell, transmission alarm) for the last serving site at the time shown.",
                "If no alarm: hand over to RF Planning as a coverage hole and run a walk/drive test.",
                "Check whether the cell was barred or locked by a configuration change."
            ),
            "No 'No service' event at this location over 24 h of 24/7 collection."
        ),
        AnomalyType.WEAK_COVERAGE to Template(
            "Weak coverage", Team.RF_PLAN,
            "Received level below the coverage threshold (RSRP < −110 dBm on 4G). Too far from the site, indoor penetration loss, obstruction, or a tilt/azimuth problem.",
            "Slow data, longer page loads, video buffering. VoLTE calls may break up or drop. Higher risk of radio link failure and fallback to 3G/2G. Indoor users are hit hardest.",
            listOf(
                "Check the serving cell's availability and VSWR/RET alarms; confirm the antenna tilt and azimuth match the design.",
                "Review whether reducing electrical downtilt or re-pointing the azimuth would cover this spot without creating overshooting.",
                "If the spot is indoors or structurally blocked: assess an indoor solution or small cell.",
                "Confirm with a walk test around the reported location."
            ),
            "RSRP ≥ −105 dBm on ≥ 95% of samples at this location; no 'Weak coverage' events over 24 h."
        ),
        AnomalyType.INTERFERENCE to Template(
            "Poor quality despite good signal (interference)", Team.RF_OPT,
            "Signal level is fine but RSRQ/SINR is poor, so the problem is interference or load, not coverage: co-channel neighbours at similar level, PCI conflicts, overshooting cells, or external (UL/DL) interference.",
            "Low SINR forces low MCS and rank, with more HARQ retransmissions. Throughput is typically 30–70% below clean conditions, latency is higher, VoLTE voice quality (MOS) drops, and radio link failures can happen even with full signal bars.",
            listOf(
                "List co-channel neighbours at this location (same EARFCN within 6 dB) and identify the strongest interferer.",
                "Check PCI mod-3 / mod-30 conflicts between the serving cell and those neighbours.",
                "Check PRB utilisation and UL interference (RSSI per PRB) KPIs on the serving cell to separate load from interference.",
                "Adjust tilt/power on overshooting neighbours to restore dominance; request a spectrum scan if external interference is suspected."
            ),
            "RSRQ ≥ −12 dB (and SINR ≥ 10 dB where reported) on ≥ 90% of samples at this location."
        ),
        AnomalyType.PCI_MOD3 to Template(
            "PCI mod-3 conflict", Team.RF_PLAN,
            "Serving cell and a strong co-channel neighbour use PCIs with the same value mod 3, so their cell-specific reference signals (CRS) fall on the same subcarriers and interfere.",
            "Corrupted channel estimation in the overlap area: lower RSRQ/SINR, lower MCS and throughput, more retransmissions and unstable handovers.",
            listOf(
                "Re-plan the PCI of one of the two cells so PCI mod 3 differs (also check mod 6 and mod 30 for UL DMRS).",
                "Make sure the new PCI doesn't create confusion/collision with other neighbours (run the PCI planning tool / ANR check).",
                "Re-test RSRQ at the reported location after the change."
            ),
            "No PCI mod-3 conflict detected at this location; RSRQ improves by ≥ 2 dB."
        ),
        AnomalyType.NO_DOMINANT to Template(
            "No dominant cell (pilot pollution)", Team.RF_OPT,
            "Three or more co-channel cells received within 6 dB of the serving cell. No cell dominates, so each is interference for the others.",
            "Low and unstable SINR, frequent cell changes and ping-pong, variable throughput, higher call setup failure and drop risk in the overlap area.",
            listOf(
                "Identify the cells overlapping at this location and decide which should be dominant.",
                "Increase downtilt (or reduce power) on the non-dominant/overshooting cells; review azimuths.",
                "If needed, tune Cell Individual Offsets (CIO) to steer UEs to the intended cell.",
                "Re-test: the dominant cell should be ≥ 6 dB above the next co-channel cell."
            ),
            "Fewer than 3 co-channel neighbours within 6 dB on ≥ 90% of samples."
        ),
        AnomalyType.MISSED_HO to Template(
            "Missed handover (stronger co-channel neighbour not used)", Team.RF_OPT,
            "A same-frequency neighbour stayed ≥ 6 dB stronger for several samples without a handover: missing neighbour relation, too high A3 offset/hysteresis/time-to-trigger, negative CIO, or the target is blocked/overloaded.",
            "The UE stays on a weaker, more interfered cell: lower throughput, and a radio link failure or call drop is likely if the level keeps falling.",
            listOf(
                "Check that the neighbour relation exists in the NRT/ANR (serving → target) and isn't blacklisted.",
                "Review A3 offset, hysteresis, time-to-trigger and CIO between the two cells.",
                "Check the target cell's availability, barring and admission/load at the time."
            ),
            "No 'Missed handover' events at this location; handover to the stronger cell within 2–3 s."
        ),
        AnomalyType.PING_PONG to Template(
            "Ping-pong handovers", Team.RF_OPT,
            "The UE goes A → B → A within seconds: two cells of similar level, hysteresis/TTT too small, or CIO imbalance.",
            "Each handover causes a short user-plane interruption (tens of ms) and extra signalling. Users notice VoLTE glitches, gaming lag and throughput dips.",
            listOf(
                "Increase handover hysteresis or time-to-trigger between the two cells.",
                "Review CIO between the pair; fix dominance at the location (tilt/power).",
                "Check the HO success rate and ping-pong counters for this pair in OSS."
            ),
            "Ping-pong rate on this pair < 5% in OSS; no events over 24 h.",
            minOccurrences = 2
        ),
        AnomalyType.EXCESSIVE_HO to Template(
            "Excessive handovers", Team.RF_OPT,
            "Six or more cell changes in one minute: no dominant cell or poor neighbour planning.",
            "Repeated short interruptions, higher signalling load and battery drain; risk of handover failures and drops.",
            listOf(
                "Treat as a dominance problem: identify the cells involved and create a clear dominant cell.",
                "Review hysteresis/TTT and CIO for the involved pairs."
            ),
            "Fewer than 6 cell changes per minute when stationary."
        ),
        AnomalyType.FALLBACK_LEGACY to Template(
            "Fallback from 4G/5G to 3G/2G", Team.RAN_PARAM,
            "The UE left LTE/NR for a legacy RAT: LTE coverage hole, too aggressive inter-RAT thresholds (A2/B2), or CSFB for voice.",
            "Loss of 4G: VoLTE isn't available (voice over 3G/2G or CSFB with longer call setup), data speeds are much lower and latency higher.",
            listOf(
                "Check the A2/B2 inter-RAT thresholds and LTE redirection settings on the serving cell.",
                "Check whether the fallback coincided with a voice call (CSFB) and whether the subscriber has VoLTE provisioned.",
                "If caused by weak LTE coverage: pass to RF Planning."
            ),
            "4G time share ≥ 99% at this location; no fallback events over 24 h."
        ),
        AnomalyType.CSFB_CALL to Template(
            "Voice calls fall back to 3G (CSFB, no VoLTE)", Team.IMS,
            "Calls aren't carried over VoLTE, so the phone uses Circuit-Switched Fallback to 3G for each call. Either VoLTE is off on the phone, not provisioned for the subscription (HSS/IMS profile), or the device model isn't enabled for VoLTE on this network.",
            "Call setup about 2–4 s slower, data slows down or pauses during calls (3G), and extra mobility (return to 4G after each call). No HD voice.",
            listOf(
                "Check the subscriber's VoLTE/IMS provisioning (HSS profile, IMS registration).",
                "Check whether this device model is whitelisted/enabled for VoLTE on the network.",
                "Ask the user to enable VoLTE/4G calling in the phone's SIM settings and retest.",
                "Until VoLTE works: review CSFB return-to-LTE (fast return) settings on the 3G side."
            ),
            "Test calls stay on 4G (VoLTE) with no drop to 3G.",
            minOccurrences = 1
        ),
        AnomalyType.FIVE_G_DROP to Template(
            "5G leg dropped", Team.RF_OPT,
            "The NR leg (EN-DC SgNB) was released or the UE left 5G SA: weak NR coverage, B1/A2 NR thresholds, or SgNB release on failure.",
            "Peak throughput falls back to LTE levels; heavy users notice slower downloads and video quality drops.",
            listOf(
                "Check SgNB addition/release counters and release causes for the anchor cell.",
                "Review the B1 (NR addition) and NR A2 thresholds; check NR coverage at the location."
            ),
            "5G time share stable; SgNB release on failure < 2%.",
            minOccurrences = 2
        ),
        AnomalyType.OVERSHOOT to Template(
            "Overshooting / far serving cell", Team.RF_OPT,
            "High timing advance: the serving cell is far away (≥ ~5 km), so closer cells aren't dominant or the far cell's tilt is too high.",
            "High path loss and poor uplink. The far cell interferes with other sites and spends capacity on distant users.",
            listOf(
                "Increase downtilt on the far cell or reduce its power.",
                "Check why closer cells aren't serving (coverage, availability, neighbour relations)."
            ),
            "TA < 20 (≈ 1.5 km) at this location."
        ),
        AnomalyType.LOW_CQI to Template(
            "Low channel quality (CQI)", Team.RF_OPT,
            "CQI ≤ 6 reported for several samples: low SINR from interference or weak signal.",
            "The scheduler uses low MCS, so throughput drops sharply and latency rises under load.",
            listOf(
                "Correlate with the interference/coverage issues at the same location and fix those first.",
                "Check the average CQI distribution of the cell in OSS."
            ),
            "CQI ≥ 9 on most samples at this location."
        ),
        AnomalyType.SIGNAL_DROP to Template(
            "Sudden signal drops", Team.RF_OPT,
            "Level fell ≥ 15 dB in one step on the same cell: obstruction, deep fading, or an intermittent cell/antenna problem.",
            "Short throughput dips and possible radio link failures.",
            listOf(
                "If repeated at the same place: check the serving cell for intermittent alarms (VSWR, RRU).",
                "Otherwise monitor; usually local fading."
            ),
            "No repeated drops at the same place.",
            minOccurrences = 3
        )
    )

    private fun bump(s: Severity) = if (s == Severity.MINOR) Severity.MAJOR else s

    private fun f0(v: Float?) = v?.let { String.format(Locale.US, "%.0f", it) } ?: "—"
    private fun f1(v: Float?) = v?.let { String.format(Locale.US, "%.1f", it) } ?: "—"

    fun cellLine(c: CellStat?): String? {
        if (c == null) return null
        val parts = mutableListOf(c.label)
        if (c.enb != null) parts += "eNB ${c.enb} / sector ${c.sector}"
        else if (c.cellId != null) parts += "Cell ID ${c.cellId}"
        if (c.arfcn != null) parts += "EARFCN/ARFCN ${c.arfcn}"
        if (c.tac != null) parts += "TAC/LAC ${c.tac}"
        return parts.joinToString(" · ")
    }

    fun build(input: IssueInput): List<Issue> {
        val out = mutableListOf<Issue>()

        // ---- radio issues
        // Area problems (coverage, interference, pollution) are grouped by location (~200 m grid) so a team
        // gets one ticket per spot listing every cell involved; cell problems are grouped per cell.
        val areaTypes = setOf(AnomalyType.WEAK_COVERAGE, AnomalyType.INTERFERENCE, AnomalyType.NO_DOMINANT, AnomalyType.LOW_CQI, AnomalyType.EXCESSIVE_HO, AnomalyType.FALLBACK_LEGACY, AnomalyType.CSFB_CALL)
        fun areaKey(a: Anomaly): String =
            if (a.lat == null || a.lon == null) "?" else "${Math.round(a.lat / 0.002)}:${Math.round(a.lon / 0.002)}"

        input.anomalies
            .filter { it.type != AnomalyType.STALE_DATA }
            .groupBy { if (it.type in areaTypes) it.type to "area:" + areaKey(it) else it.type to "cell:" + (it.cell ?: "?") }
            .forEach { (key, list) ->
                val type = key.first
                val t = templates[type] ?: return@forEach
                if (list.size < t.minOccurrences) return@forEach
                val involved = list.filter { it.cell != null }.groupBy { it.cell!! }
                    .map { (c, l) -> Triple(c, l.size, l.sumOf { it.durationS }) }
                    .sortedWith(compareByDescending<Triple<String, Int, Long>> { it.third }.thenByDescending { it.second })
                val mainLabel = involved.firstOrNull()?.first
                val cell = mainLabel?.let { input.cells[it] }
                val duration = list.sumOf { it.durationS }
                var sev = type.severity
                if (list.size >= 5 || duration >= 600) sev = bump(sev)
                // A weak-coverage issue that lasts only seconds is a local spot: optimisation first.
                val team = if (type == AnomalyType.WEAK_COVERAGE && duration < 120) Team.RF_OPT else t.team
                val ev = mutableListOf<String>()
                ev += "${list.size} occurrence(s), total ${fmtDur(duration)} between ${fmtTime(list.minOf { it.start })} and ${fmtTime(list.maxOf { it.end })}."
                if (involved.size > 1) {
                    ev += "Cells involved: " + involved.joinToString("; ") { e ->
                        val cs = input.cells[e.first]
                        e.first + (cs?.enb?.let { " [eNB $it/${cs.sector}]" } ?: "") + " (×${e.second}, ${fmtDur(e.third)})"
                    } + "."
                }
                list.map { it.detail }.distinct().take(3).forEach { ev += "Measured: $it" }
                if (type == AnomalyType.FALLBACK_LEGACY) {
                    ev += "If a voice call was made at these times, this is CSFB (no VoLTE), not a coverage fallback."
                }
                involved.map { it.first }.take(3).mapNotNull { input.cells[it] }.forEach { c ->
                    ev += "${c.label} over the period: ${c.samples} samples, avg level ${f1(c.avgLevel)} dBm (min ${c.levelMin ?: "—"}), " +
                        "avg RSRQ ${f1(c.avgRsrq)} dB" + (c.avgSinr?.let { ", avg SINR ${f1(it)} dB" } ?: "") + "."
                }
                val loc = list.firstOrNull { it.lat != null }
                val where = if (type in areaTypes) " (${involved.size} cell${if (involved.size > 1) "s" else ""})" else ""
                out += Issue(
                    id = "", title = t.title + (mainLabel?.let { if (type in areaTypes) " around $it$where" else " on $it" } ?: ""),
                    severity = sev, team = team,
                    cell = cell, cellLabel = mainLabel, lat = loc?.lat, lon = loc?.lon,
                    first = list.minOf { it.start }, last = list.maxOf { it.end },
                    occurrences = list.size, durationS = duration, evidence = ev,
                    cause = t.cause, impact = t.impact, actions = t.actions, verify = t.verify
                )
            }

        // ---- throughput vs allocated bandwidth
        input.speed?.let { sp ->
            val dl = sp.dlMbps
            val ul = sp.ulMbps
            val bw = sp.bwMhz
            if (dl != null && sp.error == null) {
                val lowForBw = bw != null && dl < bw * 0.5f
                val dlBelowUl = ul != null && dl < ul
                if (lowForBw || dlBelowUl) {
                    val interfered = (sp.rsrq ?: 0) <= -15
                    out += Issue(
                        id = "", title = "Low downlink throughput for the allocated bandwidth",
                        severity = Severity.MAJOR, team = if (interfered) Team.RF_OPT else Team.CAPACITY,
                        cell = sp.cell?.let { input.cells[it] }, cellLabel = sp.cell, lat = null, lon = null,
                        first = sp.at, last = sp.at, occurrences = 1, durationS = 0,
                        evidence = listOfNotNull(
                            "Download ${f1(dl)} Mbps, upload ${f1(ul)} Mbps" + (bw?.let { " on $it MHz aggregated" } ?: "") + ".",
                            if (dlBelowUl) "Downlink is lower than uplink, which is abnormal for LTE (DL is normally several times UL)." else null,
                            "Radio during the test: ${sp.radio}."
                        ),
                        cause = if (interfered)
                            "Radio quality during the test was poor (RSRQ ${sp.rsrq} dB), so DL MCS/rank is limited by interference. Cell load may add to it."
                        else "Radio conditions look acceptable, so the limit is likely cell load (PRB utilisation), scheduler or transport backhaul capacity.",
                        impact = "Slow downloads, video starting at low resolution or buffering, app updates and cloud sync taking much longer.",
                        actions = listOf(
                            "Check DL PRB utilisation, active users and average user throughput for the serving cell at the test time.",
                            "If PRB load is high: capacity action (carrier add, load balancing to other layers).",
                            "If load is low: check backhaul utilisation/packet loss for the site (Transport) and the interference issues listed in this report.",
                            "Repeat the speed test 3–4 times at different hours to confirm."
                        ),
                        verify = "DL ≥ 1 Mbps per MHz aggregated (e.g. ≥ 50 Mbps on 50 MHz) and DL > UL."
                    )
                }
            }
        }

        // ---- DNS
        input.dns?.let { d ->
            val ops = d.resolvers.filter { it.name.startsWith("Network DNS") }
            val pub = d.resolvers.filter { !it.name.startsWith("Network DNS") && !it.name.startsWith("System") }
            ops.filter { it.nxdomainHijack == true }.forEach { r ->
                out += netIssue("NXDOMAIN redirection on operator DNS ${r.server}", Severity.MINOR, Team.CORE_DNS,
                    listOf("Queries for non-existent domains returned an IP address instead of NXDOMAIN."),
                    "Resolver is configured to redirect failed lookups (ad/search page).",
                    "Breaks apps and security tools that rely on NXDOMAIN; privacy and policy concern.",
                    listOf("Confirm whether NXDOMAIN redirection is intended; disable it or offer an opt-out."),
                    "Non-existent domains return NXDOMAIN.", d.at)
            }
            ops.forEach { r ->
                val fail = if (r.queries == 0) 0f else (r.timeouts + r.failures) * 100f / r.queries
                if (fail >= 5f) out += netIssue("DNS failures on operator resolver ${r.server}", Severity.MAJOR, Team.CORE_DNS,
                    listOf("${f0(fail)}% of lookups failed (${r.timeouts} timeouts, ${r.failures} errors) out of ${r.queries}."),
                    "Resolver overload, UDP/53 packet loss on the path, or rate limiting.",
                    "Websites and apps fail to open or open after long delays; users see 'no internet' even with full bars.",
                    listOf("Check resolver CPU/query load and drop counters.", "Check packet loss between the PGW/UPF and the resolver."),
                    "Failure rate < 1%.", d.at)
            }
            val bestOp = ops.mapNotNull { it.medianColdMs }.minOrNull()
            val bestPub = pub.mapNotNull { it.medianColdMs }.minOrNull()
            if (bestOp != null && bestPub != null && bestOp - bestPub > 20) {
                out += netIssue("Operator DNS slower than public resolvers", Severity.MINOR, Team.CORE_DNS,
                    listOf("Median lookup: operator $bestOp ms vs public $bestPub ms."),
                    "Resolver far from users, overloaded, or poor caching/recursion path.",
                    "Every new website or app connection starts later: noticeable on page loads and app start-up.",
                    listOf("Check resolver location (anycast/near the PGW), load and cache hit ratio."),
                    "Operator median ≤ public median + 5 ms.", d.at)
            }
        }

        // ---- latency / loss
        input.pings.forEach { p ->
            val avg = p.avgMs
            if (p.received > 0 && (p.lossPct >= 2f || (avg != null && avg > 80f) || (p.jitterMs ?: 0f) > 20f)) {
                out += netIssue("High latency / loss to ${p.label}", if (p.lossPct >= 5f) Severity.MAJOR else Severity.MINOR,
                    Team.TRANSPORT,
                    listOf("${p.method} to ${p.target}: avg ${f0(avg)} ms, max ${f0(p.maxMs)} ms, jitter ${f0(p.jitterMs)} ms, loss ${f0(p.lossPct)}%."),
                    "Congestion or loss on backhaul/transit, or radio retransmissions if radio quality is poor at the time.",
                    "Laggy video calls and gaming, slow page start, VoIP apps (WhatsApp etc.) choppy.",
                    listOf("Compare with RAN latency KPIs; if the radio is clean, check backhaul and peering utilisation/loss for the site."),
                    "Avg RTT < 50 ms, jitter < 10 ms, loss < 1%.", System.currentTimeMillis())
            }
        }

        // ---- device notes (not tickets)
        val staleCount = input.anomalies.count { it.type == AnomalyType.STALE_DATA }
        if (staleCount > 0) {
            out += netIssue("Device reported repeated (cached) measurements", Severity.MINOR, Team.DEVICE,
                listOf("$staleCount period(s) with identical values for 10+ samples."),
                "The phone's modem sometimes returns cached values to apps.",
                "None for users; some measurements in this report may be stale.",
                listOf("No network action. Treat values in those periods with caution."), "—", null)
        }
        if (!input.sinrReported && input.samples > 0) {
            out += netIssue("Device doesn't report SINR/CQI", Severity.MINOR, Team.DEVICE,
                listOf("No SINR values in ${input.samples} samples."),
                "Vendor modem limitation.",
                "None for users; quality is judged from RSRQ only.",
                listOf("No network action. Use a device that reports SINR for detailed quality analysis."), "—", null)
        }

        val sorted = out.sortedWith(
            compareBy<Issue> { if (it.team == Team.DEVICE) 1 else 0 }
                .thenBy { it.severity.ordinal }
                .thenByDescending { it.occurrences }
                .thenByDescending { it.durationS }
        )
        val withIds = sorted.mapIndexed { i, it -> it.copy(id = "R${i + 1}") }
        return withIds.map { iss ->
            val related = withIds.filter { o ->
                o.id != iss.id && o.team != Team.DEVICE && iss.team != Team.DEVICE &&
                    o.cellLabel != null && iss.evidence.any { e -> e.contains(o.cellLabel) }
            }.map { it.id }
            if (related.isEmpty()) iss else iss.copy(evidence = iss.evidence + "Related issues: ${related.joinToString(", ")}.")
        }
    }

    private fun netIssue(
        title: String, sev: Severity, team: Team, ev: List<String>, cause: String, impact: String,
        actions: List<String>, verify: String, at: Long?
    ) = Issue("", title, sev, team, null, null, null, null, at, at, 1, 0, ev, cause, impact, actions, verify)

    fun fmtTime(t: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(t))

    fun fmtDur(s: Long): String = when {
        s >= 3600 -> "${s / 3600} h ${(s % 3600) / 60} min"
        s >= 60 -> "${s / 60} min ${s % 60} s"
        else -> "$s s"
    }
}

/** Markdown (for people and email) and CSV (one row per issue, for trackers) exporters. */
object IssueReport {

    fun markdown(input: IssueInput, issues: List<Issue>): String {
        val sb = StringBuilder()
        val df = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        val tickets = issues.filter { it.team != Team.DEVICE }
        val notes = issues.filter { it.team == Team.DEVICE }
        val loc = issues.firstOrNull { it.lat != null }
        sb.append("# Radio issue report: ${input.operator}\n\n")
        sb.append("- **Period:** ${df.format(Date(input.from))} → ${df.format(Date(input.to))}\n")
        sb.append("- **Device:** ${input.device}\n")
        sb.append("- **Samples:** ${input.samples}\n")
        if (loc?.mapLink != null) sb.append("- **Location:** ${loc.lat}, ${loc.lon} (${loc.mapLink})\n")
        sb.append("- **Issues for network teams:** ${tickets.size} ")
        sb.append("(${tickets.count { it.severity == Severity.CRITICAL }} critical, ${tickets.count { it.severity == Severity.MAJOR }} major, ${tickets.count { it.severity == Severity.MINOR }} minor)\n\n")
        appendKpis(sb, input)
        appendNetwork(sb, input)

        if (tickets.isEmpty()) {
            sb.append("No network issues detected in this period.\n\n")
        } else {
            sb.append("## Summary\n\n| ID | Severity | Issue | Team | Service impact |\n|---|---|---|---|---|\n")
            tickets.forEach { i ->
                sb.append("| ${i.id} | ${i.severity.label} | ${i.title.replace("|", "/")} | ${i.team.label} | ${i.impact.substringBefore(". ").replace("|", "/")} |\n")
            }
            sb.append("\n## By team\n\n")
            tickets.groupBy { it.team }.forEach { (team, list) ->
                sb.append("- **${team.label}:** ${list.joinToString(", ") { it.id }}\n")
            }
            sb.append("\n")
            tickets.forEach { i -> appendIssue(sb, i) }
        }
        if (notes.isNotEmpty()) {
            sb.append("## Notes (device, not network faults)\n\n")
            notes.forEach { n -> sb.append("- **${n.title}:** ${n.evidence.joinToString(" ")} ${n.impact}\n") }
            sb.append("\n")
        }
        sb.append("---\nGenerated by Radio KPI from on-device measurements (Android telephony API). ")
        sb.append("Signalling is inferred, not raw RRC/NAS. Verify against OSS counters before changing parameters.\n")
        return sb.toString()
    }

    private fun f1(v: Float?) = v?.let { String.format(Locale.US, "%.1f", it) } ?: "—"
    private fun pct(v: Float?) = v?.let { String.format(Locale.US, "%.1f%%", it) } ?: "—"

    private fun appendKpis(sb: StringBuilder, input: IssueInput) {
        val s = input.summary ?: return
        if (s.samples == 0) return
        sb.append("## Key indicators\n\n| KPI | Value | Target |\n|---|---|---|\n")
        sb.append("| Availability (in service) | ${pct(s.availabilityPct)} | ≥ 99.5% |\n")
        sb.append("| Avg signal level | ${f1(s.levelAvg)} dBm (min ${s.levelMin ?: "—"}, max ${s.levelMax ?: "—"}) | ≥ −100 dBm |\n")
        sb.append("| Good coverage (≥ −100 dBm 4G) | ${pct(s.goodPct)} | ≥ 90% |\n")
        sb.append("| Avg RSRQ | ${f1(s.rsrqAvg)} dB | ≥ −12 dB |\n")
        if (s.sinrAvg != null) sb.append("| Avg SINR / SINR ≥ 13 dB | ${f1(s.sinrAvg)} dB / ${pct(s.sinrGoodPct)} | ≥ 10 dB / ≥ 60% |\n")
        sb.append("| 5G time | ${pct(s.fiveGPct)} | — |\n")
        if (s.nrRsrpAvg != null) {
            sb.append("| 5G NR leg: avg SS-RSRP / SS-SINR | ${f1(s.nrRsrpAvg)} dBm / ${f1(s.nrSinrAvg)} dB | ≥ −100 dBm / ≥ 10 dB |\n")
        }
        sb.append("| Carrier aggregation time | ${pct(s.caPct)} | — |\n")
        sb.append("| Cell changes / cells seen | ${s.cellChanges} / ${s.uniqueCells} | — |\n")
        sb.append("| Anomalies detected | ${s.anomalies} | — |\n\n")
        if (input.bands.isNotEmpty()) {
            val tot = input.bands.values.sum().coerceAtLeast(1)
            sb.append("**Band usage:** " + input.bands.entries.joinToString(", ") { "${it.key} ${pct(it.value * 100f / tot)}" } + "\n\n")
        }
    }

    private fun appendNetwork(sb: StringBuilder, input: IssueInput) {
        val link = input.link
        if (link == null && input.dns == null && input.pings.isEmpty() && input.speed == null) return
        sb.append("## Data network tests\n\n")
        link?.let { l ->
            sb.append("- **Bearer:** ${l.transport} (${l.iface ?: "—"}), ${l.stack}, IPv4 ${l.ipv4.firstOrNull() ?: "—"}${if (l.cgnat) " (CGNAT)" else ""}, MTU ${l.mtu ?: "—"}\n")
            sb.append("- **DNS:** ${l.dns.joinToString(", ").ifBlank { "—" }} · Private DNS: ${l.privateDns}\n")
        }
        input.speed?.let { sp ->
            sb.append("- **Speed test:** DL ${f1(sp.dlMbps)} Mbps / UL ${f1(sp.ulMbps)} Mbps · radio: ${sp.radio}\n")
        }
        input.pings.forEach { p ->
            sb.append("- **Latency ${p.label}:** avg ${f1(p.avgMs)} ms, jitter ${f1(p.jitterMs)} ms, loss ${f1(p.lossPct)}% (${p.method})\n")
        }
        input.dns?.resolvers?.forEach { r ->
            sb.append("- **DNS ${r.name} (${r.server}):** median ${r.medianColdMs ?: "—"} ms cold / ${r.medianWarmMs ?: "—"} ms cached, success ${pct(r.successPct)}\n")
        }
        sb.append("\n")
    }

    private fun appendIssue(sb: StringBuilder, i: Issue) {
        sb.append("## ${i.id}: ${i.title}\n\n")
        sb.append("**Severity:** ${i.severity.label} · **Team:** ${i.team.label}\n\n")
        IssueBuilder.cellLine(i.cell)?.let { sb.append("**Cell:** $it\n\n") }
            ?: i.cellLabel?.let { sb.append("**Cell:** $it\n\n") }
        if (i.first != null) {
            sb.append("**When:** ${IssueBuilder.fmtTime(i.first)}")
            if (i.last != null && i.last != i.first) sb.append(" → ${IssueBuilder.fmtTime(i.last)}")
            sb.append("\n\n")
        }
        i.mapLink?.let { sb.append("**Where:** ${i.lat}, ${i.lon} ($it)\n\n") }
        sb.append("**Evidence:**\n")
        i.evidence.forEach { sb.append("- $it\n") }
        sb.append("\n**Probable cause:** ${i.cause}\n\n")
        sb.append("**Service impact:** ${i.impact}\n\n")
        sb.append("**Recommended actions:**\n")
        i.actions.forEachIndexed { n, a -> sb.append("${n + 1}. $a\n") }
        sb.append("\n**Done when:** ${i.verify}\n\n---\n\n")
    }

    private fun q(s: String?): String = "\"" + (s ?: "").replace("\"", "\"\"").replace("\n", " ") + "\""

    fun csv(issues: List<Issue>): String {
        val sb = StringBuilder()
        sb.append("id,severity,team,issue,cell,enb,sector,pci,arfcn,band,tac,lat,lon,first_seen,last_seen,occurrences,duration_s,evidence,probable_cause,service_impact,actions,done_when\n")
        issues.forEach { i ->
            val c = i.cell
            sb.append(listOf(
                q(i.id), q(i.severity.label), q(i.team.label), q(i.title), q(i.cellLabel),
                q(c?.enb?.toString()), q(c?.sector?.toString()), q(c?.pci?.toString()), q(c?.arfcn?.toString()),
                q(c?.band), q(c?.tac?.toString()), q(i.lat?.toString()), q(i.lon?.toString()),
                q(i.first?.let { IssueBuilder.fmtTime(it) }), q(i.last?.let { IssueBuilder.fmtTime(it) }),
                q(i.occurrences.toString()), q(i.durationS.toString()),
                q(i.evidence.joinToString(" | ")), q(i.cause), q(i.impact),
                q(i.actions.mapIndexed { n, a -> "${n + 1}) $a" }.joinToString(" ")), q(i.verify)
            ).joinToString(","))
            sb.append("\n")
        }
        return sb.toString()
    }
}
