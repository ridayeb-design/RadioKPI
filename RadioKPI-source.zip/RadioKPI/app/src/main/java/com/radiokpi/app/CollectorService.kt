package com.radiokpi.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Foreground service for 24/7 collection: keeps the process alive with a persistent notification
 * (type "location", required for cell info in the background) and a partial wake lock.
 */
class CollectorService : Service() {

    companion object {
        private const val CHANNEL = "collector"
        private const val NOTIF_ID = 42
        private const val ACTION_STOP = "com.radiokpi.app.STOP"

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, CollectorService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, CollectorService::class.java).setAction(ACTION_STOP))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var wakeLock: PowerManager.WakeLock? = null
    private val engine by lazy { RadioEngine.get(this) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            engine.setBackground(false)
            engine.pause()
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        createChannel()
        try {
            ServiceCompat.startForeground(
                this, NOTIF_ID, build(),
                if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
            )
        } catch (e: Exception) {
            // e.g. restarted by the system while the app is in the background (Android 14 rules)
            engine.setBackground(false)
            stopSelf()
            return START_NOT_STICKY
        }
        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RadioKPI:collector").apply {
                setReferenceCounted(false)
                acquire(24 * 3_600_000L)
            }
        }
        engine.start()
        engine.setBackground(true)
        scope.coroutineContext[Job]?.children?.forEach { it.cancel() }
        scope.launch {
            val nm = getSystemService(NotificationManager::class.java)
            while (isActive) {
                delay(15_000)
                try { nm.notify(NOTIF_ID, build()) } catch (_: Exception) { }
                // Renew the wake lock well before it expires.
                wakeLock?.let { if (!it.isHeld) it.acquire(24 * 3_600_000L) }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) { }
        wakeLock = null
        engine.setBackground(false)
        super.onDestroy()
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "24/7 collection", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Shown while Radio KPI is collecting radio data in the background"
                    setShowBadge(false)
                }
            )
        }
    }

    private fun build(): Notification {
        val st = engine.state.value
        val s = st.snapshot
        val c = s?.serving
        val title = if (s == null || c == null) "Radio KPI · collecting" else "${s.techLabel} · ${c.cellLabel}"
        val text = listOfNotNull(
            c?.primaryDbm?.let { "level $it dBm" },
            c?.sinr?.let { "SINR $it dB" },
            "${st.kpis.samples} samples",
            st.anomalies.count { it.ongoing }.takeIf { it > 0 }?.let { "$it active issue(s)" }
        ).joinToString(" · ")

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, CollectorService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_radio)
            .setContentTitle(title)
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }
}
