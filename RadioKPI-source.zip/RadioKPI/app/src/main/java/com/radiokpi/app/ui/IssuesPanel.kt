package com.radiokpi.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.radiokpi.app.analysis.Issue
import com.radiokpi.app.analysis.IssueBuilder
import com.radiokpi.app.analysis.Team

/** List of team-ready issues; tap one to see cause, impact and actions. */
@Composable
fun IssuesPanel(title: String, issues: List<Issue>, onExport: (() -> Unit)?, exportLabel: String = "Export issue report") {
    val tickets = issues.filter { it.team != Team.DEVICE }
    val notes = issues.filter { it.team == Team.DEVICE }
    Panel(title = title, trailing = "${tickets.size} issue(s)") {
        if (tickets.isEmpty()) {
            Text("No network issues detected so far.", color = C.Muted, fontSize = 13.sp)
        }
        var open by rememberSaveable { mutableStateOf<String?>(null) }
        tickets.forEach { i ->
            val col = severityColor(i.severity)
            Column(
                Modifier.fillMaxWidth()
                    .clickable { open = if (open == i.id) null else i.id }
                    .padding(vertical = 7.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Dot(col)
                    Spacer(Modifier.width(8.dp))
                    Text("${i.id} · ${i.title}", color = C.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f))
                }
                Row(Modifier.padding(start = 16.dp, top = 3.dp)) {
                    Badge(i.severity.label, col)
                    Spacer(Modifier.width(6.dp))
                    Badge(i.team.label, C.Accent)
                }
                Text(i.impact.substringBefore(". ") + ".", color = C.Muted, fontSize = 12.sp,
                    modifier = Modifier.padding(start = 16.dp, top = 4.dp))
                if (open == i.id) {
                    Column(Modifier.padding(start = 16.dp, top = 6.dp)) {
                        IssueBuilder.cellLine(i.cell)?.let { Label("Cell", it) }
                        i.evidence.forEach { Text("• $it", color = C.Text, fontSize = 12.sp, fontFamily = FontFamily.Monospace) }
                        Label("Probable cause", i.cause)
                        Label("Service impact", i.impact)
                        Text("Recommended actions", color = C.Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 6.dp))
                        i.actions.forEachIndexed { n, act -> Text("${n + 1}. $act", color = C.Text, fontSize = 12.sp) }
                        Label("Done when", i.verify)
                    }
                }
            }
        }
        if (notes.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            notes.forEach { Text("Note: ${it.title}", color = C.Muted, fontSize = 11.sp) }
        }
        if (onExport != null) {
            Spacer(Modifier.height(10.dp))
            Button(onClick = onExport, colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.Bg)) {
                Text(exportLabel, fontWeight = FontWeight.Bold)
            }
        } else {
            Text("Tap an issue for cause, impact and actions. Use Export report at the top to share everything.",
                color = C.Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
private fun Label(title: String, text: String) {
    Text(title, color = C.Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
    Text(text, color = C.Text, fontSize = 12.sp)
}
