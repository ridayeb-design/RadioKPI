package com.radiokpi.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.radiokpi.app.radio.Grade

@Composable
fun Panel(
    modifier: Modifier = Modifier,
    title: String? = null,
    trailing: String? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(C.Surface)
            .border(1.dp, C.Border, RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        if (title != null) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(title.uppercase(), color = C.Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp, modifier = Modifier.weight(1f))
                if (trailing != null) Text(trailing, color = C.Muted, fontSize = 11.sp)
            }
            Spacer(Modifier.height(10.dp))
        }
        content()
    }
}

/** Big metric tile: value, unit, quality grade and a strength bar. */
@Composable
fun MetricCard(
    label: String, value: Int?, unit: String, grade: Grade,
    rangeMin: Int, rangeMax: Int, modifier: Modifier = Modifier
) {
    val color = C.grade(grade)
    Column(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(C.Surface)
            .border(1.dp, C.Border, RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Text(label, color = C.Muted, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value?.toString() ?: "—", color = C.Text, fontSize = 28.sp,
                fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Spacer(Modifier.width(3.dp))
            Text(unit, color = C.Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 5.dp))
        }
        Spacer(Modifier.height(6.dp))
        val frac = if (value == null) 0f
        else ((value - rangeMin).toFloat() / (rangeMax - rangeMin)).coerceIn(0f, 1f)
        Box(Modifier.fillMaxWidth().height(5.dp).clip(CircleShape).background(C.Surface2)) {
            Box(Modifier.fillMaxWidth(frac).height(5.dp).clip(CircleShape).background(color))
        }
        Spacer(Modifier.height(6.dp))
        Text(grade.label, color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun InfoItem(label: String, value: String?, modifier: Modifier = Modifier) {
    Column(modifier.padding(vertical = 5.dp)) {
        Text(label, color = C.Muted, fontSize = 11.sp)
        Text(value ?: "—", color = C.Text, fontSize = 15.sp, fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Medium)
    }
}

/** Grid of label/value pairs, [cols] per row. */
@Composable
fun InfoGrid(items: List<Pair<String, String?>>, cols: Int = 3) {
    items.chunked(cols).forEach { row ->
        Row(Modifier.fillMaxWidth()) {
            row.forEach { (l, v) -> InfoItem(l, v, Modifier.weight(1f)) }
            repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
}

@Composable
fun KpiTile(label: String, value: String, sub: String? = null, color: Color = C.Text, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(C.Surface)
            .border(1.dp, C.Border, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Text(label, color = C.Muted, fontSize = 11.sp)
        Spacer(Modifier.height(2.dp))
        Text(value, color = color, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        if (sub != null) Text(sub, color = C.Muted, fontSize = 11.sp)
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) C.Accent else C.Surface2)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp)
    ) {
        Text(text, color = if (selected) C.Bg else C.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Badge(text: String, color: Color) {
    Box(
        Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.18f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

/** Horizontal percentage bar with label. */
@Composable
fun PctBar(label: String, pct: Float, color: Color) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Text(label, color = C.Text, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text("%.1f%%".format(pct), color = C.Muted, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
        }
        Spacer(Modifier.height(4.dp))
        Box(Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(C.Surface2)) {
            Box(Modifier.fillMaxWidth((pct / 100f).coerceIn(0f, 1f)).height(8.dp).clip(CircleShape).background(color))
        }
    }
}

/**
 * Line chart over a fixed window, with coloured quality bands behind it.
 * [bands] = list of (lowerBound, colour) ordered from top (best) to bottom.
 */
@Composable
fun TrendChart(
    title: String, unit: String, values: List<Int?>,
    min: Float, max: Float, bands: List<Pair<Float, Color>>,
    lineColor: Color, window: Int = 90
) {
    val shown = values.takeLast(window)
    val current = shown.lastOrNull { it != null }
    Panel(title = title, trailing = current?.let { "now $it $unit" } ?: "no data") {
        Row {
            Column(Modifier.height(130.dp).width(34.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Text(max.toInt().toString(), color = C.Muted, fontSize = 10.sp)
                Text(((max + min) / 2).toInt().toString(), color = C.Muted, fontSize = 10.sp)
                Text(min.toInt().toString(), color = C.Muted, fontSize = 10.sp)
            }
            Canvas(Modifier.weight(1f).height(130.dp)) {
                val w = size.width
                val h = size.height
                fun y(v: Float) = h - (v.coerceIn(min, max) - min) / (max - min) * h
                var top = max
                for ((lower, c) in bands) {
                    val y0 = y(top); val y1 = y(lower)
                    drawRect(c.copy(alpha = 0.09f), topLeft = Offset(0f, y0), size = Size(w, y1 - y0))
                    top = lower
                }
                if (shown.size >= 2) {
                    val step = w / (window - 1)
                    val path = Path()
                    var started = false
                    shown.forEachIndexed { i, v ->
                        if (v == null) {
                            started = false
                        } else {
                            val x = i * step
                            val yy = y(v.toFloat())
                            if (!started) { path.moveTo(x, yy); started = true } else path.lineTo(x, yy)
                        }
                    }
                    drawPath(path, lineColor, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                    val lastIdx = shown.indexOfLast { it != null }
                    if (lastIdx >= 0) {
                        drawCircle(lineColor, radius = 4.dp.toPx(),
                            center = Offset(lastIdx * step, y(shown[lastIdx]!!.toFloat())))
                    }
                }
            }
        }
    }
}

@Composable
fun Dot(color: Color) {
    Box(Modifier.size(8.dp).clip(CircleShape).background(color))
}
