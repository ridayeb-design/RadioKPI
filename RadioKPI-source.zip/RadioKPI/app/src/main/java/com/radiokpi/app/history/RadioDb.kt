package com.radiokpi.app.history

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.radiokpi.app.analysis.Anomaly
import com.radiokpi.app.radio.RadioSnapshot
import com.radiokpi.app.radio.Rat
import com.radiokpi.app.signalling.RrcEstimate
import com.radiokpi.app.signalling.SigEvent
import com.radiokpi.app.signalling.SigType
import java.io.File

/** On-device storage for samples, anomalies and signalling events (plain SQLite, no extra libraries). */
class RadioDb private constructor(private val ctx: Context) : SQLiteOpenHelper(ctx, NAME, null, VERSION) {

    companion object {
        const val NAME = "radiokpi.db"
        const val VERSION = 2
        const val RETENTION_MS = 14L * 86_400_000L

        @Volatile private var inst: RadioDb? = null
        fun get(ctx: Context): RadioDb =
            inst ?: synchronized(this) { inst ?: RadioDb(ctx.applicationContext).also { inst = it } }

        private val MOBILITY = listOf(
            SigType.HO_INTRA, SigType.HO_INTER, SigType.HO_IRAT, SigType.RESEL_INTRA,
            SigType.RESEL_INTER, SigType.RESEL_IRAT, SigType.CELL_CHANGE
        ).joinToString(",") { "'${it.name}'" }

        private const val GOOD = "(level IS NOT NULL AND ((rat IN ('LTE','NR') AND level >= -100) OR (rat NOT IN ('LTE','NR') AND level >= -95)))"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE samples (
                ts INTEGER NOT NULL, lat REAL, lon REAL, speed REAL, op TEXT, nettype TEXT, tech TEXT,
                rat TEXT, band TEXT, cell TEXT, pci INTEGER, arfcn INTEGER, tac INTEGER, cid INTEGER,
                level INTEGER, rsrq INTEGER, sinr INTEGER, cqi INTEGER, ta INTEGER,
                nr_rsrp INTEGER, nr_sinr INTEGER, cc INTEGER, bw INTEGER, neigh INTEGER, rrc TEXT,
                nb_pci INTEGER, nb_arfcn INTEGER, nb_level INTEGER, close6 INTEGER)"""
        )
        db.execSQL("CREATE INDEX idx_samples_ts ON samples(ts)")
        db.execSQL(
            """CREATE TABLE anomalies (type TEXT NOT NULL, start INTEGER NOT NULL, endts INTEGER,
                cell TEXT, detail TEXT, lat REAL, lon REAL, worst INTEGER, PRIMARY KEY(type, start))"""
        )
        db.execSQL("CREATE INDEX idx_anom_start ON anomalies(start)")
        db.execSQL("CREATE TABLE sig (ts INTEGER NOT NULL, type TEXT, layer TEXT, detail TEXT, cell TEXT)")
        db.execSQL("CREATE INDEX idx_sig_ts ON sig(ts)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            listOf("nb_pci", "nb_arfcn", "nb_level", "close6").forEach { col ->
                try { db.execSQL("ALTER TABLE samples ADD COLUMN $col INTEGER") } catch (_: Exception) { }
            }
        }
    }

    // ---------------------------------------------------------------- writes

    fun insertSample(s: RadioSnapshot, rrc: RrcEstimate) {
        val c = s.serving
        val v = ContentValues().apply {
            put("ts", s.timestamp)
            s.location?.let { put("lat", it.lat); put("lon", it.lon); put("speed", it.speedKmh.toDouble()) }
            put("op", s.operator)
            put("nettype", s.networkType)
            put("tech", s.techLabel)
            put("rat", c?.rat?.name)
            put("band", c?.bandKey)
            put("cell", c?.cellLabel)
            put("pci", c?.pci)
            put("arfcn", c?.arfcn)
            put("tac", c?.tac)
            put("cid", c?.cellId)
            put("level", c?.primaryDbm)
            put("rsrq", c?.let { if (it.rat == Rat.WCDMA) it.ecno else it.rsrq })
            put("sinr", c?.sinr)
            put("cqi", c?.cqi)
            put("ta", c?.ta)
            put("nr_rsrp", s.nsa?.ssRsrp)
            put("nr_sinr", s.nsa?.ssSinr)
            put("cc", s.ccBandwidthsKhz.size.takeIf { it > 0 })
            put("bw", s.ccBandwidthsKhz.takeIf { it.isNotEmpty() }?.sum())
            put("neigh", s.neighbours.size)
            put("rrc", rrc.name)
            // Strongest co-channel neighbour and how many are within 6 dB (pilot pollution / PCI checks).
            val lvl = c?.primaryDbm
            val co = if (c == null) emptyList() else s.neighbours.filter {
                it.rat == c.rat && it.primaryDbm != null && (it.arfcn == null || c.arfcn == null || it.arfcn == c.arfcn)
            }
            val best = co.maxByOrNull { it.primaryDbm ?: -999 }
            put("nb_pci", best?.pci)
            put("nb_arfcn", best?.arfcn)
            put("nb_level", best?.primaryDbm)
            put("close6", if (lvl == null) null else co.count { (it.primaryDbm ?: -999) >= lvl - 6 })
        }
        writableDatabase.insert("samples", null, v)
    }

    fun upsertAnomalies(list: List<Anomaly>) {
        if (list.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            list.forEach { a ->
                val v = ContentValues().apply {
                    put("type", a.type.name); put("start", a.start); put("endts", a.end)
                    put("cell", a.cell); put("detail", a.detail); put("lat", a.lat); put("lon", a.lon); put("worst", a.worst)
                }
                db.insertWithOnConflict("anomalies", null, v, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    /** Fallbacks re-classified as CSFB: delete the old FALLBACK rows, then store the new type. */
    fun retypeCsfb(list: List<Anomaly>) {
        if (list.isEmpty()) return
        list.forEach { a ->
            writableDatabase.delete("anomalies", "type = ? AND start = ?", arrayOf("FALLBACK_LEGACY", a.start.toString()))
        }
        upsertAnomalies(list)
    }

    fun insertSig(list: List<SigEvent>) {
        if (list.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            list.forEach { e ->
                val v = ContentValues().apply {
                    put("ts", e.t); put("type", e.type.name); put("layer", e.type.layer.tag)
                    put("detail", e.detail); put("cell", e.cell)
                }
                db.insert("sig", null, v)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun purgeOld(now: Long = System.currentTimeMillis()) {
        val cut = (now - RETENTION_MS).toString()
        val db = writableDatabase
        db.delete("samples", "ts < ?", arrayOf(cut))
        db.delete("anomalies", "start < ?", arrayOf(cut))
        db.delete("sig", "ts < ?", arrayOf(cut))
    }

    fun clearAll() {
        val db = writableDatabase
        db.delete("samples", null, null)
        db.delete("anomalies", null, null)
        db.delete("sig", null, null)
        try { db.execSQL("VACUUM") } catch (_: Exception) { }
    }

    // ---------------------------------------------------------------- reads

    private fun Cursor.fOrNull(i: Int): Float? = if (isNull(i)) null else getFloat(i)
    private fun Cursor.iOrNull(i: Int): Int? = if (isNull(i)) null else getInt(i)

    private inline fun <T> query(sql: String, map: (Cursor) -> T): List<T> {
        val out = mutableListOf<T>()
        readableDatabase.rawQuery(sql, null).use { c -> while (c.moveToNext()) out += map(c) }
        return out
    }

    fun load(range: Range, now: Long = System.currentTimeMillis(), fromOverride: Long? = null, bucketOverride: Long? = null): HistoryData {
        val from = fromOverride ?: (now - range.ms)
        val b = bucketOverride ?: range.bucketMs
        val w = "ts >= $from"

        val buckets = query(
            """SELECT (ts / $b) * $b AS t, COUNT(*), AVG(level), MIN(level), MAX(level), AVG(sinr), AVG(rsrq), AVG(cqi),
               SUM(CASE WHEN $GOOD THEN 1 ELSE 0 END), SUM(CASE WHEN rat IS NULL THEN 1 ELSE 0 END),
               SUM(CASE WHEN tech LIKE '5G%' THEN 1 ELSE 0 END), SUM(CASE WHEN cc > 1 THEN 1 ELSE 0 END),
               AVG(nr_rsrp), AVG(nr_sinr)
               FROM samples WHERE $w GROUP BY t ORDER BY t"""
        ) { c ->
            val n = c.getInt(1).coerceAtLeast(1)
            Bucket(
                t = c.getLong(0), samples = c.getInt(1), levelAvg = c.fOrNull(2), levelMin = c.iOrNull(3),
                levelMax = c.iOrNull(4), sinrAvg = c.fOrNull(5), rsrqAvg = c.fOrNull(6), cqiAvg = c.fOrNull(7),
                goodPct = c.getInt(8) * 100f / n, noServicePct = c.getInt(9) * 100f / n,
                fiveGPct = c.getInt(10) * 100f / n, caPct = c.getInt(11) * 100f / n,
                nrRsrpAvg = c.fOrNull(12), nrSinrAvg = c.fOrNull(13)
            )
        }

        val techRows = query("SELECT (ts / $b) * $b AS t, tech, COUNT(*) FROM samples WHERE $w GROUP BY t, tech ORDER BY t") { c ->
            Triple(c.getLong(0), c.getString(1) ?: "Unknown", c.getInt(2))
        }
        val tech = techRows.groupBy { it.first }.map { (t, rows) -> TechBucket(t, rows.associate { it.second to it.third }) }
        val techTotals = techRows.groupBy { it.second }.mapValues { e -> e.value.sumOf { it.third } }

        val bandTotals = query("SELECT COALESCE(band, 'No service'), COUNT(*) FROM samples WHERE $w GROUP BY 1 ORDER BY 2 DESC") { c ->
            c.getString(0) to c.getInt(1)
        }.toMap()

        val anomalyBuckets = query("SELECT (start / $b) * $b AS t, COUNT(*) FROM anomalies WHERE start >= $from GROUP BY t ORDER BY t") { c ->
            CountBucket(c.getLong(0), c.getInt(1))
        }
        val anomalyTypes = query("SELECT type, COUNT(*) FROM anomalies WHERE start >= $from GROUP BY type ORDER BY 2 DESC") { c ->
            c.getString(0) to c.getInt(1)
        }.toMap()

        val mobilityBuckets = query("SELECT (ts / $b) * $b AS t, COUNT(*) FROM sig WHERE ts >= $from AND type IN ($MOBILITY) GROUP BY t ORDER BY t") { c ->
            CountBucket(c.getLong(0), c.getInt(1))
        }

        val hours = query(
            """SELECT CAST(strftime('%H', ts / 1000, 'unixepoch', 'localtime') AS INTEGER) AS h, COUNT(*), AVG(level), AVG(sinr)
               FROM samples WHERE $w GROUP BY h ORDER BY h"""
        ) { c -> HourProfile(c.getInt(0), c.getInt(1), c.fOrNull(2), c.fOrNull(3)) }

        val cells = query(
            """SELECT cell, COUNT(*), AVG(level), AVG(sinr), band FROM samples WHERE $w AND cell IS NOT NULL
               GROUP BY cell ORDER BY COUNT(*) DESC LIMIT 12"""
        ) { c -> CellRow(c.getString(0), c.getInt(1), c.fOrNull(2), c.fOrNull(3), c.getString(4)) }

        val summary = query(
            """SELECT COUNT(*), MIN(ts), MAX(ts), AVG(level), MIN(level), MAX(level), AVG(sinr), AVG(rsrq),
               SUM(CASE WHEN $GOOD THEN 1 ELSE 0 END), SUM(CASE WHEN sinr >= 13 THEN 1 ELSE 0 END), COUNT(sinr),
               SUM(CASE WHEN rat IS NULL THEN 1 ELSE 0 END), SUM(CASE WHEN tech LIKE '5G%' THEN 1 ELSE 0 END),
               SUM(CASE WHEN cc > 1 THEN 1 ELSE 0 END), COUNT(DISTINCT cell), AVG(nr_rsrp), AVG(nr_sinr)
               FROM samples WHERE $w"""
        ) { c ->
            val n = c.getInt(0)
            val d = n.coerceAtLeast(1)
            RangeSummary(
                samples = n,
                firstTs = if (c.isNull(1)) null else c.getLong(1),
                lastTs = if (c.isNull(2)) null else c.getLong(2),
                levelAvg = c.fOrNull(3), levelMin = c.iOrNull(4), levelMax = c.iOrNull(5),
                sinrAvg = c.fOrNull(6), rsrqAvg = c.fOrNull(7),
                goodPct = c.getInt(8) * 100f / d,
                sinrGoodPct = if (c.getInt(10) == 0) null else c.getInt(9) * 100f / c.getInt(10),
                availabilityPct = 100f - c.getInt(11) * 100f / d,
                fiveGPct = c.getInt(12) * 100f / d,
                caPct = c.getInt(13) * 100f / d,
                anomalies = anomalyTypes.values.sum(),
                cellChanges = mobilityBuckets.sumOf { it.count },
                uniqueCells = c.getInt(14),
                nrRsrpAvg = c.fOrNull(15),
                nrSinrAvg = c.fOrNull(16)
            )
        }.first()

        val total = query("SELECT COUNT(*) FROM samples") { it.getLong(0) }.first()
        val sizeKb = File(ctx.getDatabasePath(NAME).path).length() / 1024

        return HistoryData(
            range, from, now, summary, buckets, tech, techTotals, bandTotals,
            anomalyBuckets, anomalyTypes, mobilityBuckets, hours, cells, total, sizeKb, b
        )
    }

    /** Builds the input for the team issue report from everything stored in the range. */
    fun issueInput(range: Range, operator: String, device: String, now: Long = System.currentTimeMillis()) =
        issueInputFrom(now - range.ms, operator, device, now)

    /** KPI summary for everything stored since [from]. */
    fun summarySince(from: Long): RangeSummary = load(Range.H1, System.currentTimeMillis(), from).summary

    fun bandsSince(from: Long): Map<String, Int> =
        query("SELECT COALESCE(band, 'No service'), COUNT(*) FROM samples WHERE ts >= $from GROUP BY 1 ORDER BY 2 DESC") { c ->
            c.getString(0) to c.getInt(1)
        }.toMap()

    fun issueInputFrom(from: Long, operator: String, device: String, now: Long = System.currentTimeMillis()): com.radiokpi.app.analysis.IssueInput {
        val anomalies = query(
            "SELECT type, start, endts, cell, detail, lat, lon, worst FROM anomalies WHERE start >= $from ORDER BY start"
        ) { c ->
            val type = try { com.radiokpi.app.analysis.AnomalyType.valueOf(c.getString(0)) } catch (_: Exception) { null }
            if (type == null) null else com.radiokpi.app.analysis.Anomaly(
                id = c.position.toLong() + 1, type = type, start = c.getLong(1),
                end = if (c.isNull(2)) c.getLong(1) else c.getLong(2), ongoing = false,
                detail = c.getString(4) ?: "", cell = c.getString(3),
                lat = if (c.isNull(5)) null else c.getDouble(5), lon = if (c.isNull(6)) null else c.getDouble(6),
                worst = c.iOrNull(7)
            )
        }.filterNotNull()
        val cells = query(
            """SELECT cell, MAX(rat), MAX(band), MAX(pci), MAX(arfcn), MAX(tac), MAX(cid), COUNT(*),
               SUM(level), COUNT(level), MIN(level), SUM(sinr), COUNT(sinr), SUM(rsrq), COUNT(rsrq), AVG(lat), AVG(lon)
               FROM samples WHERE ts >= $from AND cell IS NOT NULL GROUP BY cell"""
        ) { c ->
            val rat = try { Rat.valueOf(c.getString(1) ?: "UNKNOWN") } catch (_: Exception) { Rat.UNKNOWN }
            com.radiokpi.app.radio.CellStat(
                label = c.getString(0), rat = rat, samples = c.getInt(7),
                levelSum = c.getLong(8), levelCount = c.getInt(9), levelMin = c.iOrNull(10),
                sinrSum = c.getLong(11), sinrCount = c.getInt(12),
                pci = c.iOrNull(3), arfcn = c.iOrNull(4), tac = c.iOrNull(5),
                cellId = if (c.isNull(6)) null else c.getLong(6), band = c.getString(2),
                rsrqSum = c.getLong(13), rsrqCount = c.getInt(14),
                lat = if (c.isNull(15)) null else c.getDouble(15), lon = if (c.isNull(16)) null else c.getDouble(16)
            )
        }.associateBy { it.label }
        val (n, sinrN, t0, t1) = query("SELECT COUNT(*), COUNT(sinr), MIN(ts), MAX(ts) FROM samples WHERE ts >= $from") { c ->
            listOf(c.getLong(0), c.getLong(1), if (c.isNull(2)) from else c.getLong(2), if (c.isNull(3)) now else c.getLong(3))
        }.first()
        return com.radiokpi.app.analysis.IssueInput(
            from = t0, to = t1, operator = operator, device = device, samples = n.toInt(),
            anomalies = anomalies, cells = cells, sinrReported = sinrN > 0
        )
    }

    /** Writes all samples in the range to a CSV file. */
    fun exportCsv(range: Range, out: File, now: Long = System.currentTimeMillis()): Int = exportCsvSince(now - range.ms, out)

    fun exportCsvSince(from: Long, out: File): Int {
        var rows = 0
        out.bufferedWriter().use { w ->
            readableDatabase.rawQuery("SELECT * FROM samples WHERE ts >= $from ORDER BY ts", null).use { c ->
                w.write(c.columnNames.joinToString(",")); w.write("\n")
                while (c.moveToNext()) {
                    w.write((0 until c.columnCount).joinToString(",") { i ->
                        if (c.isNull(i)) "" else c.getString(i).replace(",", " ")
                    })
                    w.write("\n")
                    rows++
                }
            }
        }
        return rows
    }
}
