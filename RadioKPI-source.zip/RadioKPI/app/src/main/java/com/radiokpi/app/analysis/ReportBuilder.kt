package com.radiokpi.app.analysis

import com.radiokpi.app.net.NetUi
import com.radiokpi.app.radio.SessionKpis
import com.radiokpi.app.signalling.SigEvent
import com.radiokpi.app.signalling.SigSummary
import com.radiokpi.app.signalling.SigType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Builds a self-contained HTML report (opens in any browser, prints to PDF). */
object ReportBuilder {

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    private fun f1(v: Float?) = v?.let { String.format(Locale.US, "%.1f", it) } ?: "—"
    private fun pct(v: Float) = String.format(Locale.US, "%.1f%%", v)

    private fun dur(ms: Long): String {
        val s = ms / 1000
        return String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
    }

    private fun sevClass(s: Severity) = when (s) {
        Severity.CRITICAL -> "crit"; Severity.MAJOR -> "major"; Severity.MINOR -> "minor"
    }

    private fun levelClass(l: FindingLevel) = when (l) {
        FindingLevel.BAD -> "crit"; FindingLevel.WARN -> "major"; FindingLevel.INFO -> "info"; FindingLevel.GOOD -> "good"
    }

    fun build(
        device: String, operator: String, k: SessionKpis, events: List<Anomaly>, now: Long,
        sig: List<SigEvent> = emptyList(), net: NetUi? = null
    ): String {
        val dateFmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)
        val score = Insights.score(k, events, now)
        val findings = Insights.findings(k, events)
        val sev = Insights.countsBySeverity(events)
        val byType = Insights.countsByType(events)
        val worst = Insights.worstCells(k, events, 10)
        val sb = StringBuilder()

        sb.append(
            """<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Radio KPI report ${esc(dateFmt.format(Date(k.startedAt)))}</title>
<style>
body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;margin:0;background:#f5f6f8;color:#1b1f24}
main{max-width:900px;margin:0 auto;padding:20px}
h1{font-size:24px;margin:0 0 4px}h2{font-size:17px;margin:28px 0 10px;border-bottom:2px solid #e3e6ea;padding-bottom:6px}
.sub{color:#5b6570;font-size:13px}
.card{background:#fff;border:1px solid #e3e6ea;border-radius:12px;padding:14px;margin-bottom:10px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}
.kpi .l{font-size:12px;color:#5b6570}.kpi .v{font-size:22px;font-weight:700;font-family:ui-monospace,monospace}
.score{display:flex;align-items:center;gap:18px}.score .big{font-size:52px;font-weight:800;font-family:ui-monospace,monospace}
table{width:100%;border-collapse:collapse;font-size:13px;background:#fff}
th,td{text-align:left;padding:7px 8px;border-bottom:1px solid #eceef1;vertical-align:top}
th{background:#f0f2f5;font-weight:600}
td.n{font-family:ui-monospace,monospace;white-space:nowrap}
.tag{display:inline-block;padding:2px 8px;border-radius:6px;font-size:11px;font-weight:700}
.crit{background:#fde2e2;color:#b42318}.major{background:#fdecd8;color:#b54708}
.minor{background:#e8eefc;color:#2f4fb5}.info{background:#e8eefc;color:#2f4fb5}.good{background:#dcf5e6;color:#137a3f}
.f{border-left:4px solid #ccc;padding:8px 12px;margin:8px 0;background:#fff;border-radius:0 8px 8px 0;color:#1b1f24}
.f.crit{border-color:#d92d20}.f.major{border-color:#f79009}.f.info{border-color:#2f6fed}.f.good{border-color:#12b76a}
.f b{display:block;margin-bottom:2px}.f.crit b{color:#b42318}.f.major b{color:#b54708}.f.info b{color:#2f4fb5}.f.good b{color:#137a3f}
.bar{height:8px;background:#eceef1;border-radius:4px;overflow:hidden}.bar i{display:block;height:8px;background:#2f6fed}
footer{color:#8a939c;font-size:11px;margin:30px 0 10px}
@media print{body{background:#fff}.card,table{break-inside:avoid}}
</style></head><body><main>
"""
        )

        sb.append("<h1>Radio KPI report</h1>")
        sb.append("<div class=\"sub\">${esc(dateFmt.format(Date(k.startedAt)))} · duration ${dur(now - k.startedAt)} · ${k.samples} samples<br>")
        sb.append("${esc(device)} · operator ${esc(operator)}</div>")

        // Score
        sb.append("<h2>Network health</h2><div class=\"card score\">")
        if (score == null) {
            sb.append("<div>Not enough samples for a score (minimum ${Insights.MIN_SAMPLES}).</div>")
        } else {
            sb.append("<div class=\"big\">${score.total}</div><div><b>${esc(score.verdict)}</b><br>")
            sb.append("<span class=\"sub\">Coverage ${f1(score.coverage)}/40 · Quality ${f1(score.quality)}/30 · ")
            sb.append("Availability ${f1(score.availability)}/20 · Stability ${f1(score.stability)}/10</span></div>")
        }
        sb.append("</div>")

        // KPIs
        sb.append("<h2>Key indicators</h2><div class=\"grid\">")
        fun kpi(l: String, v: String) = sb.append("<div class=\"card kpi\"><div class=\"l\">${esc(l)}</div><div class=\"v\">${esc(v)}</div></div>")
        kpi("Availability", pct(k.availabilityPct))
        kpi("Avg level", "${f1(k.avgPrimary)} dBm")
        kpi("Min / max level", "${k.primaryMin ?: "—"} / ${k.primaryMax ?: "—"}")
        kpi("Avg RSRQ", "${f1(k.avgRsrq)} dB")
        kpi("Avg SINR", "${f1(k.avgSinr)} dB")
        kpi("Good coverage", pct(k.goodCoveragePct))
        kpi("Bad coverage", pct(k.badCoveragePct))
        kpi("SINR ≥ 13 dB", pct(k.goodSinrPct))
        kpi("5G time", pct(k.fiveGPct))
        kpi("CA time", pct(k.caPct))
        kpi("Cell changes", k.cellChanges.toString())
        kpi("Unique cells", k.uniqueCells.size.toString())
        sb.append("</div>")

        // Findings
        sb.append("<h2>Findings and recommendations</h2>")
        if (findings.isEmpty()) sb.append("<div class=\"card\">Not enough data yet.</div>")
        findings.forEach {
            sb.append("<div class=\"f ${levelClass(it.level)}\"><b>${esc(it.title)}</b>${esc(it.text)}</div>")
        }

        // Anomaly summary
        sb.append("<h2>Anomalies (${events.size})</h2><div class=\"card\">")
        sb.append("<span class=\"tag crit\">Critical ${sev[Severity.CRITICAL] ?: 0}</span> ")
        sb.append("<span class=\"tag major\">Major ${sev[Severity.MAJOR] ?: 0}</span> ")
        sb.append("<span class=\"tag minor\">Minor ${sev[Severity.MINOR] ?: 0}</span></div>")
        if (byType.isNotEmpty()) {
            sb.append("<table><tr><th>Type</th><th>Severity</th><th>Count</th><th>Total time</th><th>What to check</th></tr>")
            byType.forEach { (t, n) ->
                val total = events.filter { it.type == t }.sumOf { it.durationS }
                sb.append("<tr><td>${esc(t.title)}</td><td><span class=\"tag ${sevClass(t.severity)}\">${t.severity.label}</span></td>")
                sb.append("<td class=\"n\">$n</td><td class=\"n\">${dur(total * 1000)}</td><td>${esc(t.advice)}</td></tr>")
            }
            sb.append("</table>")
        }

        // Worst cells
        if (worst.isNotEmpty()) {
            sb.append("<h2>Cells to check</h2><table><tr><th>Cell</th><th>Samples</th><th>Avg level</th><th>Min</th><th>Avg SINR</th><th>Anomalies</th></tr>")
            worst.forEach { w ->
                sb.append("<tr><td>${esc(w.stat.label)}</td><td class=\"n\">${w.stat.samples}</td>")
                sb.append("<td class=\"n\">${f1(w.stat.avgLevel)}</td><td class=\"n\">${w.stat.levelMin ?: "—"}</td>")
                sb.append("<td class=\"n\">${f1(w.stat.avgSinr)}</td><td class=\"n\">${w.anomalies}</td></tr>")
            }
            sb.append("</table>")
        }

        // Bands
        if (k.bandStats.isNotEmpty()) {
            sb.append("<h2>Band usage</h2><table><tr><th>Band</th><th>Technology</th><th>Time share</th><th>Avg level</th><th></th></tr>")
            k.bandStats.entries.sortedByDescending { it.value.samples }.forEach { (band, st) ->
                val p = if (k.samples == 0) 0f else st.samples * 100f / k.samples
                sb.append("<tr><td>${esc(band)} ${esc(st.common)}</td><td>${esc(st.tech)}</td><td class=\"n\">${pct(p)}</td>")
                sb.append("<td class=\"n\">${f1(st.avgLevel)} dBm</td>")
                sb.append("<td style=\"width:30%\"><div class=\"bar\"><i style=\"width:${String.format(Locale.US, "%.1f", p)}%\"></i></div></td></tr>")
            }
            sb.append("</table>")
        }

        // Technology share
        if (k.ratCounts.isNotEmpty()) {
            sb.append("<h2>Technology share</h2><table><tr><th>Technology</th><th>Time share</th></tr>")
            k.ratCounts.entries.sortedByDescending { it.value }.forEach { (tech, n) ->
                sb.append("<tr><td>${esc(tech)}</td><td class=\"n\">${pct(if (k.samples == 0) 0f else n * 100f / k.samples)}</td></tr>")
            }
            sb.append("</table>")
        }

        // Event log
        if (events.isNotEmpty()) {
            sb.append("<h2>Event log</h2><table><tr><th>Time</th><th>Event</th><th>Duration</th><th>Cell</th><th>Details</th><th>Location</th></tr>")
            events.asReversed().take(300).forEach { a ->
                val loc = if (a.lat != null && a.lon != null)
                    "<a href=\"https://maps.google.com/?q=${a.lat},${a.lon}\">map</a>" else "—"
                sb.append("<tr><td class=\"n\">${timeFmt.format(Date(a.start))}</td>")
                sb.append("<td><span class=\"tag ${sevClass(a.type.severity)}\">${esc(a.type.title)}</span>${if (a.ongoing) " <i>(ongoing)</i>" else ""}</td>")
                sb.append("<td class=\"n\">${if (a.durationS > 0) "${a.durationS}s" else "—"}</td>")
                sb.append("<td>${esc(a.cell ?: "—")}</td><td>${esc(a.detail)}</td><td>$loc</td></tr>")
            }
            sb.append("</table>")
        }

        appendSignalling(sb, sig, timeFmt)
        if (net != null) appendNetwork(sb, net)

        sb.append("<footer>Generated by Radio KPI on ${esc(dateFmt.format(Date(now)))}. ")
        sb.append("Measurements come from the phone's modem through the Android API; thresholds are typical drive-test values.</footer>")
        sb.append("</main></body></html>")
        return sb.toString()
    }

    private fun appendSignalling(sb: StringBuilder, sig: List<SigEvent>, timeFmt: SimpleDateFormat) {
        if (sig.isEmpty()) return
        val c = SigSummary.counts(sig)
        fun n(t: SigType) = c[t] ?: 0
        sb.append("<h2>Signalling and mobility</h2>")
        sb.append("<div class=\"sub\">Inferred from Android telephony callbacks; not raw RRC/NAS messages.</div><br>")
        sb.append("<table><tr><th>Procedure</th><th>Count</th></tr>")
        listOf(
            "Handover intra / inter / IRAT" to "${n(SigType.HO_INTRA)} / ${n(SigType.HO_INTER)} / ${n(SigType.HO_IRAT)}",
            "Reselection intra / inter / IRAT" to "${n(SigType.RESEL_INTRA)} / ${n(SigType.RESEL_INTER)} / ${n(SigType.RESEL_IRAT)}",
            "Cell change (RRC state unknown)" to n(SigType.CELL_CHANGE).toString(),
            "TAU / LAU (area change)" to "${n(SigType.TAU)} / ${n(SigType.LAU)}",
            "EN-DC SgNB addition / release" to "${n(SigType.SGNB_ADD)} / ${n(SigType.SGNB_REL)}",
            "RRC connected / idle transitions (est.)" to "${n(SigType.RRC_CONNECTED)} / ${n(SigType.RRC_IDLE)}",
            "Out of service / limited service" to "${n(SigType.OUT_OF_SERVICE)} / ${n(SigType.EMERGENCY_ONLY)}",
            "PDN disconnected / suspended" to "${n(SigType.BEARER_DISCONNECTED)} / ${n(SigType.BEARER_SUSPENDED)}",
            "Carrier aggregation reconfigurations" to n(SigType.CA_CHANGE).toString()
        ).forEach { (l, v) -> sb.append("<tr><td>${esc(l)}</td><td class=\"n\">${esc(v)}</td></tr>") }
        sb.append("</table><br><table><tr><th>Time</th><th>Layer</th><th>Event</th><th>Details</th></tr>")
        sig.asReversed().take(300).forEach { e ->
            sb.append("<tr><td class=\"n\">${timeFmt.format(Date(e.t))}</td><td class=\"n\">${e.type.layer.tag}</td>")
            sb.append("<td>${esc(e.type.title)}</td><td>${esc(e.detail)}</td></tr>")
        }
        sb.append("</table>")
    }

    private fun appendNetwork(sb: StringBuilder, net: NetUi) {
        val link = net.link
        if (link == null && net.dns == null && net.pings.isEmpty() && net.speed == null) return
        sb.append("<h2>Data network and DNS</h2>")
        if (link != null) {
            sb.append("<table>")
            listOf(
                "Bearer" to "${link.transport} · ${link.iface ?: "—"}",
                "IP stack" to link.stack,
                "IPv4" to (link.ipv4.firstOrNull() ?: "—") + if (link.cgnat) " (CGNAT/private)" else "",
                "IPv6" to (link.ipv6.firstOrNull() ?: "—"),
                "DNS (network)" to link.dns.joinToString(", ").ifBlank { "—" },
                "Private DNS" to link.privateDns,
                "MTU" to (link.mtu?.toString() ?: "—")
            ).forEach { (l, v) -> sb.append("<tr><th style=\"width:30%\">${esc(l)}</th><td>${esc(v)}</td></tr>") }
            sb.append("</table><br>")
        }
        net.dns?.let { d ->
            sb.append("<table><tr><th>Resolver</th><th>Server</th><th>Median cold</th><th>Median cached</th><th>P90</th><th>Success</th><th>Timeouts</th><th>NXDOMAIN</th><th>AAAA</th></tr>")
            d.resolvers.forEach { r ->
                sb.append("<tr><td>${esc(r.name)}</td><td class=\"n\">${esc(r.server)}</td>")
                sb.append("<td class=\"n\">${r.medianColdMs ?: "—"} ms</td><td class=\"n\">${r.medianWarmMs ?: "—"} ms</td>")
                sb.append("<td class=\"n\">${r.p90Ms ?: "—"} ms</td><td class=\"n\">${pct(r.successPct)}</td><td class=\"n\">${r.timeouts}</td>")
                sb.append("<td>${when (r.nxdomainHijack) { true -> "<span class=\"tag crit\">HIJACK</span>"; false -> "clean"; null -> "—" }}</td>")
                sb.append("<td>${when (r.aaaa) { true -> "yes"; false -> "no"; null -> "—" }}</td></tr>")
            }
            sb.append("</table>")
            d.findings.forEach { sb.append("<div class=\"f info\">${esc(it)}</div>") }
        }
        if (net.pings.isNotEmpty()) {
            sb.append("<br><table><tr><th>Target</th><th>Method</th><th>Avg</th><th>Min</th><th>Max</th><th>Jitter</th><th>Loss</th></tr>")
            net.pings.forEach { p ->
                sb.append("<tr><td>${esc(p.label)} <span class=\"sub\">${esc(p.target)}</span></td><td>${p.method}</td>")
                sb.append("<td class=\"n\">${f1(p.avgMs)} ms</td><td class=\"n\">${f1(p.minMs)}</td><td class=\"n\">${f1(p.maxMs)}</td>")
                sb.append("<td class=\"n\">${f1(p.jitterMs)}</td><td class=\"n\">${pct(p.lossPct)}</td></tr>")
            }
            sb.append("</table>")
            net.pingFindings.forEach { sb.append("<div class=\"f info\">${esc(it)}</div>") }
        }
        if (net.http.isNotEmpty()) {
            sb.append("<br><table><tr><th>HTTP</th><th>Status</th><th>First</th><th>Repeat</th></tr>")
            net.http.forEach { h ->
                sb.append("<tr><td>${esc(h.url)}</td><td>${h.code ?: esc(h.error ?: "—")}</td>")
                sb.append("<td class=\"n\">${h.coldMs ?: "—"} ms</td><td class=\"n\">${h.warmMs ?: "—"} ms</td></tr>")
            }
            sb.append("</table>")
        }
        net.speed?.let { s ->
            sb.append("<br><div class=\"grid\">")
            sb.append("<div class=\"card kpi\"><div class=\"l\">Download</div><div class=\"v\">${f1(s.dlMbps)} Mbps</div></div>")
            sb.append("<div class=\"card kpi\"><div class=\"l\">Upload</div><div class=\"v\">${f1(s.ulMbps)} Mbps</div></div></div>")
            sb.append("<div class=\"sub\">Radio during test: ${esc(s.radio)}</div>")
        }
    }
}
