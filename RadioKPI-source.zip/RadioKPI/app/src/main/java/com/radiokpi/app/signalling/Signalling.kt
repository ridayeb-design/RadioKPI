package com.radiokpi.app.signalling

import com.radiokpi.app.radio.RadioSnapshot
import com.radiokpi.app.radio.Rat

/** Protocol layer tag shown next to each event (3GPP terminology). */
enum class Layer(val tag: String) {
    RRC("RRC"), NAS("NAS"), MOB("MOB"), PDN("PDN"), PHY("PHY"), CALL("CALL")
}

enum class SigType(val title: String, val layer: Layer) {
    HO_INTRA("Intra-frequency handover", Layer.MOB),
    HO_INTER("Inter-frequency handover", Layer.MOB),
    HO_IRAT("Inter-RAT handover", Layer.MOB),
    RESEL_INTRA("Intra-frequency cell reselection", Layer.RRC),
    RESEL_INTER("Inter-frequency cell reselection", Layer.RRC),
    RESEL_IRAT("Inter-RAT cell reselection", Layer.RRC),
    CELL_CHANGE("Serving cell change", Layer.MOB),
    TAU("Tracking Area Update (TAC change)", Layer.NAS),
    LAU("Location/Routing Area Update (LAC change)", Layer.NAS),
    SGNB_ADD("EN-DC SgNB Addition (NR leg added)", Layer.RRC),
    SGNB_REL("EN-DC SgNB Release (NR leg released)", Layer.RRC),
    CA_CHANGE("Carrier aggregation reconfiguration", Layer.RRC),
    RRC_CONNECTED("RRC_CONNECTED (estimated)", Layer.RRC),
    RRC_IDLE("RRC_IDLE / dormancy (estimated)", Layer.RRC),
    IN_SERVICE("Registered (IN_SERVICE)", Layer.NAS),
    OUT_OF_SERVICE("Out of service (no registration)", Layer.NAS),
    EMERGENCY_ONLY("Limited service (emergency only)", Layer.NAS),
    PLMN_CHANGE("PLMN / roaming change", Layer.NAS),
    BEARER_CONNECTED("Default EPS bearer / PDN connected", Layer.PDN),
    BEARER_SUSPENDED("Bearer suspended", Layer.PDN),
    BEARER_DISCONNECTED("PDN disconnected", Layer.PDN),
    BEARER_CONNECTING("PDN connecting", Layer.PDN),
    DISPLAY("RAT indicator change", Layer.PHY),
    CALL_MT("Incoming call (MT: paging implied if UE was idle)", Layer.CALL),
    CALL_ACTIVE("Call active (off-hook)", Layer.CALL),
    CALL_END("Call released", Layer.CALL)
}

data class SigEvent(val t: Long, val type: SigType, val detail: String, val cell: String? = null)

/** Data activity reported by the modem; DORMANT means the radio link went idle. */
enum class RrcEstimate { CONNECTED, IDLE, UNKNOWN }

/**
 * Infers mobility / RRC / NAS events from consecutive radio snapshots.
 * Connected-mode cell changes are handovers; idle-mode ones are reselections.
 */
class SnapshotInference {
    private var last: RadioSnapshot? = null

    fun reset() { last = null }

    fun process(s: RadioSnapshot, rrc: RrcEstimate): List<SigEvent> {
        val prev = last
        val out = mutableListOf<SigEvent>()
        val c = s.serving
        val p = prev?.serving
        if (prev != null && c != null && p != null) {
            if (c.key != p.key) {
                val sameRat = c.rat == p.rat
                val sameFreq = sameRat && c.arfcn != null && c.arfcn == p.arfcn
                val type = when (rrc) {
                    RrcEstimate.CONNECTED -> when {
                        !sameRat -> SigType.HO_IRAT
                        sameFreq -> SigType.HO_INTRA
                        else -> SigType.HO_INTER
                    }
                    RrcEstimate.IDLE -> when {
                        !sameRat -> SigType.RESEL_IRAT
                        sameFreq -> SigType.RESEL_INTRA
                        else -> SigType.RESEL_INTER
                    }
                    RrcEstimate.UNKNOWN -> SigType.CELL_CHANGE
                }
                val from = "${p.cellLabel} (${p.arfcnLabel} ${p.arfcn ?: "?"})"
                val to = "${c.cellLabel} (${c.arfcnLabel} ${c.arfcn ?: "?"})"
                val lv = listOfNotNull(p.primaryDbm?.let { "$it" }, c.primaryDbm?.let { "$it dBm" }).joinToString(" → ")
                out += SigEvent(s.timestamp, type, "$from → $to" + if (lv.isNotBlank()) "  [$lv]" else "", c.cellLabel)
            }
            val ta1 = p.tac
            val ta2 = c.tac
            if (ta1 != null && ta2 != null && ta1 != ta2) {
                val lte = c.rat == Rat.LTE || c.rat == Rat.NR
                out += SigEvent(
                    s.timestamp, if (lte) SigType.TAU else SigType.LAU,
                    "${c.areaLabel} $ta1 → $ta2" + if (lte) " (UE sends TAU Request)" else " (UE sends LAU/RAU)",
                    c.cellLabel
                )
            }
        }
        if (prev != null) {
            if (!prev.isNsa && s.isNsa) {
                out += SigEvent(s.timestamp, SigType.SGNB_ADD,
                    "NR leg up, SS-RSRP ${s.nsa?.ssRsrp ?: "?"} dBm, anchor ${c?.cellLabel ?: "?"}", c?.cellLabel)
            }
            if (prev.isNsa && !s.isNsa && c != null) {
                out += SigEvent(s.timestamp, SigType.SGNB_REL,
                    "NR leg released (last SS-RSRP ${prev.nsa?.ssRsrp ?: "?"} dBm), now ${s.techLabel}", c.cellLabel)
            }
            val cc1 = prev.ccBandwidthsKhz
            val cc2 = s.ccBandwidthsKhz
            if (cc1.isNotEmpty() && cc2.isNotEmpty() && cc1.size != cc2.size) {
                out += SigEvent(s.timestamp, SigType.CA_CHANGE,
                    "${cc1.size}CC → ${cc2.size}CC (${cc1.sum() / 1000} → ${cc2.sum() / 1000} MHz aggregated)", c?.cellLabel)
            }
        }
        last = s
        return out
    }
}

/** Mapping of Android telephony constants (kept as ints so they work on every API level). */
object TelephonyNames {
    fun serviceState(v: Int) = when (v) {
        0 -> "IN_SERVICE"; 1 -> "OUT_OF_SERVICE"; 2 -> "EMERGENCY_ONLY"; 3 -> "POWER_OFF"; else -> "STATE_$v"
    }

    fun dataState(v: Int) = when (v) {
        0 -> "DISCONNECTED"; 1 -> "CONNECTING"; 2 -> "CONNECTED"; 3 -> "SUSPENDED"
        4 -> "DISCONNECTING"; 5 -> "HANDOVER_IN_PROGRESS"; else -> "STATE_$v"
    }

    fun displayOverride(v: Int) = when (v) {
        0 -> "None (plain RAT)"; 1 -> "LTE CA"; 2 -> "LTE Advanced Pro (4G+)"
        3 -> "NR NSA (EN-DC, 5G icon)"; 4 -> "NR NSA mmWave"; 5 -> "NR Advanced (5G+)"; else -> "Override $v"
    }

    fun duplex(v: Int) = when (v) { 1 -> "FDD"; 2 -> "TDD"; else -> "?" }

    fun dataActivity(v: Int) = when (v) {
        0 -> "NONE"; 1 -> "IN"; 2 -> "OUT"; 3 -> "INOUT"; 4 -> "DORMANT"; else -> "?"
    }
}

/** Counts per category, for the summary grid and report. */
object SigSummary {
    fun counts(events: List<SigEvent>): Map<SigType, Int> = events.groupingBy { it.type }.eachCount()

    fun handovers(c: Map<SigType, Int>) =
        (c[SigType.HO_INTRA] ?: 0) + (c[SigType.HO_INTER] ?: 0) + (c[SigType.HO_IRAT] ?: 0)

    fun reselections(c: Map<SigType, Int>) =
        (c[SigType.RESEL_INTRA] ?: 0) + (c[SigType.RESEL_INTER] ?: 0) + (c[SigType.RESEL_IRAT] ?: 0)
}
