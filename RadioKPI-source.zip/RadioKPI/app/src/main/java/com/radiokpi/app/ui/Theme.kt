package com.radiokpi.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.radiokpi.app.radio.Grade

object C {
    val Bg = Color(0xFF0E1117)
    val Surface = Color(0xFF161B22)
    val Surface2 = Color(0xFF1F2630)
    val Border = Color(0xFF2A313C)
    val Text = Color(0xFFE6EDF3)
    val Muted = Color(0xFF8B949E)
    val Accent = Color(0xFF22D3EE)
    val Accent2 = Color(0xFFA78BFA)
    val Rec = Color(0xFFEF4444)

    fun grade(g: Grade): Color = when (g) {
        Grade.EXCELLENT -> Color(0xFF22C55E)
        Grade.GOOD -> Color(0xFF84CC16)
        Grade.FAIR -> Color(0xFFEAB308)
        Grade.POOR -> Color(0xFFF97316)
        Grade.BAD -> Color(0xFFEF4444)
        Grade.NA -> Color(0xFF6B7280)
    }
}

@Composable
fun RadioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.Accent,
            onPrimary = C.Bg,
            background = C.Bg,
            surface = C.Surface,
            onSurface = C.Text,
            onBackground = C.Text
        ),
        content = content
    )
}
