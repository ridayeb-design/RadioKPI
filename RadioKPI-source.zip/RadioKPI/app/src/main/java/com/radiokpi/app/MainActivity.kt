package com.radiokpi.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.radiokpi.app.analysis.ReportBuilder
import com.radiokpi.app.diag.DiagViewModel
import com.radiokpi.app.net.NetViewModel
import com.radiokpi.app.ui.NetActions
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.radiokpi.app.ui.Actions
import com.radiokpi.app.ui.DiagActions
import com.radiokpi.app.ui.C
import com.radiokpi.app.ui.RadioApp
import com.radiokpi.app.ui.RadioTheme

class MainActivity : ComponentActivity() {

    private val vm: RadioViewModel by viewModels()
    private val diagVm: DiagViewModel by viewModels()
    private val netVm: NetViewModel by viewModels()

    /** One-line radio summary attached to speed-test results. */
    private fun radioContext(): String {
        val s = vm.state.value.snapshot ?: return "no radio data"
        val c = s.serving ?: return "no service"
        return listOfNotNull(
            s.techLabel, c.cellLabel, c.arfcn?.let { "${c.arfcnLabel} $it" },
            c.primaryDbm?.let { "level $it dBm" }, c.sinr?.let { "SINR $it dB" }, c.cqi?.let { "CQI $it" },
            s.ccBandwidthsKhz.takeIf { it.isNotEmpty() }?.let { "${it.size}CC ${it.sum() / 1000} MHz" },
            s.nsa?.ssRsrp?.let { "NR SS-RSRP $it" }
        ).joinToString(" · ")
    }

    private val required = arrayOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.READ_PHONE_STATE
    )

    private fun hasPermissions() = required.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Keep the screen on while measuring (drive/walk tests).
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContent {
            RadioTheme {
                var granted by remember { mutableStateOf(hasPermissions()) }
                val launcher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestMultiplePermissions()
                ) { granted = hasPermissions() }

                val maskPicker = rememberLauncherForActivityResult(
                    ActivityResultContracts.OpenDocument()
                ) { uri -> if (uri != null) diagVm.importMask(uri) }

                LaunchedEffect(granted) { if (granted) vm.start() }

                Box(Modifier.fillMaxSize().background(C.Bg).safeDrawingPadding()) {
                    if (!granted) {
                        PermissionScreen { launcher.launch(required) }
                    } else {
                        val state by vm.state.collectAsStateWithLifecycle()
                        val diag by diagVm.state.collectAsStateWithLifecycle()
                        val net by netVm.state.collectAsStateWithLifecycle()
                        RadioApp(
                            state,
                            Actions(
                                onToggleRun = { if (state.running) vm.pause() else vm.start() },
                                onToggleLog = vm::toggleLogging,
                                onShareLog = { shareLog() },
                                onReset = vm::resetKpis,
                                onInterval = vm::setInterval,
                                onOpenLocationSettings = {
                                    startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                                },
                                onExportReport = { exportReport() }
                            ),
                            diag,
                            DiagActions(
                                onCheckRoot = { diagVm.checkRoot() },
                                onRefresh = { diagVm.detect() },
                                onImportMask = { maskPicker.launch(arrayOf("*/*")) },
                                onStart = { diagVm.startCapture() },
                                onStop = { diagVm.stopCapture() },
                                onUsbDiag = { on, preset -> diagVm.setUsbDiag(on, preset) }
                            ),
                            net,
                            NetActions(
                                onRefresh = { netVm.refreshLink() },
                                onDns = { netVm.runDns() },
                                onLatency = { netVm.runLatency() },
                                onSpeed = { netVm.runSpeed(radioContext()) }
                            )
                        )
                    }
                }
            }
        }
    }

    private fun exportReport() {
        val st = vm.state.value
        val html = ReportBuilder.build(
            device = "${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE}",
            operator = st.snapshot?.operator ?: "—",
            k = st.kpis,
            events = st.anomalies,
            now = System.currentTimeMillis(),
            sig = st.sigEvents,
            net = netVm.state.value
        )
        val dir = File(getExternalFilesDir(null), "logs").apply { mkdirs() }
        val name = "report_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".html"
        val f = File(dir, name)
        f.writeText(html)
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/html"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Radio KPI report")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "Share or open report"))
    }

    private fun shareLog() {
        val f = vm.state.value.logFile ?: return
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, f.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "Share radio log"))
    }
}

@Composable
private fun PermissionScreen(onGrant: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Radio KPI", color = C.Text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(
            "To read serving and neighbour cell measurements (RSRP, RSRQ, SINR…), Android requires " +
                "Location and Phone permissions. Nothing leaves your phone.",
            color = C.Muted, fontSize = 14.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onGrant,
            colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.Bg)
        ) { Text("Grant permissions", fontWeight = FontWeight.Bold) }
    }
}
