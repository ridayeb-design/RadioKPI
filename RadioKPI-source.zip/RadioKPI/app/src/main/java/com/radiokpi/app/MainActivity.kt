package com.radiokpi.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.ui.text.font.FontFamily
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.radiokpi.app.analysis.ReportBuilder
import com.radiokpi.app.diag.DiagViewModel
import com.radiokpi.app.net.NetViewModel
import com.radiokpi.app.history.HistoryReport
import com.radiokpi.app.history.RadioDb
import com.radiokpi.app.analysis.IssueBuilder
import com.radiokpi.app.analysis.IssueInput
import com.radiokpi.app.analysis.IssueReport
import com.radiokpi.app.history.HistoryViewModel
import com.radiokpi.app.ui.HistoryActions
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import android.net.Uri
import android.os.PowerManager
import com.radiokpi.app.ui.NetActions
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.radiokpi.app.ui.Actions
import com.radiokpi.app.ui.DiagActions
import com.radiokpi.app.ui.C
import com.radiokpi.app.ui.RadioApp
import com.radiokpi.app.ui.RadioTheme

class MainActivity : ComponentActivity() {

    private val vm: RadioViewModel by viewModels()
    private val diagVm: DiagViewModel by viewModels()
    private val netVm: NetViewModel by viewModels()
    private val historyVm: HistoryViewModel by viewModels()

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        CollectorService.start(this)
    }

    private fun toggle247() {
        if (vm.state.value.background) {
            CollectorService.stop(this)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            CollectorService.start(this)
        }
    }

    @android.annotation.SuppressLint("BatteryLife")
    private fun openBatterySettings() {
        val pm = getSystemService(PowerManager::class.java)
        val intent = if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
        } else {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        }
        try { startActivity(intent) } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun shareFile(f: File, mime: String, title: String) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, f.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, title))
    }

    private fun logsDir() = File(getExternalFilesDir(null), "logs").apply { mkdirs() }
    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun deviceName() = "${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE}"

    /** Issue input for the live session, including the latest network test results. */
    private fun sessionIssueInput(): IssueInput {
        val st = vm.state.value
        val net = netVm.state.value
        return IssueInput(
            from = st.kpis.startedAt, to = st.snapshot?.timestamp ?: System.currentTimeMillis(),
            operator = st.snapshot?.operator ?: "—", device = deviceName(), samples = st.kpis.samples,
            anomalies = st.anomalies, cells = st.kpis.cellStats, sinrReported = st.kpis.sinrCount > 0,
            link = net.link, dns = net.dns, pings = net.pings, speed = net.speed
        )
    }

    private fun shareIssueFiles(input: IssueInput, tag: String) {
        val issues = IssueBuilder.build(input)
        val md = File(logsDir(), "issues_${tag}_${stamp()}.md").apply { writeText(IssueReport.markdown(input, issues)) }
        val csv = File(logsDir(), "issues_${tag}_${stamp()}.csv").apply { writeText(IssueReport.csv(issues)) }
        val uris = arrayListOf(
            FileProvider.getUriForFile(this, "$packageName.fileprovider", md),
            FileProvider.getUriForFile(this, "$packageName.fileprovider", csv)
        )
        val send = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "text/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            putExtra(Intent.EXTRA_SUBJECT, "Radio issue report ${input.operator}")
            putExtra(Intent.EXTRA_TEXT, IssueReport.markdown(input, issues).take(3000))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "Share issue report"))
    }

    private fun exportSessionIssues() = shareIssueFiles(sessionIssueInput(), "session")

    // ---------------------------------------------------------------- the two main buttons

    /** Start: new session, live measuring and 24/7 background collection. */
    private fun startAll() {
        RadioEngine.get(this).beginSession()
        vm.start()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            CollectorService.start(this)
        }
    }

    /** Stop: ends background collection and measuring. Stored data is kept for Export. */
    private fun stopAll() {
        CollectorService.stop(this)
        vm.pause()
    }

    /** Export: report (.md) + issues (.csv) + raw samples (.csv) for everything since Start. */
    private fun exportAll() {
        val engine = RadioEngine.get(this)
        lifecycleScope.launch {
            val now = System.currentTimeMillis()
            val from = engine.sessionStart.takeIf { it in 1 until now } ?: (now - 24 * 3_600_000L)
            val op = vm.state.value.snapshot?.operator ?: "—"
            val tag = stamp()
            val db = RadioDb.get(this@MainActivity)
            val prepared = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                val base = db.issueInputFrom(from, op, deviceName(), now)
                if (base.samples == 0) null else {
                    val samplesCsv = File(logsDir(), "samples_$tag.csv")
                    db.exportCsvSince(from, samplesCsv)
                    base.copy(summary = db.summarySince(from), bands = db.bandsSince(from)) to samplesCsv
                }
            }
            if (prepared == null) {
                android.widget.Toast.makeText(this@MainActivity,
                    "No data yet. Tap Start and measure for a few minutes first.", android.widget.Toast.LENGTH_LONG).show()
                return@launch
            }
            val net = netVm.state.value
            val input = prepared.first.copy(link = net.link, dns = net.dns, pings = net.pings, speed = net.speed)
            val issues = IssueBuilder.build(input)
            val md = File(logsDir(), "report_$tag.md").apply { writeText(IssueReport.markdown(input, issues)) }
            val csv = File(logsDir(), "issues_$tag.csv").apply { writeText(IssueReport.csv(issues)) }
            val uris = arrayListOf(md, csv, prepared.second).map {
                FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", it)
            }
            val send = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "text/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
                putExtra(Intent.EXTRA_SUBJECT, "Radio KPI report ${input.operator}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "Share report"))
        }
    }

    private fun exportHistoryIssues() {
        lifecycleScope.launch {
            val range = historyVm.state.value.range
            val op = vm.state.value.snapshot?.operator ?: "—"
            val input = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                RadioDb.get(this@MainActivity).issueInput(range, op, deviceName())
            }
            // Attach the latest network tests (DNS/latency/speed) too.
            val net = netVm.state.value
            shareIssueFiles(input.copy(link = net.link, dns = net.dns, pings = net.pings, speed = net.speed), range.name)
        }
    }

    private fun exportHistoryReport() {
        val d = historyVm.state.value.data ?: return
        val html = HistoryReport.build(
            d, "${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE}",
            vm.state.value.snapshot?.operator ?: "—"
        )
        val f = File(logsDir(), "history_${d.range.name}_${stamp()}.html")
        f.writeText(html)
        shareFile(f, "text/html", "Share or open history report")
    }

    private fun exportHistoryCsv() {
        lifecycleScope.launch {
            val f = File(logsDir(), "history_${historyVm.state.value.range.name}_${stamp()}.csv")
            historyVm.exportCsv(f)
            shareFile(f, "text/csv", "Share history CSV")
        }
    }

    /** One-line radio summary attached to speed-test results. */
    private fun radioContext(): String {
        val s = vm.state.value.snapshot ?: return "no radio data"
        val c = s.serving ?: return "no service"
        return listOfNotNull(
            s.techLabel, c.cellLabel, c.arfcn?.let { "${c.arfcnLabel} $it" },
            c.primaryDbm?.let { "level $it dBm" }, c.sinr?.let { "SINR $it dB" }, c.cqi?.let { "CQI $it" },
            s.ccBandwidthsKhz.takeIf { it.isNotEmpty() }?.let { "${it.size}CC ${it.sum() / 1000} MHz" },
            s.nsa?.ssRsrp?.let { "NR SS-RSRP $it" }
        ).joinToString(" · ")
    }

    private val required = arrayOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.READ_PHONE_STATE
    )

    private fun hasPermissions() = required.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashLog.install(this)
        val lastCrash = CrashLog.takeLast(this)
        enableEdgeToEdge()
        // Keep the screen on while measuring (drive/walk tests).
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContent {
            RadioTheme {
                var granted by remember { mutableStateOf(hasPermissions()) }
                var crashText by remember { mutableStateOf(lastCrash) }
                crashText?.let { txt ->
                    AlertDialog(
                        onDismissRequest = { crashText = null },
                        title = { Text("The app crashed last time") },
                        text = {
                            Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                                Text("Tap Copy and paste this to Claude so it can be fixed.", fontSize = 13.sp)
                                Spacer(Modifier.height(8.dp))
                                Text(txt, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                val cm = getSystemService(ClipboardManager::class.java)
                                cm.setPrimaryClip(ClipData.newPlainText("Radio KPI crash", txt))
                                crashText = null
                            }) { Text("Copy") }
                        },
                        dismissButton = { TextButton(onClick = { crashText = null }) { Text("Close") } }
                    )
                }
                val launcher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestMultiplePermissions()
                ) { granted = hasPermissions() }

                val maskPicker = rememberLauncherForActivityResult(
                    ActivityResultContracts.OpenDocument()
                ) { uri -> if (uri != null) diagVm.importMask(uri) }


                Box(Modifier.fillMaxSize().background(C.Bg).safeDrawingPadding()) {
                    if (!granted) {
                        PermissionScreen { launcher.launch(required) }
                    } else {
                        val state by vm.state.collectAsStateWithLifecycle()
                        val diag by diagVm.state.collectAsStateWithLifecycle()
                        val net by netVm.state.collectAsStateWithLifecycle()
                        val hist by historyVm.state.collectAsStateWithLifecycle()
                        RadioApp(
                            state,
                            Actions(
                                onToggleRun = { if (state.running) stopAll() else startAll() },
                                onToggleLog = vm::toggleLogging,
                                onShareLog = { shareLog() },
                                onReset = vm::resetKpis,
                                onInterval = vm::setInterval,
                                onOpenLocationSettings = {
                                    startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                                },
                                onExportReport = { exportReport() },
                                onExportIssues = { exportSessionIssues() },
                                onExportAll = { exportAll() }
                            ),
                            diag,
                            DiagActions(
                                onCheckRoot = { diagVm.checkRoot() },
                                onRefresh = { diagVm.detect() },
                                onImportMask = { maskPicker.launch(arrayOf("*/*")) },
                                onStart = { diagVm.startCapture() },
                                onStop = { diagVm.stopCapture() },
                                onUsbDiag = { on, preset -> diagVm.setUsbDiag(on, preset) }
                            ),
                            net,
                            NetActions(
                                onRefresh = { netVm.refreshLink() },
                                onDns = { netVm.runDns() },
                                onLatency = { netVm.runLatency() },
                                onSpeed = {
                                    val sn = vm.state.value.snapshot
                                    netVm.runSpeed(
                                        radioContext(),
                                        sn?.ccBandwidthsKhz?.takeIf { it.isNotEmpty() }?.sum()?.div(1000),
                                        sn?.serving?.rsrq,
                                        sn?.serving?.cellLabel
                                    )
                                }
                            ),
                            hist,
                            HistoryActions(
                                onRange = { r -> historyVm.load(r) },
                                onRefresh = { historyVm.load() },
                                onReport = { exportHistoryReport() },
                                onCsv = { exportHistoryCsv() },
                                onClear = { historyVm.clearAll() },
                                onToggle247 = { toggle247() },
                                onBatterySettings = { openBatterySettings() },
                                onIssueReport = { exportHistoryIssues() }
                            ),
                            remember(state.anomalies, state.kpis.samples / 5, net) {
                                IssueBuilder.build(sessionIssueInput())
                            }
                        )
                    }
                }
            }
        }
    }

    private fun exportReport() {
        val st = vm.state.value
        val html = ReportBuilder.build(
            device = "${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE}",
            operator = st.snapshot?.operator ?: "—",
            k = st.kpis,
            events = st.anomalies,
            now = System.currentTimeMillis(),
            sig = st.sigEvents,
            net = netVm.state.value
        )
        val dir = File(getExternalFilesDir(null), "logs").apply { mkdirs() }
        val name = "report_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".html"
        val f = File(dir, name)
        f.writeText(html)
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/html"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Radio KPI report")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "Share or open report"))
    }

    private fun shareLog() {
        val f = vm.state.value.logFile ?: return
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, f.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "Share radio log"))
    }
}

@Composable
private fun PermissionScreen(onGrant: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Radio KPI", color = C.Text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(
            "To read serving and neighbour cell measurements (RSRP, RSRQ, SINR…), Android requires " +
                "Location and Phone permissions. Nothing leaves your phone.",
            color = C.Muted, fontSize = 14.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onGrant,
            colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.Bg)
        ) { Text("Grant permissions", fontWeight = FontWeight.Bold) }
    }
}
