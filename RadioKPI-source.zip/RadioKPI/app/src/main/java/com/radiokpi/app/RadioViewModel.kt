package com.radiokpi.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.StateFlow

/** Screen-facing wrapper around the app-wide [RadioEngine]. */
class RadioViewModel(app: Application) : AndroidViewModel(app) {
    private val engine = RadioEngine.get(app)
    val state: StateFlow<UiState> = engine.state

    fun start() = engine.start()
    fun pause() = engine.pause()
    fun setInterval(ms: Long) = engine.setInterval(ms)
    fun resetKpis() = engine.resetKpis()
    fun toggleLogging() = engine.toggleLogging()

    override fun onCleared() {
        // Without 24/7 mode, stop measuring when the screen is gone to save battery.
        if (!engine.state.value.background) engine.pause()
        super.onCleared()
    }
}
