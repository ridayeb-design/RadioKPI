package com.radiokpi.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.radiokpi.app.analysis.Anomaly
import com.radiokpi.app.analysis.AnomalyDetector
import com.radiokpi.app.radio.BandStat
import com.radiokpi.app.radio.CellStat
import com.radiokpi.app.radio.CsvLogger
import com.radiokpi.app.radio.SessionKpis
import com.radiokpi.app.radio.TrendPoint
import com.radiokpi.app.radio.RadioReader
import com.radiokpi.app.radio.RadioSnapshot
import com.radiokpi.app.radio.Rat
import com.radiokpi.app.signalling.RrcEstimate
import com.radiokpi.app.signalling.SigEvent
import com.radiokpi.app.signalling.SignallingMonitor
import com.radiokpi.app.signalling.SnapshotInference
import java.io.File
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class UiState(
    val running: Boolean = false,
    val snapshot: RadioSnapshot? = null,
    val history: List<TrendPoint> = emptyList(),
    val kpis: SessionKpis = SessionKpis(),
    val logging: Boolean = false,
    val logFile: File? = null,
    val logRows: Int = 0,
    val intervalMs: Long = 2000,
    val error: String? = null,
    val locationOff: Boolean = false,
    val anomalies: List<Anomaly> = emptyList(),
    val sigEvents: List<SigEvent> = emptyList(),
    val rrc: RrcEstimate = RrcEstimate.UNKNOWN,
    val rrcConnectedMs: Long = 0,
    val rrcIdleMs: Long = 0,
    val dormantSeen: Boolean = false
)

class RadioViewModel(app: Application) : AndroidViewModel(app) {

    private val reader = RadioReader(app)
    private val logger = CsvLogger(app)
    private val detector = AnomalyDetector()
    private val inference = SnapshotInference()
    private val monitor = SignallingMonitor(app) { e -> addSig(listOf(e)) }

    private fun addSig(events: List<SigEvent>) {
        if (events.isEmpty()) return
        _state.update { it.copy(sigEvents = (it.sigEvents + events).takeLast(500)) }
    }
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var job: Job? = null
    private var lastServingKey: String? = null
    private var lastRat: Rat? = null

    fun start() {
        if (job?.isActive == true) return
        reader.startLocation()
        monitor.start()
        _state.update { it.copy(running = true) }
        job = viewModelScope.launch {
            while (isActive) {
                try {
                    val snap = reader.read()
                    onSnapshot(snap)
                    _state.update { it.copy(error = null, locationOff = !reader.isLocationEnabled()) }
                } catch (e: SecurityException) {
                    _state.update { it.copy(error = "Permission missing: grant Location and Phone permissions.") }
                } catch (e: Exception) {
                    _state.update { it.copy(error = e.message ?: e.javaClass.simpleName) }
                }
                delay(_state.value.intervalMs)
            }
        }
    }

    fun pause() {
        job?.cancel()
        job = null
        reader.stopLocation()
        monitor.stop()
        _state.update { it.copy(running = false) }
    }

    fun setInterval(ms: Long) = _state.update { it.copy(intervalMs = ms) }

    fun resetKpis() {
        lastServingKey = null
        lastRat = null
        detector.reset()
        inference.reset()
        monitor.resetCounters()
        _state.update {
            it.copy(kpis = SessionKpis(), history = emptyList(), anomalies = emptyList(), sigEvents = emptyList())
        }
    }

    fun toggleLogging() {
        if (_state.value.logging) {
            logger.stop()
            _state.update { it.copy(logging = false) }
        } else {
            val f = logger.start()
            _state.update { it.copy(logging = true, logFile = f, logRows = 0) }
        }
    }

    private fun onSnapshot(s: RadioSnapshot) {
        if (_state.value.logging) logger.log(s)
        val events = detector.process(s)
        addSig(inference.process(s, monitor.rrc))
        val (rrcConn, rrcIdle) = monitor.rrcTimes(s.timestamp)
        val c = s.serving
        val point = TrendPoint(s.timestamp, c?.primaryDbm, c?.rsrq, c?.sinr ?: s.nsa?.ssSinr, c?.rat)

        _state.update { st ->
            val k = st.kpis
            val primary = c?.primaryDbm
            val lteNr = c?.rat == Rat.LTE || c?.rat == Rat.NR
            val goodThr = if (lteNr) -100 else -95
            val exThr = if (lteNr) -90 else -85
            val badThr = if (lteNr) -110 else -105

            var cellChanges = k.cellChanges
            var ratChanges = k.ratChanges
            if (c != null) {
                val key = c.key
                if (lastServingKey != null && key != lastServingKey) cellChanges++
                if (lastRat != null && c.rat != lastRat) ratChanges++
                lastServingKey = key
                lastRat = c.rat
            }

            val newK = k.copy(
                samples = k.samples + 1,
                noService = k.noService + if (c == null) 1 else 0,
                primarySum = k.primarySum + (primary ?: 0),
                primaryCount = k.primaryCount + if (primary != null) 1 else 0,
                primaryMin = listOfNotNull(k.primaryMin, primary).minOrNull(),
                primaryMax = listOfNotNull(k.primaryMax, primary).maxOrNull(),
                sinrSum = k.sinrSum + (c?.sinr ?: 0),
                sinrCount = k.sinrCount + if (c?.sinr != null) 1 else 0,
                rsrqSum = k.rsrqSum + (c?.rsrq ?: 0),
                rsrqCount = k.rsrqCount + if (c?.rsrq != null) 1 else 0,
                goodCoverage = k.goodCoverage + if (primary != null && primary >= goodThr) 1 else 0,
                excellentCoverage = k.excellentCoverage + if (primary != null && primary >= exThr) 1 else 0,
                badCoverage = k.badCoverage + if (primary == null || primary < badThr) 1 else 0,
                goodSinr = k.goodSinr + if ((c?.sinr ?: Int.MIN_VALUE) >= 13) 1 else 0,
                fiveG = k.fiveG + if (c?.rat == Rat.NR || s.isNsa) 1 else 0,
                ratCounts = k.ratCounts + (s.techLabel to ((k.ratCounts[s.techLabel] ?: 0) + 1)),
                cellChanges = cellChanges,
                ratChanges = ratChanges,
                uniqueCells = if (c != null) k.uniqueCells + c.key else k.uniqueCells,
                caSamples = k.caSamples + if (s.caActive) 1 else 0,
                bandStats = if (c == null) k.bandStats else {
                    val key = c.bandKey
                    val old = k.bandStats[key] ?: BandStat(c.rat.label, c.bandResult?.common ?: "")
                    k.bandStats + (key to old.copy(
                        samples = old.samples + 1,
                        levelSum = old.levelSum + (primary ?: 0),
                        levelCount = old.levelCount + if (primary != null) 1 else 0,
                        lastArfcn = c.arfcn ?: old.lastArfcn
                    ))
                },
                cellStats = if (c == null) k.cellStats else {
                    val key = c.cellLabel
                    val old = k.cellStats[key] ?: CellStat(key, c.rat)
                    k.cellStats + (key to old.copy(
                        samples = old.samples + 1,
                        levelSum = old.levelSum + (primary ?: 0),
                        levelCount = old.levelCount + if (primary != null) 1 else 0,
                        levelMin = listOfNotNull(old.levelMin, primary).minOrNull(),
                        sinrSum = old.sinrSum + (c.sinr ?: 0),
                        sinrCount = old.sinrCount + if (c.sinr != null) 1 else 0
                    ))
                }
            )
            st.copy(
                snapshot = s,
                history = (st.history + point).takeLast(180),
                kpis = newK,
                logRows = logger.rows,
                anomalies = events,
                rrc = monitor.rrc,
                rrcConnectedMs = rrcConn,
                rrcIdleMs = rrcIdle,
                dormantSeen = monitor.dormantSeen
            )
        }
    }

    override fun onCleared() {
        logger.stop()
        reader.stopLocation()
        monitor.stop()
        super.onCleared()
    }
}
