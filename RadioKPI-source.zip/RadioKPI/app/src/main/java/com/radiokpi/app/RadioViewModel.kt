package com.radiokpi.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.radiokpi.app.radio.CsvLogger
import com.radiokpi.app.radio.RadioReader
import com.radiokpi.app.radio.RadioSnapshot
import com.radiokpi.app.radio.Rat
import java.io.File
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class TrendPoint(val t: Long, val primary: Int?, val rsrq: Int?, val sinr: Int?, val rat: Rat?)

data class BandStat(
    val tech: String,
    val common: String,
    val samples: Int = 0,
    val levelSum: Long = 0,
    val levelCount: Int = 0,
    val lastArfcn: Int? = null
) {
    val avgLevel: Float? get() = if (levelCount == 0) null else levelSum.toFloat() / levelCount
}

/** Session KPIs accumulated from every sample. */
data class SessionKpis(
    val startedAt: Long = System.currentTimeMillis(),
    val samples: Int = 0,
    val noService: Int = 0,
    val primarySum: Long = 0,
    val primaryCount: Int = 0,
    val primaryMin: Int? = null,
    val primaryMax: Int? = null,
    val sinrSum: Long = 0,
    val sinrCount: Int = 0,
    val rsrqSum: Long = 0,
    val rsrqCount: Int = 0,
    val goodCoverage: Int = 0,      // RSRP >= -100 dBm (LTE/NR) or RSCP >= -95 / RSSI >= -95
    val excellentCoverage: Int = 0, // RSRP >= -90
    val badCoverage: Int = 0,       // RSRP < -110
    val goodSinr: Int = 0,          // SINR >= 13 dB
    val fiveG: Int = 0,             // SA or NSA samples
    val ratCounts: Map<String, Int> = emptyMap(),
    val cellChanges: Int = 0,
    val ratChanges: Int = 0,
    val uniqueCells: Set<String> = emptySet(),
    val caSamples: Int = 0,
    val bandStats: Map<String, BandStat> = emptyMap()
) {
    val caPct get() = pct(caSamples)
    private fun pct(n: Int) = if (samples == 0) 0f else n * 100f / samples
    val avgPrimary: Float? get() = if (primaryCount == 0) null else primarySum.toFloat() / primaryCount
    val avgSinr: Float? get() = if (sinrCount == 0) null else sinrSum.toFloat() / sinrCount
    val avgRsrq: Float? get() = if (rsrqCount == 0) null else rsrqSum.toFloat() / rsrqCount
    val goodCoveragePct get() = pct(goodCoverage)
    val excellentCoveragePct get() = pct(excellentCoverage)
    val badCoveragePct get() = pct(badCoverage)
    val goodSinrPct get() = if (sinrCount == 0) 0f else goodSinr * 100f / sinrCount
    val fiveGPct get() = pct(fiveG)
    val noServicePct get() = pct(noService)
    val availabilityPct get() = 100f - noServicePct
}

data class UiState(
    val running: Boolean = false,
    val snapshot: RadioSnapshot? = null,
    val history: List<TrendPoint> = emptyList(),
    val kpis: SessionKpis = SessionKpis(),
    val logging: Boolean = false,
    val logFile: File? = null,
    val logRows: Int = 0,
    val intervalMs: Long = 2000,
    val error: String? = null,
    val locationOff: Boolean = false
)

class RadioViewModel(app: Application) : AndroidViewModel(app) {

    private val reader = RadioReader(app)
    private val logger = CsvLogger(app)
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var job: Job? = null
    private var lastServingKey: String? = null
    private var lastRat: Rat? = null

    fun start() {
        if (job?.isActive == true) return
        reader.startLocation()
        _state.update { it.copy(running = true) }
        job = viewModelScope.launch {
            while (isActive) {
                try {
                    val snap = reader.read()
                    onSnapshot(snap)
                    _state.update { it.copy(error = null, locationOff = !reader.isLocationEnabled()) }
                } catch (e: SecurityException) {
                    _state.update { it.copy(error = "Permission missing: grant Location and Phone permissions.") }
                } catch (e: Exception) {
                    _state.update { it.copy(error = e.message ?: e.javaClass.simpleName) }
                }
                delay(_state.value.intervalMs)
            }
        }
    }

    fun pause() {
        job?.cancel()
        job = null
        reader.stopLocation()
        _state.update { it.copy(running = false) }
    }

    fun setInterval(ms: Long) = _state.update { it.copy(intervalMs = ms) }

    fun resetKpis() {
        lastServingKey = null
        lastRat = null
        _state.update { it.copy(kpis = SessionKpis(), history = emptyList()) }
    }

    fun toggleLogging() {
        if (_state.value.logging) {
            logger.stop()
            _state.update { it.copy(logging = false) }
        } else {
            val f = logger.start()
            _state.update { it.copy(logging = true, logFile = f, logRows = 0) }
        }
    }

    private fun onSnapshot(s: RadioSnapshot) {
        if (_state.value.logging) logger.log(s)
        val c = s.serving
        val point = TrendPoint(s.timestamp, c?.primaryDbm, c?.rsrq, c?.sinr ?: s.nsa?.ssSinr, c?.rat)

        _state.update { st ->
            val k = st.kpis
            val primary = c?.primaryDbm
            val lteNr = c?.rat == Rat.LTE || c?.rat == Rat.NR
            val goodThr = if (lteNr) -100 else -95
            val exThr = if (lteNr) -90 else -85
            val badThr = if (lteNr) -110 else -105

            var cellChanges = k.cellChanges
            var ratChanges = k.ratChanges
            if (c != null) {
                val key = c.key
                if (lastServingKey != null && key != lastServingKey) cellChanges++
                if (lastRat != null && c.rat != lastRat) ratChanges++
                lastServingKey = key
                lastRat = c.rat
            }

            val newK = k.copy(
                samples = k.samples + 1,
                noService = k.noService + if (c == null) 1 else 0,
                primarySum = k.primarySum + (primary ?: 0),
                primaryCount = k.primaryCount + if (primary != null) 1 else 0,
                primaryMin = listOfNotNull(k.primaryMin, primary).minOrNull(),
                primaryMax = listOfNotNull(k.primaryMax, primary).maxOrNull(),
                sinrSum = k.sinrSum + (c?.sinr ?: 0),
                sinrCount = k.sinrCount + if (c?.sinr != null) 1 else 0,
                rsrqSum = k.rsrqSum + (c?.rsrq ?: 0),
                rsrqCount = k.rsrqCount + if (c?.rsrq != null) 1 else 0,
                goodCoverage = k.goodCoverage + if (primary != null && primary >= goodThr) 1 else 0,
                excellentCoverage = k.excellentCoverage + if (primary != null && primary >= exThr) 1 else 0,
                badCoverage = k.badCoverage + if (primary == null || primary < badThr) 1 else 0,
                goodSinr = k.goodSinr + if ((c?.sinr ?: Int.MIN_VALUE) >= 13) 1 else 0,
                fiveG = k.fiveG + if (c?.rat == Rat.NR || s.isNsa) 1 else 0,
                ratCounts = k.ratCounts + (s.techLabel to ((k.ratCounts[s.techLabel] ?: 0) + 1)),
                cellChanges = cellChanges,
                ratChanges = ratChanges,
                uniqueCells = if (c != null) k.uniqueCells + c.key else k.uniqueCells,
                caSamples = k.caSamples + if (s.caActive) 1 else 0,
                bandStats = if (c == null) k.bandStats else {
                    val key = c.bandKey
                    val old = k.bandStats[key] ?: BandStat(c.rat.label, c.bandResult?.common ?: "")
                    k.bandStats + (key to old.copy(
                        samples = old.samples + 1,
                        levelSum = old.levelSum + (primary ?: 0),
                        levelCount = old.levelCount + if (primary != null) 1 else 0,
                        lastArfcn = c.arfcn ?: old.lastArfcn
                    ))
                }
            )
            st.copy(
                snapshot = s,
                history = (st.history + point).takeLast(180),
                kpis = newK,
                logRows = logger.rows
            )
        }
    }

    override fun onCleared() {
        logger.stop()
        reader.stopLocation()
        super.onCleared()
    }
}
