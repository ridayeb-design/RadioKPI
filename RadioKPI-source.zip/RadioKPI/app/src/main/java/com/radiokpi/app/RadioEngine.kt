package com.radiokpi.app

import android.app.Application
import android.content.Context
import android.os.Handler
import android.os.Looper
import com.radiokpi.app.history.RadioDb
import com.radiokpi.app.analysis.Anomaly
import com.radiokpi.app.analysis.AnomalyDetector
import com.radiokpi.app.radio.BandStat
import com.radiokpi.app.radio.CellStat
import com.radiokpi.app.radio.CsvLogger
import com.radiokpi.app.radio.SessionKpis
import com.radiokpi.app.radio.TrendPoint
import com.radiokpi.app.radio.RadioReader
import com.radiokpi.app.radio.RadioSnapshot
import com.radiokpi.app.radio.Rat
import com.radiokpi.app.signalling.RrcEstimate
import com.radiokpi.app.signalling.SigEvent
import com.radiokpi.app.signalling.SignallingMonitor
import com.radiokpi.app.signalling.SnapshotInference
import java.io.File
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class UiState(
    val running: Boolean = false,
    val snapshot: RadioSnapshot? = null,
    val history: List<TrendPoint> = emptyList(),
    val kpis: SessionKpis = SessionKpis(),
    val logging: Boolean = false,
    val logFile: File? = null,
    val logRows: Int = 0,
    val intervalMs: Long = 2000,
    val error: String? = null,
    val locationOff: Boolean = false,
    val anomalies: List<Anomaly> = emptyList(),
    val sigEvents: List<SigEvent> = emptyList(),
    val rrc: RrcEstimate = RrcEstimate.UNKNOWN,
    val rrcConnectedMs: Long = 0,
    val rrcIdleMs: Long = 0,
    val dormantSeen: Boolean = false,
    val background: Boolean = false,      // 24/7 foreground service running
    val storedSamples: Long = 0           // samples written to the database this run
)

/**
 * App-wide measurement engine. Lives as long as the process (kept alive by CollectorService
 * in 24/7 mode), so collection continues when the screen is off or the app is closed.
 */
class RadioEngine private constructor(private val app: Application) {

    companion object {
        @Volatile private var inst: RadioEngine? = null
        fun get(ctx: Context): RadioEngine = inst ?: synchronized(this) {
            inst ?: RadioEngine(ctx.applicationContext as Application).also { inst = it }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val prefs = app.getSharedPreferences("radiokpi", Context.MODE_PRIVATE)
    private val db = RadioDb.get(app)
    private var lastPurge = 0L
    private var stored = 0L

    private val reader = RadioReader(app)
    private val logger = CsvLogger(app)
    private val detector = AnomalyDetector()
    private val inference = SnapshotInference()
    private val monitor = SignallingMonitor(app) { e -> addSig(listOf(e)) }

    private fun addSig(events: List<SigEvent>) {
        if (events.isEmpty()) return
        _state.update { it.copy(sigEvents = (it.sigEvents + events).takeLast(500)) }
        io.launch { try { db.insertSig(events) } catch (_: Exception) { } }
        // A call starting explains a recent drop to 3G (CSFB): re-classify it.
        if (events.any { it.type == com.radiokpi.app.signalling.SigType.CALL_MT || it.type == com.radiokpi.app.signalling.SigType.CALL_ACTIVE }) {
            val changed = detector.markCsfb(System.currentTimeMillis())
            if (changed.isNotEmpty()) {
                _state.update { it.copy(anomalies = detector.current()) }
                io.launch { try { db.retypeCsfb(changed) } catch (_: Exception) { } }
            }
        }
    }
    private val _state = MutableStateFlow(UiState(intervalMs = prefs.getLong("interval", 2000L)))
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var job: Job? = null
    private var lastServingKey: String? = null
    private var lastRat: Rat? = null

    val isRunning: Boolean get() = job?.isActive == true

    /** Start time of the current measurement session (set by the Start button), 0 if none. */
    val sessionStart: Long get() = prefs.getLong("sessionStart", 0L)

    /** New session: clears live KPIs and remembers the start time for Export report. */
    fun beginSession() {
        resetKpis()
        prefs.edit().putLong("sessionStart", System.currentTimeMillis()).apply()
    }

    fun setBackground(on: Boolean) = _state.update { it.copy(background = on) }

    fun start() {
        if (job?.isActive == true) return
        // Location updates and PhoneStateListener need the main thread.
        Handler(Looper.getMainLooper()).post {
            reader.startLocation()
            monitor.start()
        }
        _state.update { it.copy(running = true) }
        job = scope.launch {
            while (isActive) {
                try {
                    val snap = reader.read()
                    onSnapshot(snap)
                    _state.update { it.copy(error = null, locationOff = !reader.isLocationEnabled()) }
                } catch (e: SecurityException) {
                    _state.update { it.copy(error = "Permission missing: grant Location and Phone permissions.") }
                } catch (e: Exception) {
                    _state.update { it.copy(error = e.message ?: e.javaClass.simpleName) }
                }
                delay(_state.value.intervalMs)
            }
        }
    }

    fun pause() {
        job?.cancel()
        job = null
        Handler(Looper.getMainLooper()).post {
            reader.stopLocation()
            monitor.stop()
        }
        _state.update { it.copy(running = false) }
    }

    fun setInterval(ms: Long) {
        prefs.edit().putLong("interval", ms).apply()
        _state.update { it.copy(intervalMs = ms) }
    }

    fun resetKpis() {
        lastServingKey = null
        lastRat = null
        detector.reset()
        inference.reset()
        monitor.resetCounters()
        _state.update {
            it.copy(kpis = SessionKpis(), history = emptyList(), anomalies = emptyList(), sigEvents = emptyList())
        }
    }

    fun toggleLogging() {
        if (_state.value.logging) {
            logger.stop()
            _state.update { it.copy(logging = false) }
        } else {
            val f = logger.start()
            _state.update { it.copy(logging = true, logFile = f, logRows = 0) }
        }
    }

    private fun onSnapshot(raw: RadioSnapshot) {
        val s = if (monitor.inCall) raw.copy(inCall = true) else raw
        if (_state.value.logging) logger.log(s)
        val events = detector.process(s)
        addSig(inference.process(s, monitor.rrc))
        persist(s, events)
        val (rrcConn, rrcIdle) = monitor.rrcTimes(s.timestamp)
        val c = s.serving
        val point = TrendPoint(s.timestamp, c?.primaryDbm, c?.rsrq, c?.sinr ?: s.nsa?.ssSinr, c?.rat)

        _state.update { st ->
            val k = st.kpis
            val primary = c?.primaryDbm
            val lteNr = c?.rat == Rat.LTE || c?.rat == Rat.NR
            val goodThr = if (lteNr) -100 else -95
            val exThr = if (lteNr) -90 else -85
            val badThr = if (lteNr) -110 else -105

            var cellChanges = k.cellChanges
            var ratChanges = k.ratChanges
            if (c != null) {
                val key = c.key
                if (lastServingKey != null && key != lastServingKey) cellChanges++
                if (lastRat != null && c.rat != lastRat) ratChanges++
                lastServingKey = key
                lastRat = c.rat
            }

            val newK = k.copy(
                samples = k.samples + 1,
                noService = k.noService + if (c == null) 1 else 0,
                primarySum = k.primarySum + (primary ?: 0),
                primaryCount = k.primaryCount + if (primary != null) 1 else 0,
                primaryMin = listOfNotNull(k.primaryMin, primary).minOrNull(),
                primaryMax = listOfNotNull(k.primaryMax, primary).maxOrNull(),
                sinrSum = k.sinrSum + (c?.sinr ?: 0),
                sinrCount = k.sinrCount + if (c?.sinr != null) 1 else 0,
                rsrqSum = k.rsrqSum + (c?.rsrq ?: 0),
                rsrqCount = k.rsrqCount + if (c?.rsrq != null) 1 else 0,
                goodCoverage = k.goodCoverage + if (primary != null && primary >= goodThr) 1 else 0,
                excellentCoverage = k.excellentCoverage + if (primary != null && primary >= exThr) 1 else 0,
                badCoverage = k.badCoverage + if (primary == null || primary < badThr) 1 else 0,
                goodSinr = k.goodSinr + if ((c?.sinr ?: Int.MIN_VALUE) >= 13) 1 else 0,
                fiveG = k.fiveG + if (c?.rat == Rat.NR || s.isNsa) 1 else 0,
                ratCounts = k.ratCounts + (s.techLabel to ((k.ratCounts[s.techLabel] ?: 0) + 1)),
                cellChanges = cellChanges,
                ratChanges = ratChanges,
                uniqueCells = if (c != null) k.uniqueCells + c.key else k.uniqueCells,
                caSamples = k.caSamples + if (s.caActive) 1 else 0,
                bandStats = if (c == null) k.bandStats else {
                    val key = c.bandKey
                    val old = k.bandStats[key] ?: BandStat(c.rat.label, c.bandResult?.common ?: "")
                    k.bandStats + (key to old.copy(
                        samples = old.samples + 1,
                        levelSum = old.levelSum + (primary ?: 0),
                        levelCount = old.levelCount + if (primary != null) 1 else 0,
                        lastArfcn = c.arfcn ?: old.lastArfcn
                    ))
                },
                cellStats = if (c == null) k.cellStats else {
                    val key = c.cellLabel
                    val old = k.cellStats[key] ?: CellStat(key, c.rat)
                    val q = if (c.rat == Rat.WCDMA) c.ecno else c.rsrq
                    k.cellStats + (key to old.copy(
                        samples = old.samples + 1,
                        levelSum = old.levelSum + (primary ?: 0),
                        levelCount = old.levelCount + if (primary != null) 1 else 0,
                        levelMin = listOfNotNull(old.levelMin, primary).minOrNull(),
                        sinrSum = old.sinrSum + (c.sinr ?: 0),
                        sinrCount = old.sinrCount + if (c.sinr != null) 1 else 0,
                        pci = c.pci ?: old.pci,
                        arfcn = c.arfcn ?: old.arfcn,
                        tac = c.tac ?: old.tac,
                        cellId = c.cellId ?: old.cellId,
                        band = c.bandKey,
                        rsrqSum = old.rsrqSum + (q ?: 0),
                        rsrqCount = old.rsrqCount + if (q != null) 1 else 0,
                        lat = s.location?.lat ?: old.lat,
                        lon = s.location?.lon ?: old.lon
                    ))
                }
            )
            st.copy(
                snapshot = s,
                history = (st.history + point).takeLast(180),
                kpis = newK,
                logRows = logger.rows,
                anomalies = events,
                rrc = monitor.rrc,
                rrcConnectedMs = rrcConn,
                rrcIdleMs = rrcIdle,
                dormantSeen = monitor.dormantSeen,
                storedSamples = stored
            )
        }
    }

    /** Saves the sample and any anomalies created/updated in this round to the database. */
    private fun persist(s: RadioSnapshot, events: List<Anomaly>) {
        val rrc = monitor.rrc
        val touched = events.filter { it.end == s.timestamp || it.start == s.timestamp }
        io.launch {
            try {
                db.insertSample(s, rrc)
                stored++
                db.upsertAnomalies(touched)
                if (s.timestamp - lastPurge > 3_600_000L) {
                    lastPurge = s.timestamp
                    db.purgeOld(s.timestamp)
                }
            } catch (_: Exception) { }
        }
    }

}
