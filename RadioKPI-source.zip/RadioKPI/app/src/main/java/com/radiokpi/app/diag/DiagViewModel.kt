package com.radiokpi.app.diag

import android.app.Application
import android.net.Uri
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class ChipVendor(val label: String) {
    QUALCOMM("Qualcomm Snapdragon"),
    MEDIATEK("MediaTek"),
    EXYNOS("Samsung Exynos (Shannon modem)"),
    TENSOR("Google Tensor (Shannon modem)"),
    UNISOC("Unisoc"),
    UNKNOWN("Unknown")
}

data class DiagUi(
    val manufacturer: String = Build.MANUFACTURER,
    val model: String = Build.MODEL,
    val android: String = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
    val soc: String = "",
    val platform: String = "",
    val vendor: ChipVendor = ChipVendor.UNKNOWN,
    val detected: Boolean = false,
    val devDiagVisible: Boolean = false,  // seen without root (often hidden by SELinux)
    val suBinary: Boolean = false,
    val rootGranted: Boolean? = null,     // null = not checked yet
    val devDiagRoot: Boolean? = null,     // checked with root
    val mdlogPath: String? = null,
    val usbConfig: String? = null,
    val savedUsbConfig: String? = null,
    val capturing: Boolean = false,
    val captureDir: String? = null,
    val captureStart: Long? = null,
    val captureSizeKb: Long? = null,
    val maskName: String? = null,
    val busy: Boolean = false,
    val log: List<String> = emptyList()
) {
    val hasDiagNode: Boolean get() = devDiagRoot == true || devDiagVisible
    val canCapture: Boolean
        get() = vendor == ChipVendor.QUALCOMM && rootGranted == true && hasDiagNode && mdlogPath != null
    val canUsbDiag: Boolean
        get() = vendor == ChipVendor.QUALCOMM && rootGranted == true && hasDiagNode
    val usbDiagOn: Boolean get() = usbConfig?.contains("diag") == true
}

object Chipset {
    private val qcom = Regex("qcom|qualcomm|msm\\d|sdm\\d|sm\\d{4}|kona|lahaina|taro|kalama|pineapple|lito|holi|bengal|trinket|atoll|parrot|crow|blair|monaco|khaje")
    private val mtk = Regex("mt\\d{4}|mediatek|mtk")
    private val tensor = Regex("gs\\d{3}|zuma|tensor")
    private val exynos = Regex("exynos|s5e\\d|universal\\d")
    private val unisoc = Regex("ums\\d|sc98|unisoc|sprd")

    fun detect(socManufacturer: String, hints: String): ChipVendor {
        val m = socManufacturer.lowercase(Locale.US)
        val h = hints.lowercase(Locale.US)
        return when {
            m.contains("qti") || m.contains("qualcomm") -> ChipVendor.QUALCOMM
            m.contains("mediatek") -> ChipVendor.MEDIATEK
            m.contains("google") -> ChipVendor.TENSOR
            m.contains("samsung") -> ChipVendor.EXYNOS
            m.contains("spreadtrum") || m.contains("unisoc") -> ChipVendor.UNISOC
            qcom.containsMatchIn(h) -> ChipVendor.QUALCOMM
            mtk.containsMatchIn(h) -> ChipVendor.MEDIATEK
            tensor.containsMatchIn(h) -> ChipVendor.TENSOR
            exynos.containsMatchIn(h) -> ChipVendor.EXYNOS
            unisoc.containsMatchIn(h) -> ChipVendor.UNISOC
            else -> ChipVendor.UNKNOWN
        }
    }
}

/**
 * Qualcomm DIAG port tools:
 *  - on-device capture to .qmdl files with the vendor `diag_mdlog` logger (needs root + mask file)
 *  - switching the USB port to DIAG mode so PC tools (QXDM, QCAT, QCSuper, SCAT) can read it (needs root)
 */
class DiagViewModel(private val app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(DiagUi())
    val state: StateFlow<DiagUi> = _state.asStateFlow()

    private val maskFile: File get() = File(app.getExternalFilesDir("diag"), "mask.cfg")
    private val tmpMask = "/data/local/tmp/radiokpi_mask.cfg"
    private var proc: Process? = null
    private var sizeJob: Job? = null
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.US)

    init { detect() }

    private fun log(msg: String) =
        _state.update { it.copy(log = (it.log + "${clock.format(Date())}  $msg").takeLast(80)) }

    private fun busy(b: Boolean) = _state.update { it.copy(busy = b) }

    fun detect() = viewModelScope.launch(Dispatchers.IO) {
        val platform = Shell.getprop("ro.board.platform")
        val chipName = Shell.getprop("ro.hardware.chipname")
        val socMan = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MANUFACTURER else ""
        val socModel = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MODEL else ""
        val vendor = Chipset.detect(
            socMan, listOf(socModel, Build.HARDWARE, Build.BOARD, platform, chipName).joinToString(" ")
        )
        val soc = listOf(socMan, socModel)
            .filter { it.isNotBlank() && it != Build.UNKNOWN }
            .joinToString(" ")
            .ifBlank { Build.HARDWARE }
        _state.update {
            it.copy(
                soc = soc,
                platform = platform.ifBlank { chipName },
                vendor = vendor,
                detected = true,
                devDiagVisible = File("/dev/diag").exists(),
                suBinary = Shell.suBinaryPresent(),
                maskName = if (maskFile.exists()) maskFile.name else null
            )
        }
    }

    /** Asks for root (Magisk/KernelSU shows a prompt), then probes /dev/diag, diag_mdlog and USB config. */
    fun checkRoot() = viewModelScope.launch(Dispatchers.IO) {
        busy(true)
        log("Requesting root…")
        val r = Shell.run("id", root = true, timeoutMs = 30000)
        if (!r.out.contains("uid=0")) {
            log("Root not available: " + r.err.ifBlank { "su denied or not installed" }.take(140))
            _state.update { it.copy(rootGranted = false) }
            busy(false)
            return@launch
        }
        log("Root granted")
        val node = Shell.run("ls -l /dev/diag", root = true).out
        val mdlog = Shell.run(
            "for p in /vendor/bin/diag_mdlog /system/vendor/bin/diag_mdlog /system/bin/diag_mdlog; do " +
                "[ -x \$p ] && echo \$p && break; done",
            root = true
        ).out.trim().ifBlank { null }
        val usb = Shell.run("getprop sys.usb.config", root = true).out.trim()
        log("/dev/diag: " + if (node.contains("diag")) "present" else "absent")
        log("diag_mdlog: " + (mdlog ?: "not found"))
        log("USB config: $usb")
        _state.update {
            it.copy(rootGranted = true, devDiagRoot = node.contains("diag"), mdlogPath = mdlog, usbConfig = usb)
        }
        busy(false)
    }

    /** Copies a user-picked QXDM/QCSuper mask (.cfg) into app storage. */
    fun importMask(uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        try {
            maskFile.parentFile?.mkdirs()
            app.contentResolver.openInputStream(uri)?.use { input ->
                maskFile.outputStream().use { input.copyTo(it) }
            }
            log("Mask imported (${maskFile.length()} bytes)")
            _state.update { it.copy(maskName = maskFile.name) }
        } catch (e: Exception) {
            log("Mask import failed: ${e.message}")
        }
    }

    fun startCapture() = viewModelScope.launch(Dispatchers.IO) {
        val st = _state.value
        val mdlog = st.mdlogPath
        if (!st.canCapture || st.capturing || mdlog == null) return@launch
        busy(true)
        val dir = "/sdcard/Download/RadioKPI_diag/" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        Shell.run("mkdir -p $dir", root = true)
        var maskArg = ""
        if (maskFile.exists()) {
            Shell.run("cp '${maskFile.absolutePath}' $tmpMask && chmod 644 $tmpMask", root = true)
            maskArg = "-f $tmpMask "
        } else {
            log("No mask file: diag_mdlog will try its default mask (often missing, so little or nothing is logged)")
        }
        Shell.run("$mdlog -k", root = true, timeoutMs = 5000) // stop any running instance
        val cmd = "$mdlog ${maskArg}-o $dir"
        log("Start: $cmd")
        try {
            val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
            proc = p
            _state.update {
                it.copy(capturing = true, captureDir = dir, captureStart = System.currentTimeMillis(), captureSizeKb = 0)
            }
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    p.inputStream.bufferedReader().forEachLine { line ->
                        if (line.isNotBlank()) log(line.take(160))
                    }
                } catch (_: Exception) { }
                val code = try { p.waitFor() } catch (_: Exception) { -1 }
                if (_state.value.capturing) {
                    log("diag_mdlog stopped by itself (exit code $code)")
                    finishCapture(dir)
                }
            }
            sizeJob = viewModelScope.launch(Dispatchers.IO) {
                while (isActive) {
                    delay(3000)
                    refreshSize(dir)
                }
            }
        } catch (e: Exception) {
            log("Failed to start: ${e.message}")
        }
        busy(false)
    }

    fun stopCapture() = viewModelScope.launch(Dispatchers.IO) {
        val st = _state.value
        if (!st.capturing) return@launch
        busy(true)
        _state.update { it.copy(capturing = false) }
        st.mdlogPath?.let { Shell.run("$it -k", root = true, timeoutMs = 8000) }
        Shell.run("pkill -f diag_mdlog || killall diag_mdlog", root = true)
        proc?.destroy()
        proc = null
        st.captureDir?.let { finishCapture(it) }
        busy(false)
    }

    private fun finishCapture(dir: String) {
        sizeJob?.cancel()
        sizeJob = null
        Shell.run("chmod -R 777 $dir", root = true)
        refreshSize(dir)
        val files = Shell.run("ls $dir", root = true).out.lines().filter { it.isNotBlank() }
        log("Saved ${files.size} file(s) to $dir")
        _state.update { it.copy(capturing = false) }
    }

    private fun refreshSize(dir: String) {
        val kb = Shell.run("du -sk $dir", root = true).out.trim()
            .split(Regex("\\s+")).firstOrNull()?.toLongOrNull()
        if (kb != null) _state.update { it.copy(captureSizeKb = kb) }
    }

    /** Switches the USB port to a DIAG composition so PC tools can connect over USB. */
    fun setUsbDiag(on: Boolean, preset: String) = viewModelScope.launch(Dispatchers.IO) {
        if (_state.value.rootGranted != true) return@launch
        busy(true)
        if (on) {
            val current = Shell.run("getprop sys.usb.config", root = true).out.trim()
            if (!current.contains("diag")) _state.update { it.copy(savedUsbConfig = current) }
            Shell.run("setprop sys.usb.config $preset", root = true)
            log("USB set to: $preset")
        } else {
            val restore = _state.value.savedUsbConfig?.takeIf { it.isNotBlank() && !it.contains("diag") } ?: "mtp,adb"
            Shell.run("setprop sys.usb.config $restore", root = true)
            log("USB restored to: $restore")
        }
        delay(2000)
        val now = Shell.run("getprop sys.usb.config", root = true).out.trim()
        log("USB config now: $now")
        _state.update { it.copy(usbConfig = now) }
        busy(false)
    }

    override fun onCleared() {
        // Stop a running capture so the modem isn't left logging after the app closes.
        if (_state.value.capturing) {
            val mdlog = _state.value.mdlogPath
            Thread {
                mdlog?.let { Shell.run("$it -k", root = true) }
                Shell.run("pkill -f diag_mdlog", root = true)
            }.start()
        }
        proc?.destroy()
        super.onCleared()
    }
}
