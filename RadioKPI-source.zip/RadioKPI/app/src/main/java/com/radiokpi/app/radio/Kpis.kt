package com.radiokpi.app.radio

/** Per-cell accumulated stats, keyed by CellMeasurement.cellLabel. */
data class CellStat(
    val label: String,
    val rat: Rat,
    val samples: Int = 0,
    val levelSum: Long = 0,
    val levelCount: Int = 0,
    val levelMin: Int? = null,
    val sinrSum: Long = 0,
    val sinrCount: Int = 0,
    val pci: Int? = null,
    val arfcn: Int? = null,
    val tac: Int? = null,
    val cellId: Long? = null,
    val band: String? = null,
    val rsrqSum: Long = 0,
    val rsrqCount: Int = 0,
    val lat: Double? = null,
    val lon: Double? = null
) {
    val avgRsrq: Float? get() = if (rsrqCount == 0) null else rsrqSum.toFloat() / rsrqCount
    /** LTE: eNB = ECI / 256, sector = ECI % 256. */
    val enb: Long? get() = if (rat == Rat.LTE) cellId?.div(256) else null
    val sector: Long? get() = if (rat == Rat.LTE) cellId?.rem(256) else null

    val avgLevel: Float? get() = if (levelCount == 0) null else levelSum.toFloat() / levelCount
    val avgSinr: Float? get() = if (sinrCount == 0) null else sinrSum.toFloat() / sinrCount
}

data class TrendPoint(val t: Long, val primary: Int?, val rsrq: Int?, val sinr: Int?, val rat: Rat?)

data class BandStat(
    val tech: String,
    val common: String,
    val samples: Int = 0,
    val levelSum: Long = 0,
    val levelCount: Int = 0,
    val lastArfcn: Int? = null
) {
    val avgLevel: Float? get() = if (levelCount == 0) null else levelSum.toFloat() / levelCount
}

/** Session KPIs accumulated from every sample. */
data class SessionKpis(
    val startedAt: Long = System.currentTimeMillis(),
    val samples: Int = 0,
    val noService: Int = 0,
    val primarySum: Long = 0,
    val primaryCount: Int = 0,
    val primaryMin: Int? = null,
    val primaryMax: Int? = null,
    val sinrSum: Long = 0,
    val sinrCount: Int = 0,
    val rsrqSum: Long = 0,
    val rsrqCount: Int = 0,
    val goodCoverage: Int = 0,      // RSRP >= -100 dBm (LTE/NR) or RSCP >= -95 / RSSI >= -95
    val excellentCoverage: Int = 0, // RSRP >= -90
    val badCoverage: Int = 0,       // RSRP < -110
    val goodSinr: Int = 0,          // SINR >= 13 dB
    val fiveG: Int = 0,             // SA or NSA samples
    val ratCounts: Map<String, Int> = emptyMap(),
    val cellChanges: Int = 0,
    val ratChanges: Int = 0,
    val uniqueCells: Set<String> = emptySet(),
    val caSamples: Int = 0,
    val bandStats: Map<String, BandStat> = emptyMap(),
    val cellStats: Map<String, CellStat> = emptyMap()
) {
    val caPct get() = pct(caSamples)
    private fun pct(n: Int) = if (samples == 0) 0f else n * 100f / samples
    val avgPrimary: Float? get() = if (primaryCount == 0) null else primarySum.toFloat() / primaryCount
    val avgSinr: Float? get() = if (sinrCount == 0) null else sinrSum.toFloat() / sinrCount
    val avgRsrq: Float? get() = if (rsrqCount == 0) null else rsrqSum.toFloat() / rsrqCount
    val goodCoveragePct get() = pct(goodCoverage)
    val excellentCoveragePct get() = pct(excellentCoverage)
    val badCoveragePct get() = pct(badCoverage)
    val goodSinrPct get() = if (sinrCount == 0) 0f else goodSinr * 100f / sinrCount
    val fiveGPct get() = pct(fiveG)
    val noServicePct get() = pct(noService)
    val availabilityPct get() = 100f - noServicePct
}

