package com.radiokpi.app.history

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class HistoryUi(
    val range: Range = Range.SESSION,
    val loading: Boolean = false,
    val data: HistoryData? = null,
    val error: String? = null
)

class HistoryViewModel(app: Application) : AndroidViewModel(app) {
    private val db = RadioDb.get(app)
    private val _state = MutableStateFlow(HistoryUi())
    val state: StateFlow<HistoryUi> = _state.asStateFlow()

    fun load(range: Range = _state.value.range) = viewModelScope.launch {
        _state.update { it.copy(range = range, loading = true, error = null) }
        try {
            val d = withContext(Dispatchers.IO) {
                if (range == Range.SESSION) {
                    val now = System.currentTimeMillis()
                    val start = com.radiokpi.app.RadioEngine.get(getApplication()).sessionStart
                    val from = if (start in 1 until now) start else now - 3_600_000L
                    val dur = now - from
                    val bucket = when {
                        dur <= 2 * 3_600_000L -> 30_000L
                        dur <= 6 * 3_600_000L -> 2 * 60_000L
                        dur <= 24 * 3_600_000L -> 10 * 60_000L
                        dur <= 3 * 86_400_000L -> 30 * 60_000L
                        else -> 2 * 3_600_000L
                    }
                    db.load(range, now, from, bucket)
                } else db.load(range)
            }
            _state.update { it.copy(data = d, loading = false) }
        } catch (e: Exception) {
            _state.update { it.copy(loading = false, error = e.message ?: e.javaClass.simpleName) }
        }
    }

    suspend fun exportCsv(out: File): Int = withContext(Dispatchers.IO) { db.exportCsv(_state.value.range, out) }

    fun clearAll() = viewModelScope.launch {
        withContext(Dispatchers.IO) { db.clearAll() }
        load()
    }
}
