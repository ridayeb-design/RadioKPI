package com.radiokpi.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.radiokpi.app.diag.ChipVendor
import com.radiokpi.app.diag.DiagUi
import com.radiokpi.app.radio.Grade

data class DiagActions(
    val onCheckRoot: () -> Unit,
    val onRefresh: () -> Unit,
    val onImportMask: () -> Unit,
    val onStart: () -> Unit,
    val onStop: () -> Unit,
    val onUsbDiag: (Boolean, String) -> Unit
)

private val usbPresets = listOf(
    "diag,serial_cdev,rmnet,adb" to "Newer Snapdragon",
    "diag,adb" to "Basic"
)

@Composable
fun DiagTab(d: DiagUi, a: DiagActions) {
    // ---- Device
    Panel(title = "Device") {
        InfoGrid(
            listOf(
                "Phone" to "${d.manufacturer} ${d.model}",
                "System" to d.android,
                "SoC" to d.soc.ifBlank { null },
                "Platform" to d.platform.ifBlank { null }
            ),
            cols = 2
        )
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Chipset vendor", color = C.Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Badge(d.vendor.label, if (d.vendor == ChipVendor.QUALCOMM) C.grade(Grade.EXCELLENT) else C.grade(Grade.FAIR))
        }
    }

    // ---- Requirements
    val rootPending = d.rootGranted == null
    Panel(title = "Requirements for diag capture") {
        CheckRow(
            "Qualcomm chipset", d.vendor == ChipVendor.QUALCOMM,
            if (d.vendor == ChipVendor.QUALCOMM) "DIAG protocol supported"
            else "This app's diag tools only work with Qualcomm modems"
        )
        CheckRow(
            "Root access",
            when { d.rootGranted == true -> true; d.rootGranted == false -> false; !d.suBinary -> false; else -> null },
            when {
                d.rootGranted == true -> "Granted"
                d.rootGranted == false -> "Denied or not available"
                !d.suBinary -> "No su found (phone isn't rooted)"
                else -> "su found: tap Check root"
            }
        )
        CheckRow(
            "Diag device /dev/diag",
            if (d.hasDiagNode) true else if (rootPending) null else false,
            when {
                d.hasDiagNode -> "Present"
                rootPending -> "Hidden from normal apps. Needs root to check"
                else -> "Not present (kernel built without DIAG)"
            }
        )
        CheckRow(
            "diag_mdlog logger",
            if (d.mdlogPath != null) true else if (rootPending) null else false,
            d.mdlogPath ?: if (rootPending) "Needs root to check" else "Not found in vendor firmware"
        )
        Spacer(Modifier.height(10.dp))
        val (msg, col) = when {
            d.canCapture -> "On-device capture available" to C.grade(Grade.EXCELLENT)
            d.canUsbDiag -> "USB diag port available (no on-device logger)" to C.grade(Grade.GOOD)
            d.vendor != ChipVendor.QUALCOMM -> "Not supported on this chipset" to C.grade(Grade.BAD)
            rootPending && d.suBinary -> "Check root to continue" to C.grade(Grade.FAIR)
            else -> "Requirements not met" to C.grade(Grade.BAD)
        }
        Text(
            msg, color = col, fontWeight = FontWeight.Bold, fontSize = 14.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                .background(col.copy(alpha = 0.14f)).padding(10.dp)
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = a.onCheckRoot, enabled = !d.busy,
                colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.Bg)
            ) { Text(if (d.busy) "Working…" else "Check root", fontWeight = FontWeight.Bold) }
            OutlinedButton(onClick = a.onRefresh, enabled = !d.busy) { Text("Re-detect", color = C.Text) }
        }
    }

    // ---- On-device capture
    Panel(title = "On-device capture (.qmdl)") {
        Text(
            "Records raw modem logs (RRC/NAS signalling, layer 1/2 measurements) into .qmdl files. " +
                "Open them on a PC with QCAT, or convert to Wireshark with SCAT.",
            color = C.Muted, fontSize = 12.sp
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Log mask", color = C.Muted, fontSize = 11.sp)
                Text(d.maskName ?: "None imported", color = C.Text, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
            }
            OutlinedButton(onClick = a.onImportMask) { Text("Import .cfg", color = C.Text) }
        }
        Spacer(Modifier.height(10.dp))
        if (d.capturing) {
            val secs = ((System.currentTimeMillis() - (d.captureStart ?: System.currentTimeMillis())) / 1000)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(C.Rec))
                Spacer(Modifier.width(8.dp))
                Text(
                    "Recording · %02d:%02d · %s".format(secs / 60, secs % 60, sizeLabel(d.captureSizeKb)),
                    color = C.Text, fontSize = 14.sp, fontFamily = FontFamily.Monospace
                )
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = a.onStop, enabled = !d.busy,
                colors = ButtonDefaults.buttonColors(containerColor = C.Rec, contentColor = C.Text)
            ) { Text("Stop capture", fontWeight = FontWeight.Bold) }
        } else {
            Button(
                onClick = a.onStart, enabled = d.canCapture && !d.busy,
                colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.Bg)
            ) { Text("Start capture", fontWeight = FontWeight.Bold) }
            if (!d.canCapture) {
                Text("Needs: Qualcomm + root + /dev/diag + diag_mdlog", color = C.Muted, fontSize = 11.sp)
            }
        }
        d.captureDir?.let {
            Spacer(Modifier.height(8.dp))
            Text("Files: $it  (${sizeLabel(d.captureSizeKb)})", color = C.Muted, fontSize = 12.sp)
            Text("Open with the Files app › Download › RadioKPI_diag", color = C.Muted, fontSize = 11.sp)
        }
    }

    // ---- USB diag port
    var preset by rememberSaveable { mutableStateOf(usbPresets.first().first) }
    Panel(title = "USB diag port (PC tools)") {
        Text(
            "Switches the phone's USB port to DIAG mode so QXDM, QCSuper or SCAT on a PC can read the modem live. " +
                "Charging and file transfer may stop while it's on.",
            color = C.Muted, fontSize = 12.sp
        )
        Spacer(Modifier.height(8.dp))
        InfoGrid(listOf("Current USB mode" to d.usbConfig, "Diag" to if (d.usbDiagOn) "ON" else "off"), cols = 2)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            usbPresets.forEach { (value, label) -> Chip(label, preset == value) { preset = value } }
        }
        Text(preset, color = C.Muted, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(top = 4.dp))
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { a.onUsbDiag(true, preset) }, enabled = d.canUsbDiag && !d.busy,
                colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.Bg)
            ) { Text("Enable", fontWeight = FontWeight.Bold) }
            OutlinedButton(onClick = { a.onUsbDiag(false, preset) }, enabled = d.rootGranted == true && !d.busy) {
                Text("Restore normal USB", color = C.Text)
            }
        }
    }

    // ---- Alternatives
    Panel(title = "Without root or Qualcomm") {
        val tips = when (d.vendor) {
            ChipVendor.EXYNOS, ChipVendor.TENSOR -> listOf(
                "Shannon modems don't use the Qualcomm DIAG protocol.",
                "Samsung: dial *#9900# (SysDump) and turn on Silent Log, if your firmware has it.",
                "Pixel: modem logging requires Google's internal tools and isn't open to apps."
            )
            ChipVendor.MEDIATEK -> listOf(
                "MediaTek uses its own modem log format.",
                "Try Engineer Mode: dial *#*#3646633#*#* › Log and Debugging › MTKLogger (if your brand left it in).",
                "Analyse the logs on a PC with MediaTek ELT."
            )
            ChipVendor.QUALCOMM -> listOf(
                "Samsung phones with Snapdragon: dial *#0808# and choose DM + MODEM + ADB to open the USB diag port without root.",
                "Then connect to a PC running QXDM, QCSuper or SCAT.",
                "Other brands usually need root (Magisk) to open the DIAG port."
            )
            else -> listOf("Diag capture needs a supported chipset. Qualcomm phones with root work best.")
        }
        tips.forEach { t ->
            Row(Modifier.padding(vertical = 3.dp)) {
                Text("•  ", color = C.Accent, fontSize = 13.sp)
                Text(t, color = C.Text, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(4.dp))
        Text("Dialer codes depend on the firmware and may not work on every model.", color = C.Muted, fontSize = 11.sp)
    }

    // ---- Log
    if (d.log.isNotEmpty()) {
        Panel(title = "Activity log") {
            d.log.takeLast(25).forEach {
                Text(it, color = C.Muted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }

    Text(
        "Diag capture is for testing networks and devices you're allowed to test. The logs can contain your phone's identifiers (IMSI/IMEI).",
        color = C.Muted, fontSize = 11.sp
    )
}

private fun sizeLabel(kb: Long?): String = when {
    kb == null -> "—"
    kb >= 1024 -> "%.1f MB".format(kb / 1024f)
    else -> "$kb KB"
}

@Composable
private fun CheckRow(label: String, ok: Boolean?, detail: String) {
    val (sym, col) = when (ok) {
        true -> "✓" to C.grade(Grade.EXCELLENT)
        false -> "✗" to C.grade(Grade.BAD)
        null -> "?" to C.Muted
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(24.dp).clip(CircleShape).background(col.copy(alpha = 0.18f)),
            contentAlignment = Alignment.Center
        ) { Text(sym, color = col, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.width(10.dp))
        Column {
            Text(label, color = C.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(detail, color = C.Muted, fontSize = 12.sp)
        }
    }
}

